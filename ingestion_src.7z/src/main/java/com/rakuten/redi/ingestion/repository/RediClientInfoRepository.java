package com.rakuten.redi.ingestion.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.rakuten.redi.ingestion.model.entity.RediClientInfoEntity;

@Repository
public interface RediClientInfoRepository extends JpaRepository<RediClientInfoEntity, String>{

}
