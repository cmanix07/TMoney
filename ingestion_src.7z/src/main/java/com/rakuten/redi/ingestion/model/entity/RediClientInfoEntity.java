package com.rakuten.redi.ingestion.model.entity;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "REDI_CLIENT_INFO")
public class RediClientInfoEntity {

	@Id
	@Column(name = "CLIENT_ID")
	private String clientId;

	@Column(name = "CLIENT_NAME")
	private String clientName;

	@Column(name = "DELIVERY_STATUS_REQ_DIR")
	private String deliveryStatusReqDir;

	@Column(name = "DELIVERY_STATUS_RES_DIR")
	private String deliveryStatusResDir;

	@Column(name = "LAST_FILE_GENERATED_TIMESTAMP")
	private LocalDateTime lastFileGeneratedTimestamp;

	@Column(name = "CREATE_USER")
	private String createUser;

	@Column(name = "CREATE_TIMESTAMP")
	private LocalDateTime createTimestamp;

	@Column(name = "CHANGE_USER")
	private String changeUser;

	@Column(name = "CHANGE_TIMESTAMP")
	private LocalDateTime changeTimestamp;

}
