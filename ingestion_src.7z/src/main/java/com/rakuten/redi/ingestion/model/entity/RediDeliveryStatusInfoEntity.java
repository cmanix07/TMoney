package com.rakuten.redi.ingestion.model.entity;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@EntityListeners(AuditingEntityListener.class)
@Table(name = "REDI_DELIVERY_STATUS_INFO")
public class RediDeliveryStatusInfoEntity  {

	@EmbeddedId
	private RediDeliveryStatusInfoEntityId rediDeliveryStatusInfoEntityId;


	@Column(name = "ORDER_NUMBER")
	private String orderNumber;

	@Column(name = "DELIVERY_STATUS")
	private Integer deliveryStatus;

	@NotNull
	@CreatedDate
	@Column(name = "CREATE_TIMESTAMP")
	private LocalDateTime createTimestamp;

	@NotNull
	@LastModifiedDate
	@Column(name = "CHANGE_TIMESTAMP")
	private LocalDateTime changeTimestamp;

}
