package com.rakuten.redi.ingestion.util;

import static com.rakuten.redi.ingestion.constants.CommonConstants.CSV_FILE_TYPE;
import static com.rakuten.redi.ingestion.constants.CommonConstants.END_FILE_TYPE;
import static com.rakuten.redi.ingestion.constants.CommonConstants.FILE_SEPARATOR;

import java.io.IOException;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.HashSet;
import java.util.Set;

import org.apache.commons.io.FilenameUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.rakuten.redi.ingestion.exception.RediIngestionException;

public class FileIngestionUtils {

	private static final Logger LOG = LoggerFactory.getLogger(FileIngestionUtils.class);

	public static Set<String> retrieveFiles(String baseFilePath) throws RediIngestionException{
		Set<String> listOfFilesName = new HashSet<>();
		String fileName = "";
		try (DirectoryStream<Path> stream = Files.newDirectoryStream(Paths.get(baseFilePath))) {
			for (Path path : stream) {
				if (!Files.isDirectory(path)) {
					fileName = path.getFileName().toString();
					if(fileName.endsWith(END_FILE_TYPE)) {
						listOfFilesName.add(FilenameUtils.getBaseName(fileName).concat(CSV_FILE_TYPE));
					}
				}
			}
		}catch (IOException ioe) {
			LOG.error("File or directory doesn't exist - baseFilePath: "+baseFilePath,ioe);
			throw new RediIngestionException("File or directory doesn't exist - baseFilePath: "+baseFilePath);
		}

		return listOfFilesName;
	}

	public static Path moveFileFromSrcToDest(String srcPath, String destPath) throws RediIngestionException {
		Path path = Paths.get("");
		if(Paths.get(srcPath).toFile().exists())
			try {
				path =Files.move( Paths.get(srcPath), Paths.get(destPath), StandardCopyOption.REPLACE_EXISTING);
			} catch (IOException e) {
				throw new RediIngestionException("Failed to move the file srcPath {} to destPath {}  ");
			}
		return path;
	}

	public static String addAbsolutePathToFile(String filePath,String endPath, String basefileName, String filetype) {
		String csvFileName = basefileName.concat(filetype);
		return filePath+FILE_SEPARATOR+endPath+FILE_SEPARATOR+csvFileName;
	}

}