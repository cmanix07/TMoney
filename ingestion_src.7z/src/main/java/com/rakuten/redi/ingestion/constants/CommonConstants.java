package com.rakuten.redi.ingestion.constants;

import java.nio.file.FileSystems;

public class CommonConstants {

	public static final int EXIT_CODE_NORMAL = 0;
	public static final int EXIT_CODE_ERROR = 1;

	public static final String DELIVERY_STATUS_PREFIX = "deliveryStatusReq";
	public static final String CSV_FILE_TYPE = ".csv";
	public static final String END_FILE_TYPE = ".end";
	public static final String FILE_SEPARATOR = FileSystems.getDefault().getSeparator();
}
