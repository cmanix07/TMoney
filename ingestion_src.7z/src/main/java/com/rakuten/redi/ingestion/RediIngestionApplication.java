package com.rakuten.redi.ingestion;

import static com.rakuten.redi.ingestion.constants.CommonConstants.EXIT_CODE_ERROR;
import static com.rakuten.redi.ingestion.constants.CommonConstants.EXIT_CODE_NORMAL;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.WebApplicationType;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.data.jpa.repository.config.EnableJpaAuditing;

import com.rakuten.redi.ingestion.executor.FileIngestionExecutor;

@SpringBootApplication
@EnableJpaAuditing
public class RediIngestionApplication {

	private static Logger LOG = LoggerFactory.getLogger(RediIngestionApplication.class);

	@Autowired
	public FileIngestionExecutor fileIngestionExecutor;

	public static void main(String[] args) {
		LOG.info("Inside the RediIngestionApplication main method called.. ");
		SpringApplicationBuilder springApp = new SpringApplicationBuilder(RediIngestionApplication.class)
				.web(WebApplicationType.NONE);
		ConfigurableApplicationContext context = springApp.run(args);
		RediIngestionApplication app = context.getBean(RediIngestionApplication.class);
		app.run(args);
	}

	public void run(String... args) {
		LOG.info("Invoking redi ingestion service request.");
		try {
			fileIngestionExecutor.startIngestion();
		} catch (Exception e) {
			LOG.error("Failure in delivery status request file retrival ", e);
			System.exit(EXIT_CODE_ERROR);
		}
		LOG.info("redi ingestion process  completed");

		System.exit(EXIT_CODE_NORMAL);
	}

}
