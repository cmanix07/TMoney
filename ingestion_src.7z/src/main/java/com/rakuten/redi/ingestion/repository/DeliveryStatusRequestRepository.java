package com.rakuten.redi.ingestion.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.rakuten.redi.ingestion.model.entity.RediDeliveryStatusInfoEntity;
import com.rakuten.redi.ingestion.model.entity.RediDeliveryStatusInfoEntityId;

@Repository
public interface DeliveryStatusRequestRepository extends JpaRepository<RediDeliveryStatusInfoEntity,RediDeliveryStatusInfoEntityId>{

}
