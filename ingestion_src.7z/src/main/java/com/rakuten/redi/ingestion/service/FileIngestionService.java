package com.rakuten.redi.ingestion.service;

import java.io.IOException;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;

import javax.transaction.Transactional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.supercsv.cellprocessor.constraint.NotNull;
import org.supercsv.cellprocessor.ift.CellProcessor;
import org.supercsv.io.CsvBeanReader;

import com.rakuten.redi.ingestion.exception.RediIngestionException;
import com.rakuten.redi.ingestion.executor.FileIngestionExecutor;
import com.rakuten.redi.ingestion.model.DeliveryStatusRequestCSV;
import com.rakuten.redi.ingestion.model.entity.RediClientInfoEntity;
import com.rakuten.redi.ingestion.model.entity.RediDeliveryStatusInfoEntity;
import com.rakuten.redi.ingestion.model.entity.RediDeliveryStatusInfoEntityId;
import com.rakuten.redi.ingestion.repository.DeliveryStatusRequestRepository;
import com.rakuten.redi.ingestion.repository.RediClientInfoRepository;

import net.sf.oval.ConstraintViolation;
import net.sf.oval.Validator;
import net.sf.oval.exception.ValidationFailedException;

@Service
public class FileIngestionService {

	private static final Logger log = LoggerFactory.getLogger(FileIngestionExecutor.class);

	@Autowired
	private DeliveryStatusRequestRepository deliveryStatusRequestRepository;

	@Autowired
	private RediClientInfoRepository rediClientInfoRepository;

	public FileIngestionService(DeliveryStatusRequestRepository deliveryStatusRequestRepository,
			RediClientInfoRepository rediClientInfoRepository) {
		this.deliveryStatusRequestRepository = deliveryStatusRequestRepository;
		this.rediClientInfoRepository = rediClientInfoRepository;
	}

	@Transactional(rollbackOn = Exception.class)
	public void writeCsvDataToDB(String fileName, CsvBeanReader csvBeanReader, String clientId)
			throws RediIngestionException, ValidationFailedException, IllegalArgumentException {
		DeliveryStatusRequestCSV deliverystatusRequestEntityCSV = null;
		Set<RediDeliveryStatusInfoEntity> deliveryStatusRequestEntityList = new HashSet<>();
		List<ConstraintViolation> constraintViolations = new LinkedList<>();
		Validator validator = new Validator();
		log.info("Inside the writeToDB clientId: " + clientId);

		try {

			while ((deliverystatusRequestEntityCSV = csvBeanReader.read(DeliveryStatusRequestCSV.class,
					DeliveryStatusRequestCSV.HEADERS, getProcessors())) != null) {

				RediDeliveryStatusInfoEntity rediDeliveryStatusInfoEntity = new RediDeliveryStatusInfoEntity();
				RediDeliveryStatusInfoEntityId rediDeliveryStatusInfoEntityId = new RediDeliveryStatusInfoEntityId(
						deliverystatusRequestEntityCSV.getReferenceId(),
						deliverystatusRequestEntityCSV.getTrackingNumber(),
						deliverystatusRequestEntityCSV.getCompanyNumber(), clientId);
				rediDeliveryStatusInfoEntity.setRediDeliveryStatusInfoEntityId(rediDeliveryStatusInfoEntityId);
				rediDeliveryStatusInfoEntity.setOrderNumber(deliverystatusRequestEntityCSV.getOrderNumber());
				rediDeliveryStatusInfoEntity.setDeliveryStatus(null);
				deliveryStatusRequestEntityList.add(rediDeliveryStatusInfoEntity);

				constraintViolations.addAll(validator.validate(deliverystatusRequestEntityCSV));

			}
			if (constraintViolations.size() > 0) {
				throw new RediIngestionException(ValidationMessage(constraintViolations));
			}
			if (!CollectionUtils.isEmpty(deliveryStatusRequestEntityList)) {
				deliveryStatusRequestRepository.saveAll(deliveryStatusRequestEntityList);
				log.info("Update of deliveryStatusRequestEntity Finished for file " + fileName);
			}
		} catch (RediIngestionException | IOException e) {
			throw new RediIngestionException("Unable to update the records for file: " + fileName);
		}
	}

	public List<RediClientInfoEntity> findAllClients() {
		return rediClientInfoRepository.findAll();
	}

	private static CellProcessor[] getProcessors() {

		final CellProcessor[] processors = new CellProcessor[] { new NotNull(), // referenceId
				new NotNull(), // trackingNumber
				new NotNull(), // companyNumber
				null // orderNumber
		};
		return processors;
	}

	private String ValidationMessage(List<ConstraintViolation> constraintViolations) {
		StringBuilder sb = new StringBuilder("");
		constraintViolations.forEach(constraintViolation -> {
			sb.append(constraintViolation.getMessage()).append(" - ").append(constraintViolation.getInvalidValue())
			.append("\n");
		});

		return sb.toString();
	}

}
