package com.rakuten.redi.ingestion.exception;

public class RediIngestionException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public RediIngestionException(String message) {
        super(message);
    }
}
