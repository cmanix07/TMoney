package com.rakuten.redi.ingestion.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import net.sf.oval.constraint.MatchPattern;
import net.sf.oval.constraint.MemberOf;
import net.sf.oval.constraint.NotBlank;
import net.sf.oval.constraint.NotNull;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class DeliveryStatusRequestCSV {

	public static String[] HEADERS_JAPANESE = {"顧客管理番号","追跡番号","受注番号","配送キャリア番号"};

	public static String[] HEADERS = {"referenceId","trackingNumber","orderNumber","companyNumber"};

	@NotNull(message = "Reference Id is a required.")
	@MatchPattern(pattern = "^[A-Za-z0-9-_]+$", message = "Invalid Reference Id.")
	private String referenceId;

	@NotNull(message = "Tracking number is a required.")
	@MatchPattern(pattern = "^[A-Za-z0-9]+$", message = "Invalid tracking number.")
	private String trackingNumber;

	
	@NotNull(message = "Company number is a required.")
	@MemberOf(message="This is a value that cannot be set for Company Number. ", value= {"1001","1002","1003","1017","1028"})
	private String companyNumber;

	@NotNull(message = "Order number is a required.")
	@MatchPattern(pattern = "^[A-Za-z0-9-_]+$", message = "Invalid Order number.")
	private String orderNumber;

}
