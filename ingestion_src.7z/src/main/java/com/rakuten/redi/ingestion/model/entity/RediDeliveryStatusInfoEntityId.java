package com.rakuten.redi.ingestion.model.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Embeddable
public class RediDeliveryStatusInfoEntityId implements Serializable{

	private static final long serialVersionUID = 1L;

	@Column(name = "REFERENCE_ID")
	private String referenceId;

	@Column(name = "TRACKING_NUMBER")
	private String trackingNumber;

	@Column(name = "COMPANY_NUMBER")
	private String companyNumber;

	@Column(name = "CLIENT_ID")
	private String clientId;

}
