package com.rakuten.redi.ingestion.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Component
@Data
@ConfigurationProperties(prefix ="redi.path") 
@NoArgsConstructor
@AllArgsConstructor
public class FileIngestionConfig {

	private String backupDir ;
	private String receiveDir ;
	private String errorDir ;

}
