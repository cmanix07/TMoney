package com.rakuten.redi.ingestion.executor;


import static com.rakuten.redi.ingestion.constants.CommonConstants.CSV_FILE_TYPE;
import static com.rakuten.redi.ingestion.constants.CommonConstants.END_FILE_TYPE;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.apache.commons.io.FilenameUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.supercsv.io.CsvBeanReader;
import org.supercsv.prefs.CsvPreference;

import com.rakuten.redi.ingestion.config.FileIngestionConfig;
import com.rakuten.redi.ingestion.constants.CommonConstants;
import com.rakuten.redi.ingestion.exception.RediIngestionException;
import com.rakuten.redi.ingestion.model.entity.RediClientInfoEntity;
import com.rakuten.redi.ingestion.service.FileIngestionService;
import com.rakuten.redi.ingestion.util.FileIngestionUtils;

import net.sf.oval.exception.ValidationFailedException;

@Component
public class FileIngestionExecutor {
	private static final Logger log = LoggerFactory.getLogger(FileIngestionExecutor.class);

	@Autowired
	FileIngestionConfig fileIngestionConfig;

	@Autowired
	FileIngestionService fileIngestionService;

	public FileIngestionExecutor(FileIngestionConfig fileIngestionConfig, FileIngestionService fileIngestionService) {
		super();
		this.fileIngestionConfig = fileIngestionConfig;
		this.fileIngestionService = fileIngestionService;
	}

	public void startIngestion() throws ValidationFailedException, IllegalArgumentException {

		List<RediClientInfoEntity> clientInfoEntityList = fileIngestionService.findAllClients();
		clientInfoEntityList.forEach(rediClientInfoEntity -> {

			String baseFilePath = rediClientInfoEntity.getDeliveryStatusReqDir();
			String clientId = rediClientInfoEntity.getClientId();

			try {
				batchExecute(baseFilePath, clientId);
			} catch (RediIngestionException rie) {
				log.error("Issue in processing of client {} "+rie.getMessage(), clientId);
			}

		});
	} 

	public void batchExecute(String baseFilePath, String clientId) throws RediIngestionException, ValidationFailedException, IllegalArgumentException {
		Set<String> listOfFilesName = null;
		log.info("BatchExecute call where inputFilePath is: " + baseFilePath);
		String absoluteFile = "";
		String absoluteBackupFile = "";
		String absoluteErrorFile = "";
		File endFile = null;
		String fileName = "";
		CsvBeanReader csvBeanReader = null;
		try {
			listOfFilesName = FileIngestionUtils
					.retrieveFiles(baseFilePath + CommonConstants.FILE_SEPARATOR + fileIngestionConfig.getReceiveDir());

			log.info("No of input files " + listOfFilesName.size());
			Iterator<String> it = listOfFilesName.iterator();
			while (it.hasNext()) {
				fileName = it.next();
				absoluteFile = FileIngestionUtils.addAbsolutePathToFile(baseFilePath,
						fileIngestionConfig.getReceiveDir(), FilenameUtils.getBaseName(fileName), CSV_FILE_TYPE);
				endFile = Paths.get(FileIngestionUtils.addAbsolutePathToFile(baseFilePath,
						fileIngestionConfig.getReceiveDir(), FilenameUtils.getBaseName(fileName), END_FILE_TYPE))
						.toFile();
				absoluteBackupFile = FileIngestionUtils.addAbsolutePathToFile(baseFilePath,
						fileIngestionConfig.getBackupDir(), FilenameUtils.getBaseName(fileName), CSV_FILE_TYPE);
				csvBeanReader = getCsvBeanReader(absoluteFile);
				fileIngestionService.writeCsvDataToDB(fileName, csvBeanReader, clientId);
				moveFile(absoluteFile, absoluteBackupFile);
				deleteFile(endFile);
			}
		} catch (RediIngestionException rie) {
			log.error("Application error occured for clientId {} and file {}  " + rie.getMessage(), absoluteFile,
					clientId);
			absoluteErrorFile = FileIngestionUtils.addAbsolutePathToFile(baseFilePath,
					fileIngestionConfig.getErrorDir(), FilenameUtils.getBaseName(fileName), CSV_FILE_TYPE);
			moveFile(absoluteFile, absoluteErrorFile);
			deleteFile(endFile);
		}finally {
			try {
				if(null != csvBeanReader)
					csvBeanReader.close();
			} catch (IOException e) {
				log.info("Failed to close the csvBeanReader: "+csvBeanReader);
			}
		}
	}

	private CsvBeanReader getCsvBeanReader(String name) throws RediIngestionException {
		CsvBeanReader reader;
		try {
			reader = new CsvBeanReader(new FileReader(name), CsvPreference.STANDARD_PREFERENCE);
			reader.getHeader(false);
		} catch (IOException e) {
			throw new RediIngestionException(e.getMessage());		

		}
		return reader;
	}

	public Path moveFile(String absoluteFile, String absoluteBackupFile) throws RediIngestionException {
		Path path = null;
		path = FileIngestionUtils.moveFileFromSrcToDest(absoluteFile, absoluteBackupFile);
		return path;
	}

	public boolean deleteFile(File file) throws RediIngestionException {
		boolean deleted = Boolean.FALSE;
		if (null != file && file.exists()) {
			deleted = file.delete();
		}
		return deleted;
	}

}
