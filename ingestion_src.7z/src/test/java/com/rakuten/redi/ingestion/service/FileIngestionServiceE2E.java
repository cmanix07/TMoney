package com.rakuten.redi.ingestion.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.doThrow;

import java.nio.file.Paths;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.annotation.Rollback;

import com.rakuten.redi.ingestion.config.FileIngestionConfig;
import com.rakuten.redi.ingestion.exception.RediIngestionException;
import com.rakuten.redi.ingestion.executor.FileIngestionExecutor;
import com.rakuten.redi.ingestion.repository.DeliveryStatusRequestRepository;

@SpringBootTest
public class FileIngestionServiceE2E {

	private FileIngestionExecutor spyFileIngestionExecutor;
	@Autowired
	private FileIngestionExecutor fileIngestionExecutor;

	@Autowired
	private FileIngestionConfig fileIngestionConfig;

	@Autowired
	FileIngestionService fileIngestionService;
	
	@Autowired
	private DeliveryStatusRequestRepository deliveryStatusRequestRepository;


	private static final String baseFilePath = Paths.get("src", "test", "resources").toFile().getAbsolutePath();


	@BeforeEach
	private void setup() {
		fileIngestionExecutor = new FileIngestionExecutor(fileIngestionConfig, fileIngestionService);
		spyFileIngestionExecutor = Mockito.spy(fileIngestionExecutor);
	}

	@Test
	void shouldCatchExceptionAndSuccessForBatchExecute() throws Exception {
		doReturn(Paths.get("")).when(spyFileIngestionExecutor).moveFile(Mockito.anyString(), Mockito.anyString());
		doReturn(Boolean.TRUE).when(spyFileIngestionExecutor).deleteFile(Mockito.any());
		doThrow(RediIngestionException.class).when(spyFileIngestionExecutor).batchExecute(baseFilePath, "R-WAYBILL");

	}

	@Test
	@Rollback
	void shouldReadTrackingNoAndWriteToDB() throws Exception {
		doReturn(Paths.get("")).when(spyFileIngestionExecutor).moveFile(Mockito.anyString(), Mockito.anyString());
		doReturn(Boolean.TRUE).when(spyFileIngestionExecutor).deleteFile(Mockito.any());
		spyFileIngestionExecutor.batchExecute(baseFilePath, "R-WAYBILL");

		assertEquals(2, deliveryStatusRequestRepository.findAll().size());
	}
}
