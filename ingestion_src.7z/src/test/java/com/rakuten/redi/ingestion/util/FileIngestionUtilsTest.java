package com.rakuten.redi.ingestion.util;

import static com.rakuten.redi.ingestion.constants.CommonConstants.FILE_SEPARATOR;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.File;
import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

import com.rakuten.redi.ingestion.exception.RediIngestionException;

@ExtendWith(MockitoExtension.class)
public class FileIngestionUtilsTest {
	
	private static final String baseFilePath = Paths.get("src","test","resources").toFile().getAbsolutePath();
	
	@Test
	public void moveFileFromSrcToDestTest() throws IOException, RediIngestionException {
		
		
		String source = baseFilePath+FILE_SEPARATOR+"recv"+FILE_SEPARATOR+"test.csv";
		String dest = baseFilePath+FILE_SEPARATOR+"bkup"+FILE_SEPARATOR+"test.csv";
		//Blank path test
		Path pathEmpty = FileIngestionUtils.moveFileFromSrcToDest("", "");
		assertEquals(pathEmpty, Paths.get(""));
		
		File file = new File(source);
		file.deleteOnExit();
		assertTrue(!file.exists());
		file.createNewFile();
		Path path = FileIngestionUtils.moveFileFromSrcToDest(source, dest);
		assertEquals(path, Paths.get(dest));
	}
	
	@Test
	public void retrieveFilesTest() throws RediIngestionException {
		//IOException.class check
		RediIngestionException ioException =  assertThrows(RediIngestionException.class, ()-> {
			FileIngestionUtils.retrieveFiles("dummy");
		});
		String actualIoExceptionMessage = ioException.getMessage();
		assertTrue(actualIoExceptionMessage.contains("File or directory doesn't exist - baseFilePath"));
		
		//Exception.class check
		Exception exception =  assertThrows(Exception.class, ()-> {
			FileIngestionUtils.retrieveFiles(null);
		});
		String actualExceptionMessage = exception.getMessage();
		assertNull(actualExceptionMessage);
		//File check 
		Set<String> actualListOfFiles = new HashSet<>();
		actualListOfFiles.add("deliveryStatusReq_R-Waybill_20202505.csv");
		Set<String> listOfFiles = FileIngestionUtils.retrieveFiles(baseFilePath+FILE_SEPARATOR+"recv");
		assertTrue(listOfFiles.containsAll(actualListOfFiles));

		//path is not an directory
		Set<String> emptyFileList = FileIngestionUtils.retrieveFiles(baseFilePath);
		assertTrue(emptyFileList.containsAll(Collections.EMPTY_SET));
		
		
		
	}

}
