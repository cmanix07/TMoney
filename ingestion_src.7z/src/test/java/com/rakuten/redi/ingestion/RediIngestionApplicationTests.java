package com.rakuten.redi.ingestion;

import static org.mockito.Mockito.doThrow;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.ginsberg.junit.exit.ExpectSystemExitWithStatus;
import com.rakuten.redi.ingestion.executor.FileIngestionExecutor;


@ExtendWith(MockitoExtension.class)
class RediIngestionApplicationTests {

	@Mock
	FileIngestionExecutor mockedFileIngestionExecutor;

	@InjectMocks
	private RediIngestionApplication rediIngestionApplication;

	@Test
	void contextLoads() {
	}

	@Test
	@ExpectSystemExitWithStatus(0)
	public void shouldReturnZeroExitCodeOnSuccessInRunMethod() {
		rediIngestionApplication.run("");
	}

	@Test
	@ExpectSystemExitWithStatus(1)
	public void shouldReturnNonZeroExitCodeOnExceptionInRunMethod() {
		doThrow(RuntimeException.class).when(mockedFileIngestionExecutor).startIngestion();
		rediIngestionApplication.run("");
	}
}

	
	
	

