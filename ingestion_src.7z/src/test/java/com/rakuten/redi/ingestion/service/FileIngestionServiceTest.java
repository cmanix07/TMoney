package com.rakuten.redi.ingestion.service;

import static com.rakuten.redi.ingestion.constants.CommonConstants.FILE_SEPARATOR;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.atLeast;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Arrays;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.supercsv.io.CsvBeanReader;
import org.supercsv.prefs.CsvPreference;

import com.rakuten.redi.ingestion.config.FileIngestionConfig;
import com.rakuten.redi.ingestion.exception.RediIngestionException;
import com.rakuten.redi.ingestion.executor.FileIngestionExecutor;
import com.rakuten.redi.ingestion.model.entity.RediClientInfoEntity;
import com.rakuten.redi.ingestion.model.entity.RediDeliveryStatusInfoEntity;
import com.rakuten.redi.ingestion.repository.DeliveryStatusRequestRepository;
import com.rakuten.redi.ingestion.repository.RediClientInfoRepository;

import net.sf.oval.exception.ValidationFailedException;

@ExtendWith(MockitoExtension.class)
public class FileIngestionServiceTest {

	public static final String WAYBILL_CLIENT_ID = "R-WAYBILL";

	private static DeliveryStatusRequestRepository deliveryStatusInfoRepository;
	private static FileIngestionConfig fileIngestionConfig;
	private static FileIngestionExecutor fileIngestionExecutor;
	private static FileIngestionExecutor spyFileIngestionExecutor;
	private static RediClientInfoRepository rediClientInfoRepository;
	private static FileIngestionService fileIngestionService;

	private static final String baseFilePath = Paths.get("src", "test", "resources").toFile().getAbsolutePath();

	@BeforeAll
	public static void setup() {
		fileIngestionConfig = Mockito.mock(FileIngestionConfig.class);
		fileIngestionExecutor = Mockito.mock(FileIngestionExecutor.class);
		deliveryStatusInfoRepository = Mockito.mock(DeliveryStatusRequestRepository.class);
		rediClientInfoRepository = Mockito.mock(RediClientInfoRepository.class);
		fileIngestionService = Mockito.mock(FileIngestionService.class);

		fileIngestionExecutor = new FileIngestionExecutor(fileIngestionConfig,fileIngestionService);
		spyFileIngestionExecutor = Mockito.spy(fileIngestionExecutor);

		when(fileIngestionConfig.getReceiveDir()).thenReturn("recv");
		when(fileIngestionConfig.getBackupDir()).thenReturn("bkup");
		when(fileIngestionConfig.getErrorDir()).thenReturn("err");

	}

	@Test
	void shouldNotFailForEmptyData() throws Exception {
		CsvBeanReader csvBeanReader = getCsvBeanReader(baseFilePath + FILE_SEPARATOR
				+ fileIngestionConfig.getReceiveDir() + FILE_SEPARATOR + "deliveryStatusReq_R-Waybill_EmptyFile.csv");
		csvBeanReader.getHeader(false);
		fileIngestionService.writeCsvDataToDB("deliveryStatusReq_R-Waybill_EmptyFile.csv", csvBeanReader, WAYBILL_CLIENT_ID);
		Set<RediDeliveryStatusInfoEntity> deliveryStatusRequestEntityList = new HashSet<>();
		verify(deliveryStatusInfoRepository, times(0)).saveAll(deliveryStatusRequestEntityList);
	}

	@Test
	void shouldNotFailIfFileNotExist() throws RediIngestionException {
		doReturn(Paths.get("")).when(spyFileIngestionExecutor).moveFile(Mockito.anyString(), Mockito.anyString());
		doReturn(Boolean.TRUE).when(spyFileIngestionExecutor).deleteFile(Mockito.any());
		spyFileIngestionExecutor.batchExecute(baseFilePath + FILE_SEPARATOR + "dummy", WAYBILL_CLIENT_ID);
		verify(deliveryStatusInfoRepository,times(0)).saveAll(Mockito.any());
	}

	@Test
	void shouldReadTrackingNoAndWriteToDB() throws Exception {
		doReturn(Paths.get("")).when(spyFileIngestionExecutor).moveFile(Mockito.anyString(), Mockito.anyString());
		doReturn(Boolean.TRUE).when(spyFileIngestionExecutor).deleteFile(Mockito.any());
		spyFileIngestionExecutor.batchExecute(baseFilePath, WAYBILL_CLIENT_ID);

		verify(fileIngestionService, atLeast(1)).writeCsvDataToDB(Mockito.anyString(), Mockito.any(), Mockito.anyString());
	}

	@Test
	void shouldDeleteFileTest() throws RediIngestionException, IOException {

		String source = baseFilePath + FILE_SEPARATOR + "recv" + FILE_SEPARATOR + "test.csv";
		File file = new File(source);
		file.deleteOnExit();
		// Check files not exist
		assertFalse(fileIngestionExecutor.deleteFile(file));
		file.createNewFile();
		// File exist
		assertTrue(fileIngestionExecutor.deleteFile(file));
		assertFalse(fileIngestionExecutor.deleteFile(null));

	}

	@Test
	public void shouldMoveFileTest() throws RediIngestionException {
		Path path = fileIngestionExecutor.moveFile("", "");
		assertEquals(path, Paths.get(""), "");
	}

	@Test
	public void shouldProcessAllClientsSucessTest() throws Exception {
		RediClientInfoEntity rediClientInfoEntity = new RediClientInfoEntity();
		rediClientInfoEntity.setDeliveryStatusReqDir(baseFilePath);
		rediClientInfoEntity.setClientId("R-WAYBILL");
		List<RediClientInfoEntity> clientInfoEntityList = new LinkedList<>(Arrays.asList(rediClientInfoEntity));
		when(rediClientInfoRepository.findAll()).thenReturn(clientInfoEntityList);

		doReturn(Paths.get("")).when(spyFileIngestionExecutor).moveFile(Mockito.anyString(), Mockito.anyString());
		doReturn(Boolean.TRUE).when(spyFileIngestionExecutor).deleteFile(Mockito.any());

		spyFileIngestionExecutor.startIngestion();
	}

	@Test
	public void ShouldsuccessNextClientFileIngestionWhenOneFailedTest() throws Exception {

		RediClientInfoEntity rediClientInfoEntityException = new RediClientInfoEntity();
		rediClientInfoEntityException.setDeliveryStatusReqDir("dummy");
		rediClientInfoEntityException.setClientId("R-WAYBILL");

		RediClientInfoEntity rediClientInfoEntity = new RediClientInfoEntity();
		rediClientInfoEntityException.setDeliveryStatusReqDir(baseFilePath);
		rediClientInfoEntityException.setClientId("R-WAYBILL");

		List<RediClientInfoEntity> clientInfoEntityList = new LinkedList<>(Arrays.asList(rediClientInfoEntityException, rediClientInfoEntity));
		when(rediClientInfoRepository.findAll()).thenReturn(clientInfoEntityList);

		doReturn(Paths.get("")).when(spyFileIngestionExecutor).moveFile(Mockito.anyString(), Mockito.anyString());
		doReturn(Boolean.TRUE).when(spyFileIngestionExecutor).deleteFile(Mockito.any());

		doThrow(RuntimeException.class).when(spyFileIngestionExecutor).batchExecute("dummy", WAYBILL_CLIENT_ID);
		spyFileIngestionExecutor.startIngestion();

	}

	@Test
	void shouldCatchExceptionAndProceedForBatchExecute() throws Exception {
		doReturn(Paths.get("")).when(spyFileIngestionExecutor).moveFile(Mockito.anyString(), Mockito.anyString());
		doReturn(Boolean.TRUE).when(spyFileIngestionExecutor).deleteFile(Mockito.any());
		spyFileIngestionExecutor.batchExecute(baseFilePath, WAYBILL_CLIENT_ID);

		verify(fileIngestionService, atLeast(1)).writeCsvDataToDB(Mockito.anyString(), Mockito.any(), Mockito.anyString());
	}


	@Test
	public void shouldProcessStartIngestionTest() throws Exception {
		RediClientInfoEntity rediClientInfoEntity = new RediClientInfoEntity();
		rediClientInfoEntity.setDeliveryStatusReqDir(baseFilePath);
		rediClientInfoEntity.setClientId("R-WAYBILL");
		List<RediClientInfoEntity> clientInfoEntityList = new LinkedList<>(Arrays.asList(rediClientInfoEntity));
		when(fileIngestionService.findAllClients()).thenReturn(clientInfoEntityList);

		doReturn(Paths.get("")).when(spyFileIngestionExecutor).moveFile(Mockito.anyString(), Mockito.anyString());
		doReturn(Boolean.TRUE).when(spyFileIngestionExecutor).deleteFile(Mockito.any());

		spyFileIngestionExecutor.startIngestion();
	}

	@Test
	void shouldThrowRuntimeExceptionTrackingNoAndWriteToDB() throws Exception {
		doReturn(Paths.get("")).when(spyFileIngestionExecutor).moveFile(Mockito.anyString(), Mockito.anyString());
		doReturn(Boolean.TRUE).when(spyFileIngestionExecutor).deleteFile(Mockito.any());

		FileIngestionService mockedFileIngestionService = Mockito.mock(FileIngestionService.class);
		FileIngestionExecutor fileIngestionExecutor = new FileIngestionExecutor(fileIngestionConfig, mockedFileIngestionService);
		FileIngestionExecutor spyFileIngestionExecutor = Mockito.spy(fileIngestionExecutor);

		doThrow(new ValidationFailedException("ValidationFailedException in DB update")).when(mockedFileIngestionService).writeCsvDataToDB(Mockito.anyString(), Mockito.any(), Mockito.anyString());
		Exception exception = assertThrows(RuntimeException.class, () -> {
			spyFileIngestionExecutor.batchExecute(baseFilePath, "R-WAYBILL");
		});

		String expectedMessage = "ValidationFailedException in DB update";
		String actualMessage = exception.getMessage();
		assertTrue(actualMessage.contains(expectedMessage));
	}

	@Test
	void shouldThrowRuntimeExceptionBatchExecute() throws Exception {
		doReturn(Paths.get("")).when(spyFileIngestionExecutor).moveFile(Mockito.anyString(), Mockito.anyString());
		doReturn(Boolean.TRUE).when(spyFileIngestionExecutor).deleteFile(Mockito.any());

		FileIngestionService mockedFileIngestionService = Mockito.mock(FileIngestionService.class);
		FileIngestionExecutor fileIngestionExecutor = new FileIngestionExecutor(fileIngestionConfig, mockedFileIngestionService);
		FileIngestionExecutor spyFileIngestionExecutor = Mockito.spy(fileIngestionExecutor);

		RediClientInfoEntity rediClientInfoEntity =new RediClientInfoEntity();
		rediClientInfoEntity.setClientId(WAYBILL_CLIENT_ID);
		rediClientInfoEntity.setDeliveryStatusReqDir("dummy");
		List<RediClientInfoEntity> list = new LinkedList<>();
		list.add(rediClientInfoEntity);
		when(mockedFileIngestionService.findAllClients()).thenReturn(list);

		doThrow(new RuntimeException("RuntimeException in BatchExecute")).when(spyFileIngestionExecutor).batchExecute(Mockito.anyString(), Mockito.anyString());
		Exception exceptionInStartIng = assertThrows(RuntimeException.class, () -> {
			spyFileIngestionExecutor.startIngestion();
		});

		String expectedMessageInStartIng = "RuntimeException in BatchExecute";
		String actualMessageInStartIng = exceptionInStartIng.getMessage();
		assertTrue(actualMessageInStartIng.contains(expectedMessageInStartIng));
	}
	
	@Test
	void shouldThrowRuntimeExceptionToStartIngestionForWriteToDB() throws Exception {
		doReturn(Paths.get("")).when(spyFileIngestionExecutor).moveFile(Mockito.anyString(), Mockito.anyString());
		doReturn(Boolean.TRUE).when(spyFileIngestionExecutor).deleteFile(Mockito.any());

		FileIngestionService mockedFileIngestionService = Mockito.mock(FileIngestionService.class);
		FileIngestionExecutor fileIngestionExecutor = new FileIngestionExecutor(fileIngestionConfig, mockedFileIngestionService);
		FileIngestionExecutor spyFileIngestionExecutor = Mockito.spy(fileIngestionExecutor);

		RediClientInfoEntity rediClientInfoEntity =new RediClientInfoEntity();
		rediClientInfoEntity.setClientId(WAYBILL_CLIENT_ID);
		rediClientInfoEntity.setDeliveryStatusReqDir(baseFilePath);
		List<RediClientInfoEntity> list = new LinkedList<>();
		list.add(rediClientInfoEntity);
		when(mockedFileIngestionService.findAllClients()).thenReturn(list);
		
		doThrow(new ValidationFailedException("RuntimeException throws to StartIngestion")).when(mockedFileIngestionService).writeCsvDataToDB(Mockito.anyString(), Mockito.any(), Mockito.anyString());
		Exception exceptionInStartIng = assertThrows(RuntimeException.class, () -> {
			spyFileIngestionExecutor.startIngestion();
		});

		String expectedMessageInStartIng = "RuntimeException throws to StartIngestion";
		String actualMessageInStartIng = exceptionInStartIng.getMessage();
		assertTrue(actualMessageInStartIng.contains(expectedMessageInStartIng));
	}

	private CsvBeanReader getCsvBeanReader(String name) throws FileNotFoundException, UnsupportedEncodingException {
		BufferedReader targetFileReader = new BufferedReader(
				new InputStreamReader(new BufferedInputStream(new FileInputStream(new File(name)))));
		return new CsvBeanReader(targetFileReader, CsvPreference.STANDARD_PREFERENCE);
	}

}
