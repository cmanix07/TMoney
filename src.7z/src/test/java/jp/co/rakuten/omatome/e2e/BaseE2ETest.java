package jp.co.rakuten.omatome.e2e;

import jp.co.rakuten.omatome.Application;
import jp.co.rakuten.omatome.controller.OmatomeController;
import org.json.JSONObject;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestInstance.Lifecycle;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.platform.runner.JUnitPlatform;
import org.junit.runner.RunWith;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.jdbc.Sql;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.util.ArrayList;
import java.util.List;

@Tag("e2e")
@RunWith(JUnitPlatform.class)
@ExtendWith({SpringExtension.class, MockitoExtension.class})
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT, classes = {Application.class})
@TestInstance(Lifecycle.PER_CLASS)
public abstract class BaseE2ETest {

	/**
	 * The root testing url
	 */
	private static final String HTTP_LOCALHOST = "http://localhost:";

	/**
	 * The root path uri of our tested api
	 */
	@Value("${server.servlet.context-path}")
	public static String rootpath;

	/**
	 * The random port choosen by spring for the tomcat server
	 */
	@LocalServerPort
	public int port;

	/**
	 * Base url of the service
	 */
	public String baseUrl;

	public String myOrderApiUrl;
	
	public String deliveryChangeUrl;

	public String token;
	
	private String headerAuthorization 	= 	"Authorization";

	/**
	 * Http client used for the tests
	 */
	@Autowired
	public TestRestTemplate template;
	
	public HttpEntity<?> httpRequestEntity;
	
	public HttpHeaders headers = new HttpHeaders();

	@BeforeAll
	public void setUp() {
		baseUrl = HTTP_LOCALHOST + port + OmatomeController.API_PATH;
		myOrderApiUrl = baseUrl + "/myOrders";
		deliveryChangeUrl = baseUrl + "/delivery-change";

		String accessTokenUrl = HTTP_LOCALHOST + port + "/accesstoken";
		String data = "{ \n" + "\"username\":\"omatome_user\",\n" + "\"password\":\"omatome@dev2020\"\n" + "}";
		ResponseEntity<?> response = template.postForEntity(accessTokenUrl, data, JSONObject.class);
		token = response.getHeaders().get("Authorization").toString();
	
		headers.setContentType(MediaType.APPLICATION_JSON);
		List<MediaType> acceptableMediaTypes = new ArrayList<>();
		acceptableMediaTypes.add(MediaType.APPLICATION_JSON);
		headers.setAccept(acceptableMediaTypes);
		token = token.replaceAll("\\[", "");
		token = token.replaceAll("\\]", "");

		headers.add(headerAuthorization,token );
		headers.add("easyId", "1");
		
	}

}
