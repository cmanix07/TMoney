package jp.co.rakuten.omatome.service;

import static org.junit.Assert.assertNull;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.lenient;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import jp.co.rakuten.omatome.entity.OmatomeAppConfig;
import jp.co.rakuten.omatome.entity.OmatomeUserEntity;
import jp.co.rakuten.omatome.entity.OmatomeUserEntityId;
import jp.co.rakuten.omatome.repository.OmatomeAppConfigRepository;
import jp.co.rakuten.omatome.repository.OmatomeUserRepository;
import jp.co.rakuten.omatome.response.AppMetadataResponse;
import jp.co.rakuten.omatome.response.MyMenuResponse;
import jp.co.rakuten.omatome.utils.OmatomeConstants;

@ExtendWith(MockitoExtension.class)
public class OmatomeServiceTest {

	@InjectMocks
	private OmatomeService omatomeService;
	@Mock
	private OmatomeUserRepository omatomeUserRepository;

	@Mock
	private OmatomeAppConfigRepository omatomeAppConfigRepository;
	
	@Test
	public void registerNewUserTest() {
		String easyId = "EASY_ID1";
		String deviceId = "DEVICE_ID1";
		String appVersion = "1.0.0";

		OmatomeUserEntity omatomeUserEntity = new OmatomeUserEntity();
		OmatomeUserEntityId omatomeUserEntityId = new OmatomeUserEntityId();
		omatomeUserEntityId.setDeviceId(deviceId);
		omatomeUserEntityId.setEasyId(easyId);
		omatomeUserEntity.setOmatomeUserId(omatomeUserEntityId);
		omatomeUserEntity.setAppVersion(appVersion);
		omatomeService.register(easyId, deviceId,appVersion);
		verify(omatomeUserRepository,times(1)).save(omatomeUserEntity);
		
	}
	
	@Test
	public void updateUserInfoTest() {
		String easyId = "EASY_ID1";
		String deviceId = "DEVICE_ID1";
		String appVersion = "1.0.0";

		OmatomeUserEntity omatomeUserEntity = new OmatomeUserEntity();
		OmatomeUserEntityId omatomeUserEntityId = new OmatomeUserEntityId();
		omatomeUserEntityId.setDeviceId(deviceId);
		omatomeUserEntityId.setEasyId(easyId);
		omatomeUserEntity.setOmatomeUserId(omatomeUserEntityId);
		omatomeUserEntity.setAppVersion(appVersion);
		Optional<OmatomeUserEntity> optional = Optional.of(omatomeUserEntity);
		lenient().when(omatomeUserRepository.findById(omatomeUserEntityId)).thenReturn(optional);

		String appNewVersion = "1.1.0";
		omatomeUserEntity.setAppVersion(appNewVersion);
		omatomeService.register(easyId, deviceId,appNewVersion);
		verify(omatomeUserRepository,times(1)).save(omatomeUserEntity);
		
	}
	
	@Test
	public void testForceAppUpdate() {
		
		OmatomeAppConfig appConfig = new OmatomeAppConfig();
		String forceUpdateMessage = "Please update to latest app to continue using app";
		String appVersion ="1.0.0";
		appConfig.setCurrentVersion(appVersion);
		appConfig.setForceUpdateEnable(1);
		appConfig.setForceUpdateMessage(forceUpdateMessage);
		appConfig.setSystemMaintenance(0);
		List<OmatomeAppConfig> appConfigList = new ArrayList<>();
		appConfigList.add(appConfig);
		lenient().when(omatomeAppConfigRepository.findAll()).thenReturn(appConfigList);

		AppMetadataResponse appMetadataResponse= omatomeService.getAppMetadata();
		
		assertEquals(true, appMetadataResponse.isForceUpdate());
		assertEquals(forceUpdateMessage, appMetadataResponse.getForceUpdateMessage());
		assertEquals(appVersion, appMetadataResponse.getCurrentVersion());
		assertNull(appMetadataResponse.getMaintenanceMessage());
		assertEquals(false, appMetadataResponse.isSystemMaintenance());

	}

	@Test
	public void testMaintenanceMessage() {
		
		OmatomeAppConfig appConfig = new OmatomeAppConfig();
		String forceUpdateMessage = "Please update to latest app to continue using app";
		String maintenanceMessage = "System maintenace from 08:00 to 12:00";

		String appVersion ="1.0.0";
		appConfig.setCurrentVersion(appVersion);
		appConfig.setForceUpdateEnable(0);
		appConfig.setForceUpdateMessage(forceUpdateMessage);
		appConfig.setMaintenanceMessage(maintenanceMessage);
		appConfig.setSystemMaintenance(1);
		List<OmatomeAppConfig> appConfigList = new ArrayList<>();
		appConfigList.add(appConfig);
		lenient().when(omatomeAppConfigRepository.findAll()).thenReturn(appConfigList);

		AppMetadataResponse appMetadataResponse= omatomeService.getAppMetadata();
		
		assertEquals(false, appMetadataResponse.isForceUpdate());
		assertNull(appMetadataResponse.getForceUpdateMessage());
		assertEquals(appVersion, appMetadataResponse.getCurrentVersion());
		assertEquals(maintenanceMessage, appMetadataResponse.getMaintenanceMessage());
		assertEquals(true, appMetadataResponse.isSystemMaintenance());

	}

	@Test
	public void testEnableNotificationSettings() {
		String easyId = "EASY_ID1";
		String deviceId = "DEVICE_ID1";
		
		OmatomeUserEntity omatomeUserEntity = new OmatomeUserEntity();
		OmatomeUserEntityId omatomeUserEntityId = new OmatomeUserEntityId();
		omatomeUserEntityId.setDeviceId(deviceId);
		omatomeUserEntityId.setEasyId(easyId);
		
		Optional<OmatomeUserEntity> optional = Optional.of(omatomeUserEntity); 
		lenient().when(omatomeUserRepository.findById(omatomeUserEntityId)).thenReturn(optional);

		omatomeUserEntity.setOmatomeUserId(omatomeUserEntityId);
		omatomeUserEntity.setNotificationEnabled(1);
		
		omatomeService.updateNotificationSettings(easyId, deviceId,true);
		verify(omatomeUserRepository,times(1)).save(omatomeUserEntity);
		
	}
	@Test
	public void testDisableNotificationSettings() {
		String easyId = "EASY_ID1";
		String deviceId = "DEVICE_ID1";
		
		OmatomeUserEntity omatomeUserEntity = new OmatomeUserEntity();
		OmatomeUserEntityId omatomeUserEntityId = new OmatomeUserEntityId();
		omatomeUserEntityId.setDeviceId(deviceId);
		omatomeUserEntityId.setEasyId(easyId);
		
		Optional<OmatomeUserEntity> optional = Optional.of(omatomeUserEntity); 
		lenient().when(omatomeUserRepository.findById(omatomeUserEntityId)).thenReturn(optional);

		omatomeUserEntity.setOmatomeUserId(omatomeUserEntityId);
		omatomeUserEntity.setNotificationEnabled(0);
		
		omatomeService.updateNotificationSettings(easyId, deviceId,false);
		verify(omatomeUserRepository,times(1)).save(omatomeUserEntity);
		
	}
	
	@Test
	public void testMyMenuNotificationDisabled() {
		
		String easyId = "EASY_ID1";
		String deviceId = "DEVICE_ID1";
		String appVersion = "1.0.0";

		OmatomeUserEntity omatomeUserEntity = new OmatomeUserEntity();
		OmatomeUserEntityId omatomeUserEntityId = new OmatomeUserEntityId();
		omatomeUserEntityId.setDeviceId(deviceId);
		omatomeUserEntityId.setEasyId(easyId);
		omatomeUserEntity.setOmatomeUserId(omatomeUserEntityId);
		omatomeUserEntity.setAppVersion(appVersion);
		Optional<OmatomeUserEntity> optional = Optional.of(omatomeUserEntity);
		lenient().when(omatomeUserRepository.findById(omatomeUserEntityId)).thenReturn(optional);


		MyMenuResponse myMenuResponse= omatomeService.getMyMenu(easyId, deviceId);
		
		assertEquals(false, myMenuResponse.isNotificationEnabled());
		assertEquals(OmatomeConstants.APP_LIST_URL, myMenuResponse.getAppListUrl());
		assertEquals(OmatomeConstants.LICENSE_URL, myMenuResponse.getLicenseUrl());
		assertEquals(OmatomeConstants.PRIVACY_POLICY_URL, myMenuResponse.getPrivacyPolicyUrl());

	}
	
	@Test
	public void testMyMenuNotificationEnabled() {
		
		String easyId = "EASY_ID1";
		String deviceId = "DEVICE_ID1";
		String appVersion = "1.0.0";

		OmatomeUserEntity omatomeUserEntity = new OmatomeUserEntity();
		OmatomeUserEntityId omatomeUserEntityId = new OmatomeUserEntityId();
		omatomeUserEntityId.setDeviceId(deviceId);
		omatomeUserEntityId.setEasyId(easyId);
		omatomeUserEntity.setOmatomeUserId(omatomeUserEntityId);
		omatomeUserEntity.setNotificationEnabled(1);
		omatomeUserEntity.setAppVersion(appVersion);
		Optional<OmatomeUserEntity> optional = Optional.of(omatomeUserEntity);
		lenient().when(omatomeUserRepository.findById(omatomeUserEntityId)).thenReturn(optional);


		MyMenuResponse myMenuResponse= omatomeService.getMyMenu(easyId, deviceId);
		
		assertEquals(true, myMenuResponse.isNotificationEnabled());
		assertEquals(OmatomeConstants.APP_LIST_URL, myMenuResponse.getAppListUrl());
		assertEquals(OmatomeConstants.LICENSE_URL, myMenuResponse.getLicenseUrl());
		assertEquals(OmatomeConstants.PRIVACY_POLICY_URL, myMenuResponse.getPrivacyPolicyUrl());

	}
	
	
}
