package jp.co.rakuten.omatome.utils;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Collections;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

class EcoDeliverySlotCheckerTest {

  private EcoDeliverySlotChecker ecoDeliverySlotChecker;

  private String today;
  private String tomorrow;

  @BeforeEach
  void setUp() {
    LocalDate now = LocalDate.now();
    today = now.format(DateTimeFormatter.ofPattern("yyyyMMdd"));
    tomorrow = now.plusDays(1).format(DateTimeFormatter.ofPattern("yyyyMMdd"));

    ecoDeliverySlotChecker = new EcoDeliverySlotChecker(
      Collections.singletonList(now.getDayOfWeek().name()),
      Collections.singletonList("53"),
      Collections.singletonList(now.getDayOfWeek().name()),
      Collections.singletonList("53")
    );
  }

  @Test
  void shouldReturnTrueForEcoDateAndTimeForJP() {
    boolean result = ecoDeliverySlotChecker.isEligible(today, "53", "1003");
    assertTrue(result);
  }


  @Test
  void shouldReturnTrueForEcoDateAndTimeForRExpress() {
    boolean result = ecoDeliverySlotChecker.isEligible(today, "53", "1028");
    assertTrue(result);
  }

  @Test
  void shouldReturnFalseIfNotAnEcoDateAndTimeSlotForJP() {
    boolean result = ecoDeliverySlotChecker.isEligible(tomorrow, "53", "1003");
    assertFalse(result);
  }

  @Test
  void shouldReturnFalseIfNotAnEcoDateAndTimeSlotForRExpress() {
    boolean result = ecoDeliverySlotChecker.isEligible(tomorrow, "53", "1028");
    assertFalse(result);
  }

}