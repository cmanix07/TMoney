package jp.co.rakuten.omatome.controller;


import static org.junit.jupiter.api.Assertions.assertEquals;

import java.net.URI;

import org.junit.jupiter.api.Test;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.util.UriComponentsBuilder;

import jp.co.rakuten.omatome.response.AppMetadataResponse;


public class GetMetadataApiTest extends BaseControllerTest{

	@Test
	public void myMenuApiTest() {
		
		httpRequestEntity = new HttpEntity<>(headers);
		String getMetaDataApiUrl = baseUrl + "/app-metadata";
		UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(getMetaDataApiUrl);
		URI requestUri = builder.build().encode().toUri();
 		ResponseEntity<AppMetadataResponse> response = template.exchange(requestUri, HttpMethod.GET, httpRequestEntity, AppMetadataResponse.class);
		
		assertEquals(HttpStatus.OK,response.getStatusCode());
		assertEquals("1.0.0",response.getBody().getCurrentVersion());
		assertEquals(false,response.getBody().isForceUpdate());
		
	}
	
}
