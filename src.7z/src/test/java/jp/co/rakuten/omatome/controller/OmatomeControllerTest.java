package jp.co.rakuten.omatome.controller;

import static java.util.Collections.emptyList;
import static java.util.Collections.singletonList;
import static jp.co.rakuten.omatome.controller.OmatomeController.API_PATH;
import static jp.co.rakuten.omatome.utils.OmatomeConstants.POINTS_PER_TRACKING_NUMBER;
import static jp.co.rakuten.omatome.utils.OmatomeConstants.REDELIVERY_REQUEST;
import static org.mockito.ArgumentMatchers.anyBoolean;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.atMostOnce;
import static org.mockito.Mockito.lenient;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.setup.MockMvcBuilders.standaloneSetup;

import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.platform.runner.JUnitPlatform;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.ResultActions;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.collect.ImmutableList;

import jp.co.rakuten.omatome.exception.JapanPostProcessingException;
import jp.co.rakuten.omatome.model.DateTimeSlot;
import jp.co.rakuten.omatome.model.TimeSlotCode;
import jp.co.rakuten.omatome.model.TrackingInfo;
import jp.co.rakuten.omatome.request.AvailableDeliveryDateRequest;
import jp.co.rakuten.omatome.request.ModifyDeliveryRequest;
import jp.co.rakuten.omatome.response.AvailableDeliveryDatesResponse;
import jp.co.rakuten.omatome.response.DeliveryChangeResponse;
import jp.co.rakuten.omatome.response.TimeSlot;
import jp.co.rakuten.omatome.service.DeliveryModificationService;
import jp.co.rakuten.omatome.service.OmatomeService;
import jp.co.rakuten.omatome.service.PointAllocationHistoryService;
import jp.co.rakuten.omatome.service.japanpost.JapanPostService;
import jp.co.rakuten.omatome.utils.EasyIdService;

@ExtendWith(MockitoExtension.class)
@RunWith(JUnitPlatform.class)
class OmatomeControllerTest {
  public static final String CONTACT_NUMBER = "01234567890";
  public static final String COMPANY_NUMBER = "1003";
  private final ObjectMapper objectMapper = new ObjectMapper();
  private MockMvc mockMvc;

  @Mock
  private OmatomeService omatomeService;
  @Mock
  private PointAllocationHistoryService pointAllocationHistoryService;
  @Mock
  private DeliveryModificationService deliveryModificationService;
  
  @Mock
  private EasyIdService easyIdService;
  
  @Mock
  private JapanPostService japanPostService;

  private AvailableDeliveryDatesResponse response;


  @BeforeEach
  void setUp() {
    mockMvc = standaloneSetup(
      new OmatomeController(
        omatomeService, deliveryModificationService,
        easyIdService, pointAllocationHistoryService))
      .setControllerAdvice(new ApplicationErrorController())
      .build();

    LinkedHashMap<String, List<TimeSlot>> availableDates = new LinkedHashMap<>();
    List<TimeSlot> timeSlots = new LinkedList<>();
    timeSlots.add(new TimeSlot("00", TimeSlotCode.getDescriptionFor("00"), false));
    timeSlots.add(new TimeSlot("53", TimeSlotCode.getDescriptionFor("53"), true));
    timeSlots.add(new TimeSlot("56", TimeSlotCode.getDescriptionFor("56"), false));
    availableDates.put("20200930", timeSlots);
    availableDates.put("20201001", timeSlots);


    DateTimeSlot dateTimeSlot1 = new DateTimeSlot("20200930", true, timeSlots);
    DateTimeSlot dateTimeSlot2 = new DateTimeSlot("20201001", true, timeSlots);


    response = new AvailableDeliveryDatesResponse(ImmutableList.of(dateTimeSlot1, dateTimeSlot2));
    lenient().when(deliveryModificationService.availableDates(anyList(), anyString())).thenReturn(availableDates);
  }


  @Test
  void shouldGetEasyIdFromHeaderDuringGetOrder() throws Exception {
    String raeToken = "hgjklkkhbudufidfnkd";
    when(easyIdService.getEasyId(raeToken)).thenReturn("easyId");

    ResultActions perform = mockMvc.perform(MockMvcRequestBuilders
      .get(API_PATH + "/myOrders")
      .header("RAE_ACCESS_TOKEN", raeToken)
      .param("companyNumber", "1003"));
    perform
      .andExpect(MockMvcResultMatchers.status().isOk());

    Mockito.verify(omatomeService, times(1))
      .fetchMyOrders("easyId", singletonList("1003"));

    Mockito.verify(easyIdService, times(1)).getEasyId(raeToken);
  }

  @Test
  void shouldHandleErrorDuringGetEasyIdFromHeaderDuringGetOrder() throws Exception {
    String raeToken = "hgjklkkhbudufidfnkd";
    when(easyIdService.getEasyId(raeToken)).thenThrow(NullPointerException.class);

    ResultActions perform = mockMvc.perform(MockMvcRequestBuilders
      .get(API_PATH + "/myOrders")
      .header("RAE_ACCESS_TOKEN", raeToken)
      .param("companyNumber", "1003"));
    perform
      .andExpect(MockMvcResultMatchers.status().is5xxServerError());


    Mockito.verify(omatomeService, never())
      .fetchMyOrders("easyId", singletonList("1003"));

    Mockito.verify(easyIdService, times(1)).getEasyId(raeToken);
  }

  @Test
  void shouldGetEasyIdFromHeaderDuringRegister() throws Exception {
    String raeToken = "hgjklkkhbudufidfnkd";
    when(easyIdService.getEasyId(raeToken)).thenReturn("easyId");

    ResultActions perform = mockMvc.perform(MockMvcRequestBuilders
      .post(API_PATH + "/register")
      .header("RAE_ACCESS_TOKEN", raeToken)
      .header("DEVICE_ID", "deviceId")
      .header("APP_VERSION", "1.0.0"));

    perform
      .andExpect(MockMvcResultMatchers.status().isOk());

    Mockito.verify(omatomeService, times(1))
      .register("easyId", "deviceId","1.0.0");

    Mockito.verify(easyIdService, times(1)).getEasyId(raeToken);
  }

  @Test
  void shouldHandleErrorDuringGetEasyIdFromHeaderDuringRegister() throws Exception {
    String raeToken = "hgjklkkhbudufidfnkd";
    when(easyIdService.getEasyId(raeToken)).thenThrow(NullPointerException.class);

    ResultActions perform = mockMvc.perform(MockMvcRequestBuilders
      .post(API_PATH + "/register")
      .header("RAE_ACCESS_TOKEN", raeToken)
      .header("DEVICE_ID", "deviceId")
      .header("APP_VERSION", "1.0.0"));

    perform
      .andExpect(MockMvcResultMatchers.status().is5xxServerError());

    Mockito.verify(omatomeService, never())
      .register("easyId", "deviceId","1.0.0");

    Mockito.verify(easyIdService, times(1)).getEasyId(raeToken);
  }

  @Test
  void shouldCallJPAPIToGetPossibleDeliveryDateAndTime() throws Exception {
    TrackingInfo trackingInfo = new TrackingInfo("1234567890", REDELIVERY_REQUEST,
      POINTS_PER_TRACKING_NUMBER, singletonList("item"),null);

    ResultActions perform = mockMvc.perform(MockMvcRequestBuilders
      .post(API_PATH + "/available-dates")
      .content(objectMapper.writeValueAsString(
        new AvailableDeliveryDateRequest(singletonList(trackingInfo), "1003")))
      .contentType("application/json"));
    perform
      .andExpect(MockMvcResultMatchers.status().isOk())
      .andExpect(content().json(objectMapper.writeValueAsString(response)));

    verify(deliveryModificationService, atMostOnce()).availableDates(singletonList(trackingInfo), "1003");
  }

  @Test
  void shouldHandleExceptionsForAvailableDates() throws Exception {
    when(deliveryModificationService.availableDates(anyList(), anyString()))
      .thenThrow(JapanPostProcessingException.class);

    ResultActions perform = mockMvc.perform(MockMvcRequestBuilders
      .post(API_PATH + "/available-dates")
      .content(objectMapper.writeValueAsString(
        new AvailableDeliveryDateRequest(singletonList(new TrackingInfo("1234567890", REDELIVERY_REQUEST,
          POINTS_PER_TRACKING_NUMBER, singletonList("item"),null)), "1003")))
      .contentType("application/json"));
    perform
      .andExpect(MockMvcResultMatchers.status().isOk())
      .andExpect(content().json(objectMapper.writeValueAsString(new AvailableDeliveryDatesResponse(emptyList()))));
  }

  @Test
  void shouldCallJPAPIToChangeDeliveryDateAndTime() throws Exception {
    String date = "date";
    String timeSlotCode = "53";
    List<TrackingInfo> trackingInfoList = singletonList(new TrackingInfo("1234567890", REDELIVERY_REQUEST,
      POINTS_PER_TRACKING_NUMBER, singletonList("item"),null));
    HashMap<String, List<TrackingInfo>> result = new HashMap<>();
    result.put("SUCCESS", trackingInfoList);
    result.put("FAILURE", Collections.emptyList());
    DeliveryChangeResponse deliveryChangeResponse =
      new DeliveryChangeResponse("id", result, 10,
        date, timeSlotCode, TimeSlotCode.getDescriptionFor(timeSlotCode), true);
    when(deliveryModificationService
      .modifyDelivery(anyList(), anyString(), anyString(), anyString(), anyString(), anyBoolean()))
      .thenReturn(deliveryChangeResponse);
    String raeToken = "hgjklkkhbudufidfnkd";
    when(easyIdService.getEasyId(raeToken)).thenReturn("12345");
    
    ResultActions perform = mockMvc.perform(MockMvcRequestBuilders
      .post(API_PATH + "/delivery-change")
      .header("RAE_ACCESS_TOKEN", raeToken)
      .content(objectMapper.writeValueAsString(
        new ModifyDeliveryRequest(trackingInfoList, date, timeSlotCode, COMPANY_NUMBER, true)))
      .contentType("application/json"));
    perform
      .andExpect(MockMvcResultMatchers.status().isAccepted())
      .andExpect(content().json(objectMapper.writeValueAsString(deliveryChangeResponse)));

    verify(deliveryModificationService, atMostOnce())
      .modifyDelivery(trackingInfoList, date, timeSlotCode, "", COMPANY_NUMBER, true);
  }
  
  @Test
  void shouldCallJPAPIToChangeDeliveryDateAndTime1() throws Exception {
    String date = "20200715";
    String timeSlotCode = "53";
    LinkedList<TrackingInfo> trackingInfoList = new LinkedList<>();
    LinkedList<TrackingInfo> successTrackingInfoList = new LinkedList<>();
    LinkedList<TrackingInfo> failedTrackingInfoList = new LinkedList<>();
    
    TrackingInfo trackingInfo1 = new TrackingInfo("1234567890", REDELIVERY_REQUEST, POINTS_PER_TRACKING_NUMBER, singletonList("item"),null);
    TrackingInfo trackingInfo2 = new TrackingInfo("1234567891", REDELIVERY_REQUEST, POINTS_PER_TRACKING_NUMBER, singletonList("item"),null);
    TrackingInfo trackingInfo3 = new TrackingInfo("1234567892", REDELIVERY_REQUEST, POINTS_PER_TRACKING_NUMBER, singletonList("item"),null);
    trackingInfoList.add(trackingInfo1);
    trackingInfoList.add(trackingInfo2);
    trackingInfoList.add(trackingInfo3);
    successTrackingInfoList.add(trackingInfo1);
    successTrackingInfoList.add(trackingInfo2);
    failedTrackingInfoList.add(trackingInfo3);
    
    HashMap<String, List<TrackingInfo>> result = new HashMap<>();
    result.put("SUCCESS", successTrackingInfoList);
    result.put("FAILURE", failedTrackingInfoList);
    DeliveryChangeResponse deliveryChangeResponse =
      new DeliveryChangeResponse("id", result, 10,
        date, timeSlotCode, TimeSlotCode.getDescriptionFor(timeSlotCode), true);

    when(deliveryModificationService
        .modifyDelivery(trackingInfoList, date, timeSlotCode, CONTACT_NUMBER, COMPANY_NUMBER, true))
        .thenReturn(deliveryChangeResponse);

    ResultActions perform = mockMvc.perform(MockMvcRequestBuilders
      .post(API_PATH + "/delivery-change")
      .content(objectMapper.writeValueAsString(
        new ModifyDeliveryRequest(trackingInfoList, date, timeSlotCode, COMPANY_NUMBER, true)))
      .contentType("application/json"));
    
     perform
      .andExpect(MockMvcResultMatchers.status().isAccepted());
     perform.andExpect(content().json(objectMapper.writeValueAsString(deliveryChangeResponse)));
    verify(deliveryModificationService, atMostOnce())
      .modifyDelivery(trackingInfoList, date, timeSlotCode, CONTACT_NUMBER, COMPANY_NUMBER, true);
  }
  
}