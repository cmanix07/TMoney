package jp.co.rakuten.omatome.e2e;

import static java.util.Collections.singletonList;
import static jp.co.rakuten.omatome.utils.OmatomeConstants.DATE_CHANGE_REQUEST;
import static jp.co.rakuten.omatome.utils.OmatomeConstants.POINTS_PER_TRACKING_NUMBER;
import static jp.co.rakuten.omatome.utils.OmatomeConstants.REDELIVERY_REQUEST;
import static org.junit.Assert.assertFalse;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.when;

import java.time.LocalDate;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;

import jp.co.rakuten.omatome.controller.OmatomeController;
import jp.co.rakuten.omatome.entity.DeliveryChangeEntity;
import jp.co.rakuten.omatome.entity.DeliveryChangePointEntity;
import jp.co.rakuten.omatome.model.TrackingInfo;
import jp.co.rakuten.omatome.repository.DeliveryChangePointsRepository;
import jp.co.rakuten.omatome.repository.DeliveryChangeRepository;
import jp.co.rakuten.omatome.response.DeliveryChangeResponse;
import jp.co.rakuten.omatome.service.DeliveryModificationService;
import jp.co.rakuten.omatome.service.japanpost.JapanPostService;
import jp.co.rakuten.omatome.utils.DateUtil;
import jp.co.rakuten.omatome.utils.EcoDeliverySlotChecker;
import jp.co.rakuten.omatome.utils.IdGenerator;

public class DeliveryModificationServiceE2E extends BaseE2ETest{
  public static final String CONTACT_NUMBER = "01234567890";
  public static final String COMPANY_NUMBER = "1003";

  @Mock
  private JapanPostService japanPostService;

  @Autowired
  OmatomeController omatomeController;

  OmatomeController spyOmatomeController;

  @Autowired
  private DeliveryChangeRepository deliveryChangeRepository;

  @Autowired
  private DeliveryChangePointsRepository deliveryChangePointsRepository;
  @Mock
  private IdGenerator idGenerator;
  @Mock
  private EcoDeliverySlotChecker ecoDeliverySlotChecker;

  private DeliveryModificationService deliveryModificationService;


  @BeforeEach
  public void setUp() {
    deliveryModificationService = new DeliveryModificationService(
        japanPostService,
        deliveryChangeRepository,
        deliveryChangePointsRepository,
        idGenerator, ecoDeliverySlotChecker);
  }


  /**
   * Existing Omatome with new request which has different delivery date.
   */
  @Test
  void ShouldOmatomeWithDateChangeRequestFailedAndSuccessDeliveryCompleted() throws Exception {
    String date = "20200716";
    String timeSlotCode = "53";
    when(idGenerator.generate()).thenReturn("delivery-change-id");

    LinkedList<TrackingInfo> trackingInfoList = new LinkedList<>();
    LinkedList<TrackingInfo> successTrackingInfoList = new LinkedList<>();
    LinkedList<TrackingInfo> failedTrackingInfoList = new LinkedList<>();

    TrackingInfo trackingInfo1 = new TrackingInfo("12345678901", DATE_CHANGE_REQUEST,
        POINTS_PER_TRACKING_NUMBER, singletonList("item"),"changeId_01");
    TrackingInfo trackingInfo2 = new TrackingInfo("12345678902", DATE_CHANGE_REQUEST,
        POINTS_PER_TRACKING_NUMBER, singletonList("item"),"changeId_01");
    TrackingInfo trackingInfo3 = new TrackingInfo("12345678991", REDELIVERY_REQUEST,
        POINTS_PER_TRACKING_NUMBER, singletonList("item"),null);
    TrackingInfo trackingInfo4 = new TrackingInfo("12345678992", REDELIVERY_REQUEST,
        POINTS_PER_TRACKING_NUMBER, singletonList("item"),null);
    TrackingInfo trackingInfo5 = new TrackingInfo("12345678993", REDELIVERY_REQUEST,
        POINTS_PER_TRACKING_NUMBER, singletonList("item"),null);

    successTrackingInfoList.add(trackingInfo1);
    successTrackingInfoList.add(trackingInfo2);
    successTrackingInfoList.add(trackingInfo3);
    successTrackingInfoList.add(trackingInfo4);

    failedTrackingInfoList.add(trackingInfo5);

    trackingInfoList.add(trackingInfo1);
    trackingInfoList.add(trackingInfo2);
    trackingInfoList.add(trackingInfo3);
    trackingInfoList.add(trackingInfo4);
    trackingInfoList.add(trackingInfo5);

    //Request delivery Change Id whose date is different 
    HashMap<String, List<TrackingInfo>> result = new HashMap<>();
    result.put("SUCCESS", successTrackingInfoList);
    result.put("FAILURE", failedTrackingInfoList);

    when(japanPostService.updateDelivery(trackingInfoList, "20200716", "53",
        CONTACT_NUMBER)).thenReturn(result);

    DeliveryChangeResponse deliveryChangeResponse = deliveryModificationService.modifyDelivery(trackingInfoList, date, timeSlotCode, CONTACT_NUMBER, COMPANY_NUMBER, true);

    assertEquals("delivery-change-id", deliveryChangeResponse.getChangeId());
    assertEquals(20, deliveryChangeResponse.getRewardedPoint());
    assertEquals(2, deliveryChangeResponse.getChangeStatus().size());
    assertEquals(4, deliveryChangeResponse.getChangeStatus().get("SUCCESS").size());
    assertEquals(1, deliveryChangeResponse.getChangeStatus().get("FAILURE").size());

    Optional<DeliveryChangePointEntity> deliveryChangePointOptional = deliveryChangePointsRepository.findById("changeId_01");
    assertFalse(deliveryChangePointOptional.isPresent());

  }
  
  /**
   * Existing Omatome with new request which has different delivery date where one tracking number failed to change the date.
   */
  @Test
  void ShouldOmatomeWithDateChangeRequestFailedOneExistingRecordsAndSuccessDeliveryCompleted() throws Exception {
    String date = "20200716";
    String timeSlotCode = "53";
    when(idGenerator.generate()).thenReturn("delivery-change-id");

    LinkedList<TrackingInfo> trackingInfoList = new LinkedList<>();
    LinkedList<TrackingInfo> successTrackingInfoList = new LinkedList<>();
    LinkedList<TrackingInfo> failedTrackingInfoList = new LinkedList<>();

    TrackingInfo trackingInfo1 = new TrackingInfo("12345678904", DATE_CHANGE_REQUEST,
        POINTS_PER_TRACKING_NUMBER, singletonList("item"),"changeId_03");
    TrackingInfo trackingInfo2 = new TrackingInfo("12345678905", DATE_CHANGE_REQUEST,
        POINTS_PER_TRACKING_NUMBER, singletonList("item"),"changeId_03");
    TrackingInfo trackingInfo3 = new TrackingInfo("12345678991", REDELIVERY_REQUEST,
        POINTS_PER_TRACKING_NUMBER, singletonList("item"),null);
    TrackingInfo trackingInfo4 = new TrackingInfo("12345678992", REDELIVERY_REQUEST,
        POINTS_PER_TRACKING_NUMBER, singletonList("item"),null);
    TrackingInfo trackingInfo5 = new TrackingInfo("12345678993", REDELIVERY_REQUEST,
        POINTS_PER_TRACKING_NUMBER, singletonList("item"),null);

    successTrackingInfoList.add(trackingInfo1);
    successTrackingInfoList.add(trackingInfo3);
    successTrackingInfoList.add(trackingInfo4);

    failedTrackingInfoList.add(trackingInfo2);
    failedTrackingInfoList.add(trackingInfo5);

    trackingInfoList.add(trackingInfo1);
    trackingInfoList.add(trackingInfo2);
    trackingInfoList.add(trackingInfo3);
    trackingInfoList.add(trackingInfo4);
    trackingInfoList.add(trackingInfo5);

    //Request delivery Change Id whose date is different 
    HashMap<String, List<TrackingInfo>> result = new HashMap<>();
    result.put("SUCCESS", successTrackingInfoList);
    result.put("FAILURE", failedTrackingInfoList);

    when(japanPostService.updateDelivery(trackingInfoList, "20200716", "53",
        CONTACT_NUMBER)).thenReturn(result);

    DeliveryChangeResponse deliveryChangeResponse = deliveryModificationService.modifyDelivery(trackingInfoList, date, timeSlotCode, CONTACT_NUMBER, COMPANY_NUMBER, true);

    assertEquals("delivery-change-id", deliveryChangeResponse.getChangeId());
    assertEquals(20, deliveryChangeResponse.getRewardedPoint());
    assertEquals(2, deliveryChangeResponse.getChangeStatus().size());
    assertEquals(3, deliveryChangeResponse.getChangeStatus().get("SUCCESS").size());
    assertEquals(2, deliveryChangeResponse.getChangeStatus().get("FAILURE").size());

    Optional<DeliveryChangePointEntity> deliveryChangePointOptional = deliveryChangePointsRepository.findById("changeId_03");
    assertTrue(deliveryChangePointOptional.isPresent());
    assertEquals("changeId_03", deliveryChangePointOptional.get().getChangeId());
    assertEquals(0, deliveryChangePointOptional.get().getPoint());

  }

  /**
   * Existing Omatome with new request which has delivery date same corresponding to existing
   */
  @Test
  void ShouldOmatomeWithMatchingDateRequestFailedAndSuccessDeliveryCompleted() throws Exception {
    String timeSlotCode = "53";
    when(idGenerator.generate()).thenReturn("delivery-change-id");

    LinkedList<TrackingInfo> trackingInfoList = new LinkedList<>();
    LinkedList<TrackingInfo> successTrackingInfoList = new LinkedList<>();
    LinkedList<TrackingInfo> failedTrackingInfoList = new LinkedList<>();
    LinkedList<TrackingInfo> newTrackingInfoList = new LinkedList<>();

    TrackingInfo trackingInfo1 = new TrackingInfo("12345678906", REDELIVERY_REQUEST,
        POINTS_PER_TRACKING_NUMBER, singletonList("item"),"changeId_04");
    TrackingInfo trackingInfo2 = new TrackingInfo("12345678907", REDELIVERY_REQUEST,
        POINTS_PER_TRACKING_NUMBER, singletonList("item"),"changeId_04");
    TrackingInfo trackingInfo3 = new TrackingInfo("12345678991", REDELIVERY_REQUEST,
        POINTS_PER_TRACKING_NUMBER, singletonList("item"),null);
    TrackingInfo trackingInfo4 = new TrackingInfo("12345678992", REDELIVERY_REQUEST,
        POINTS_PER_TRACKING_NUMBER, singletonList("item"),null);
    TrackingInfo trackingInfo5 = new TrackingInfo("12345678993", REDELIVERY_REQUEST,
        POINTS_PER_TRACKING_NUMBER, singletonList("item"),null);

    successTrackingInfoList.add(trackingInfo3);
    successTrackingInfoList.add(trackingInfo4);

    failedTrackingInfoList.add(trackingInfo5);

    trackingInfoList.add(trackingInfo1);
    trackingInfoList.add(trackingInfo2);
    trackingInfoList.add(trackingInfo3);
    trackingInfoList.add(trackingInfo4);
    trackingInfoList.add(trackingInfo5);

    newTrackingInfoList.add(trackingInfo3);
    newTrackingInfoList.add(trackingInfo4);
    newTrackingInfoList.add(trackingInfo5);

    //Request delivery Change Id whose date is different 
    HashMap<String, List<TrackingInfo>> result = new HashMap<>();
    result.put("SUCCESS", successTrackingInfoList);
    result.put("FAILURE", failedTrackingInfoList);

    when(japanPostService.updateDelivery(newTrackingInfoList, DateUtil.format(LocalDate.now()), "53",
        CONTACT_NUMBER)).thenReturn(result);

    DeliveryChangeResponse deliveryChangeResponse = deliveryModificationService.modifyDelivery(trackingInfoList, DateUtil.format(LocalDate.now()), timeSlotCode, CONTACT_NUMBER, COMPANY_NUMBER, true);

    assertEquals("delivery-change-id", deliveryChangeResponse.getChangeId());
    assertEquals(40, deliveryChangeResponse.getRewardedPoint());
    assertEquals(2, deliveryChangeResponse.getChangeStatus().size());
    assertEquals(2, deliveryChangeResponse.getChangeStatus().get("SUCCESS").size());
    assertEquals(1, deliveryChangeResponse.getChangeStatus().get("FAILURE").size());

    Optional<DeliveryChangePointEntity> deliveryChangePointOptional = deliveryChangePointsRepository.findById("changeId_01");
    assertFalse(deliveryChangePointOptional.isPresent());

  }
  
  @Test
  public void testDB() {
    List<DeliveryChangeEntity> deliveryList = deliveryChangeRepository.findAll();
    
    for (DeliveryChangeEntity deliveryChangeEntity : deliveryList) {
      System.out.println(deliveryChangeEntity.getDeliveryChangeId());
      System.out.println(deliveryChangeEntity.getId().getTrackingNumber());
    }
  }

}

