package jp.co.rakuten.omatome.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.lenient;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import jp.co.rakuten.omatome.entity.PointAllocationHistoryEntity;
import jp.co.rakuten.omatome.repository.PointAllocationHistoryRepository;
import jp.co.rakuten.omatome.response.PointAllocationHistoryResponseDTO;
import jp.co.rakuten.omatome.response.PointAllocationInfo;
import jp.co.rakuten.omatome.utils.OmatomeConstants;

@ExtendWith(MockitoExtension.class)
public class PointAllocationHistoryServiceTest {
	
	@InjectMocks
	PointAllocationHistoryService pointAllocationHistoryService;
	
	@Mock
	PointAllocationHistoryRepository pointAllocationHistoryRepository;
	
	@Test
	public void testPointHistoryWithAnnotationFlagTrue() {
		Long easyId = 1l;
		LocalDate date = LocalDate.now().minusDays(OmatomeConstants.NUMBER_OF_DAYS_DATA);
		List<PointAllocationHistoryEntity> pointAllocationHistoryList = new ArrayList<>();
		LocalDateTime pointGrantDate = LocalDateTime.now().minusDays(5);
		LocalDate formattedPointGrantDate = LocalDate.now().minusDays(5);
		String expectedPointGrantDate = formattedPointGrantDate.format(DateTimeFormatter.ofPattern("yyyy/MM/dd"));
		PointAllocationHistoryEntity pointAllocationHistory = createPointAllocationHistory
				("1", "4001", "1028", "4002",
						10, 1, 1,pointGrantDate);
		pointAllocationHistoryList.add(pointAllocationHistory);
		lenient().when(pointAllocationHistoryRepository.findByEasyId(easyId,date)).thenReturn(pointAllocationHistoryList);
		
		PointAllocationHistoryResponseDTO actualPointAllocationHistoryResponseDTO = pointAllocationHistoryService.fetchPointAllocationHistory(easyId);

		PointAllocationInfo pointAllocationInfo= actualPointAllocationHistoryResponseDTO.getPointHistoryList().get(0);
		assertEquals("4001", pointAllocationInfo.getTrackingNumber());
		assertEquals("1028", pointAllocationInfo.getCompanyNumber());
		assertEquals("4002", pointAllocationInfo.getPointNotAllocatedTrackingNumber());
		assertEquals(10, pointAllocationInfo.getPoints());
		assertEquals(true, pointAllocationInfo.isAnnotationFlag());
		assertEquals(expectedPointGrantDate, pointAllocationInfo.getPointGrantDate());

		
	}
	@Test
	public void testPointHistoryWithAnnotationFlagFalse() {
		Long easyId = 1l;
		LocalDate date = LocalDate.now().minusDays(OmatomeConstants.NUMBER_OF_DAYS_DATA);
		List<PointAllocationHistoryEntity> pointAllocationHistoryList = new ArrayList<>();
		LocalDateTime pointGrantDate = LocalDateTime.now().minusDays(5);
		LocalDate formattedPointGrantDate = LocalDate.now().minusDays(5);
		String expectedPointGrantDate = formattedPointGrantDate.format(DateTimeFormatter.ofPattern("yyyy/MM/dd"));
		PointAllocationHistoryEntity pointAllocationHistory = createPointAllocationHistory
				("1", "4001", "1028", null,
						0, 0, 1,pointGrantDate);
		pointAllocationHistoryList.add(pointAllocationHistory);
		lenient().when(pointAllocationHistoryRepository.findByEasyId(easyId,date)).thenReturn(pointAllocationHistoryList);
		
		PointAllocationHistoryResponseDTO actualPointAllocationHistoryResponseDTO = pointAllocationHistoryService.fetchPointAllocationHistory(easyId);

		PointAllocationInfo pointAllocationInfo= actualPointAllocationHistoryResponseDTO.getPointHistoryList().get(0);
		assertEquals("4001", pointAllocationInfo.getTrackingNumber());
		assertEquals("1028", pointAllocationInfo.getCompanyNumber());
		assertEquals(null, pointAllocationInfo.getPointNotAllocatedTrackingNumber());
		assertEquals(0, pointAllocationInfo.getPoints());
		assertEquals(false, pointAllocationInfo.isAnnotationFlag());
		assertEquals(expectedPointGrantDate, pointAllocationInfo.getPointGrantDate());

		
	}
	
	
	@Test
	public void testPointHistoryWithMultipleRecords() {
		Long easyId = 1l;
		LocalDate date = LocalDate.now().minusDays(OmatomeConstants.NUMBER_OF_DAYS_DATA);
		List<PointAllocationHistoryEntity> pointAllocationHistoryList = new ArrayList<>();
		LocalDateTime pointGrantDate = LocalDateTime.now().minusDays(5);
		LocalDate formattedPointGrantDate = LocalDate.now().minusDays(5);
		String expectedPointGrantDate = formattedPointGrantDate.format(DateTimeFormatter.ofPattern("yyyy/MM/dd"));
		PointAllocationHistoryEntity pointAllocationHistory = createPointAllocationHistory
				("1", "4001", "1028", "4002",
						10, 1, 1,pointGrantDate);
		pointAllocationHistoryList.add(pointAllocationHistory);
		
		LocalDateTime pointGrantDate1 = LocalDateTime.now().minusDays(2);
		LocalDate formattedPointGrantDate1 = LocalDate.now().minusDays(2);
		String expectedPointGrantDate1 = formattedPointGrantDate1.format(DateTimeFormatter.ofPattern("yyyy/MM/dd"));
		
		pointAllocationHistory = createPointAllocationHistory
				("1", "4003", "1028", null,
						0, 0, 1,pointGrantDate1);
		pointAllocationHistoryList.add(pointAllocationHistory);
		lenient().when(pointAllocationHistoryRepository.findByEasyId(easyId,date)).thenReturn(pointAllocationHistoryList);
		
		PointAllocationHistoryResponseDTO actualPointAllocationHistoryResponseDTO = pointAllocationHistoryService.fetchPointAllocationHistory(easyId);

		PointAllocationInfo pointAllocationInfo= actualPointAllocationHistoryResponseDTO.getPointHistoryList().get(0);
		assertEquals("4001", pointAllocationInfo.getTrackingNumber());
		assertEquals("1028", pointAllocationInfo.getCompanyNumber());
		assertEquals("4002", pointAllocationInfo.getPointNotAllocatedTrackingNumber());
		assertEquals(10, pointAllocationInfo.getPoints());
		assertEquals(true, pointAllocationInfo.isAnnotationFlag());
		assertEquals(expectedPointGrantDate, pointAllocationInfo.getPointGrantDate());

		pointAllocationInfo= actualPointAllocationHistoryResponseDTO.getPointHistoryList().get(1);
		assertEquals("4003", pointAllocationInfo.getTrackingNumber());
		assertEquals("1028", pointAllocationInfo.getCompanyNumber());
		assertEquals(null, pointAllocationInfo.getPointNotAllocatedTrackingNumber());
		assertEquals(0, pointAllocationInfo.getPoints());
		assertEquals(false, pointAllocationInfo.isAnnotationFlag());
		assertEquals(expectedPointGrantDate1, pointAllocationInfo.getPointGrantDate());

		
	}
	
	public PointAllocationHistoryEntity createPointAllocationHistory(String changeRequestId,
			String trackingNumber,String companyNumber,String pointNotAllocatedTrackingNumber,Integer points,
			Integer annotationFlag,Integer pointAllocatedFlag,LocalDateTime pointGrantDate) {
		PointAllocationHistoryEntity pointAllocationHistory = new PointAllocationHistoryEntity();
		pointAllocationHistory.setChangeRequestId(changeRequestId);
		pointAllocationHistory.setAnnotationFlag(annotationFlag);
		pointAllocationHistory.setCompanyNumber(companyNumber);
		pointAllocationHistory.setPointNotAllocatedTrackingNumber(pointNotAllocatedTrackingNumber);
		pointAllocationHistory.setTrackingNumber(trackingNumber);
		pointAllocationHistory.setPoint(points);
		pointAllocationHistory.setChangeTimestamp(pointGrantDate);
		return pointAllocationHistory;
	}

}
