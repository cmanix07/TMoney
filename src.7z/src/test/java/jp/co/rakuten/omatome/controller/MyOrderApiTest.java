package jp.co.rakuten.omatome.controller;


import static org.assertj.core.api.Assertions.assertThat;

import java.net.URI;
import java.util.List;
import java.util.stream.Collectors;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.util.UriComponentsBuilder;

import jp.co.rakuten.omatome.response.MyOrderResponseDTO;
import jp.co.rakuten.omatome.response.OrderInfo;
import jp.co.rakuten.omatome.response.ShippingList;
import jp.co.rakuten.omatome.response.TrackingNumberDetails;
import jp.co.rakuten.omatome.utils.OmatomeConstants;

public class MyOrderApiTest extends BaseControllerTest{
	
	@BeforeAll
	public void init() {
		httpRequestEntity = new HttpEntity<>(headers);
	}

	@Test
	public void myOrdersJPTest() {
		UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(myOrderApiUrl);
		builder.queryParam("companyNumber", "1003");
		URI requestUri = builder.build().encode().toUri();
 		ResponseEntity<MyOrderResponseDTO> response = template.exchange(requestUri, HttpMethod.GET, httpRequestEntity, MyOrderResponseDTO.class);
		
		assertThat(response.getStatusCode()).isEqualTo(HttpStatus.OK);
		assertThat(response.getBody().getResponseCode()).isEqualTo(OmatomeConstants.SUCCESS_RESPONSE_CODE);
		OrderInfo jpOrderInfo = new OrderInfo();
		jpOrderInfo.setOrderNumber("1003");
		assertThat(getOrderNumberResult(response, jpOrderInfo)).isTrue();
		
		OrderInfo expressOrderInfo = new OrderInfo();
		expressOrderInfo.setOrderNumber("4001");
		assertThat(getOrderNumberResult(response, expressOrderInfo)).isFalse();

	}
	
	@Test
	public void myOrdersJPAndExpressTest() throws Exception {

		UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(myOrderApiUrl);
		builder.queryParam("companyNumber", "1003,1028");
		URI requestUri = builder.build().encode().toUri();
 		ResponseEntity<MyOrderResponseDTO> response = template.exchange(requestUri, HttpMethod.GET, httpRequestEntity, MyOrderResponseDTO.class);
		
		assertThat(response.getStatusCode()).isEqualTo(HttpStatus.OK);
		assertThat(response.getBody().getResponseCode()).isEqualTo(OmatomeConstants.SUCCESS_RESPONSE_CODE);
		OrderInfo jpOrderInfo = new OrderInfo();
		jpOrderInfo.setOrderNumber("1003");
		assertThat(getOrderNumberResult(response, jpOrderInfo)).isTrue();
		
		OrderInfo expressOrderInfo = new OrderInfo();
		expressOrderInfo.setOrderNumber("4001");
		assertThat(getOrderNumberResult(response, expressOrderInfo)).isTrue();

	}
	
	@Test
	public void myOrdersExpressTest() throws Exception {

		UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(myOrderApiUrl);
		builder.queryParam("companyNumber", "1028");
		URI requestUri = builder.build().encode().toUri();
 		ResponseEntity<MyOrderResponseDTO> response = template.exchange(requestUri, HttpMethod.GET, httpRequestEntity, MyOrderResponseDTO.class);
		
		assertThat(response.getStatusCode()).isEqualTo(HttpStatus.OK);
		assertThat(response.getBody().getResponseCode()).isEqualTo(OmatomeConstants.SUCCESS_RESPONSE_CODE);

		OrderInfo jpOrderInfo = new OrderInfo();
		jpOrderInfo.setOrderNumber("1003");
		assertThat(getOrderNumberResult(response, jpOrderInfo)).isFalse();
		
		OrderInfo expressOrderInfo = new OrderInfo();
		expressOrderInfo.setOrderNumber("4001");
		assertThat(getOrderNumberResult(response, expressOrderInfo)).isTrue();

	}
	
	
	@Test
	public void myOrdersCompanyNumberWithNullValueTest() throws Exception {
		String companyNumber = null;
		UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(myOrderApiUrl);
		builder.queryParam("companyNumber", companyNumber);
		URI requestUri = builder.build().encode().toUri();
 		ResponseEntity<MyOrderResponseDTO> response = template.exchange(requestUri, HttpMethod.GET, httpRequestEntity, MyOrderResponseDTO.class);

		assertThat(response.getStatusCode()).isEqualTo(HttpStatus.OK);
		assertThat(response.getBody().getResponseCode()).isEqualTo(OmatomeConstants.SUCCESS_RESPONSE_CODE);
		OrderInfo jpOrderInfo = new OrderInfo();
		jpOrderInfo.setOrderNumber("1003");
		assertThat(getOrderNumberResult(response, jpOrderInfo)).isTrue();
		
		OrderInfo expressOrderInfo = new OrderInfo();
		expressOrderInfo.setOrderNumber("4001");
		assertThat(getOrderNumberResult(response, expressOrderInfo)).isTrue();
		
	}
	
	@Test
	public void myOrdersCompanyNumberWithEmptyStringValueTest() throws Exception {
		UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(myOrderApiUrl);
		builder.queryParam("companyNumber", "");
		URI requestUri = builder.build().encode().toUri();
 		ResponseEntity<MyOrderResponseDTO> response = template.exchange(requestUri, HttpMethod.GET, httpRequestEntity, MyOrderResponseDTO.class);

		assertThat(response.getStatusCode()).isEqualTo(HttpStatus.OK);
		assertThat(response.getBody().getResponseCode()).isEqualTo(OmatomeConstants.SUCCESS_RESPONSE_CODE);
		OrderInfo jpOrderInfo = new OrderInfo();
		jpOrderInfo.setOrderNumber("1003");
		assertThat(getOrderNumberResult(response, jpOrderInfo)).isTrue();
		
		OrderInfo expressOrderInfo = new OrderInfo();
		expressOrderInfo.setOrderNumber("4001");
		assertThat(getOrderNumberResult(response, expressOrderInfo)).isTrue();
	}
	
	private boolean getOrderNumberResult(ResponseEntity<MyOrderResponseDTO> response, OrderInfo orderInfo) {
		List<ShippingList> shippingList = response.getBody().getShippingList().stream().collect(Collectors.toList());
		for(ShippingList shippingInfo : shippingList) {
			List<TrackingNumberDetails> trackingNumberDetailsList = shippingInfo.getTrackingNumberDetails().stream().collect(Collectors.toList());
			for(TrackingNumberDetails trackingNumberDetail : trackingNumberDetailsList) {
				List<OrderInfo> orderInfoList = trackingNumberDetail.getOrderList().stream().collect(Collectors.toList());
				for(OrderInfo order : orderInfoList) {
					if(orderInfo.getOrderNumber().equalsIgnoreCase(order.getOrderNumber())) {
						return true;
					}
				}
			}
		}
		return false;
	}

}
