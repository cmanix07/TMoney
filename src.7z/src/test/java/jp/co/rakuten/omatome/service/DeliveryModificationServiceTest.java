package jp.co.rakuten.omatome.service;

import static java.util.Collections.singletonList;
import static jp.co.rakuten.omatome.utils.OmatomeConstants.DATE_CHANGE_REQUEST;
import static jp.co.rakuten.omatome.utils.OmatomeConstants.POINTS_PER_TRACKING_NUMBER;
import static jp.co.rakuten.omatome.utils.OmatomeConstants.REDELIVERY_REQUEST;
import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.atMostOnce;
import static org.mockito.Mockito.lenient;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.platform.runner.JUnitPlatform;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import jp.co.rakuten.omatome.entity.DeliveryChangeEntity;
import jp.co.rakuten.omatome.entity.DeliveryChangePointEntity;
import jp.co.rakuten.omatome.entity.id.DeliveryChangeEntityId;
import jp.co.rakuten.omatome.model.TimeSlotCode;
import jp.co.rakuten.omatome.model.TrackingInfo;
import jp.co.rakuten.omatome.repository.DeliveryChangePointsRepository;
import jp.co.rakuten.omatome.repository.DeliveryChangeRepository;
import jp.co.rakuten.omatome.response.DeliveryChangeResponse;
import jp.co.rakuten.omatome.response.TimeSlot;
import jp.co.rakuten.omatome.service.japanpost.JapanPostService;
import jp.co.rakuten.omatome.utils.DateUtil;
import jp.co.rakuten.omatome.utils.EcoDeliverySlotChecker;
import jp.co.rakuten.omatome.utils.IdGenerator;

@ExtendWith(MockitoExtension.class)
@RunWith(JUnitPlatform.class)
class DeliveryModificationServiceTest {

  @Mock
  private JapanPostService japanPostService;

  @Mock
  private DeliveryChangeRepository deliveryChangeRepository;

  @Mock
  private DeliveryChangePointsRepository deliveryChangePointsRepository;

  @Mock
  private IdGenerator idGenerator;

  @Captor
  private ArgumentCaptor<List<DeliveryChangeEntity>> captor;

  @Mock
  private EcoDeliverySlotChecker ecoDeliverySlotChecker;

  private DeliveryModificationService service;

  @BeforeEach
  void setUp() {
    service = new DeliveryModificationService(
        japanPostService,
        deliveryChangeRepository,
        deliveryChangePointsRepository,
        idGenerator, ecoDeliverySlotChecker);
  }

  @Test
  void shouldModifyDelivery() {

    when(idGenerator.generate()).thenReturn("delivery-change-id");

    LinkedList<TrackingInfo> trackingInfoList = new LinkedList<>();
    TrackingInfo trackingInfo1 = new TrackingInfo("23456789", REDELIVERY_REQUEST,

        POINTS_PER_TRACKING_NUMBER, singletonList("item"),null);
    TrackingInfo trackingInfo2 = new TrackingInfo("234567891", REDELIVERY_REQUEST,
        POINTS_PER_TRACKING_NUMBER, singletonList("item"),null);

    trackingInfoList.add(trackingInfo1);
    trackingInfoList.add(trackingInfo2);
    HashMap<String, List<TrackingInfo>> result = new HashMap<>();
    result.put("SUCCESS", Collections.singletonList(trackingInfo2));
    result.put("FAILURE", Collections.singletonList(trackingInfo1));

    when(japanPostService.updateDelivery(trackingInfoList, "20200715", "53",
        "contactNumber")).thenReturn(result);

    DeliveryChangeResponse deliveryChangeResponse = service.modifyDelivery(trackingInfoList,
        "20200715", "53",
        "contactNumber",
        "1003", true);

    verify(japanPostService, times(1)).updateDelivery(trackingInfoList,
        "20200715", "53",
        "contactNumber");

    verify(deliveryChangeRepository, atMostOnce())
    .saveAll(Collections.singletonList(
        new DeliveryChangeEntity(

            new DeliveryChangeEntityId("1003", "234567891"),
            "delivery-change-id",
            LocalDate.now(), TimeSlotCode.getDescriptionFor("53"), "53", true,
            null, REDELIVERY_REQUEST)));

    verify(deliveryChangePointsRepository, atMostOnce())
    .save(new DeliveryChangePointEntity("delivery-change-id", 0, false));

    assertThat(deliveryChangeResponse.getChangeId()).isEqualTo("delivery-change-id");
    assertThat(deliveryChangeResponse.getChangeStatus()).isEqualTo(result);
    assertThat(deliveryChangeResponse.getRewardedPoint()).isEqualTo(0);
    assertThat(deliveryChangeResponse.getDeliveryDate()).isEqualTo("20200715");
    assertThat(deliveryChangeResponse.getEcoFlag()).isEqualTo(true);
    assertThat(deliveryChangeResponse.getTimeSlotCode()).isEqualTo("53");
    assertThat(deliveryChangeResponse.getTimeRange()).isEqualTo(TimeSlotCode.getDescriptionFor("53"));

  }

  @Test
  void shouldReturnPointsForOmatomeWithMoreThanOneSuccessDeliveryChange() {

    when(idGenerator.generate()).thenReturn("delivery-change-id");

    LinkedList<TrackingInfo> trackingInfoList = new LinkedList<>();
    TrackingInfo trackingInfo1 = new TrackingInfo("23456789", REDELIVERY_REQUEST,

        POINTS_PER_TRACKING_NUMBER, singletonList("item"),null);
    TrackingInfo trackingInfo2 = new TrackingInfo("234567891", REDELIVERY_REQUEST,
        0, singletonList("item"),null);

    trackingInfoList.add(trackingInfo1);
    trackingInfoList.add(trackingInfo2);
    HashMap<String, List<TrackingInfo>> result = new HashMap<>();
    result.put("SUCCESS", trackingInfoList);
    result.put("FAILURE", Collections.emptyList());


    when(japanPostService.updateDelivery(trackingInfoList, "20200715", "53",
        "contactNumber")).thenReturn(result);

    DeliveryChangeResponse deliveryChangeResponse = service.modifyDelivery(trackingInfoList,
        "20200715", "53",
        "contactNumber",
        "1003", true);

    verify(japanPostService, times(1)).updateDelivery(trackingInfoList,
        "20200715", "53",
        "contactNumber");

    verify(deliveryChangeRepository, atMostOnce())
    .saveAll(Arrays.asList(
        new DeliveryChangeEntity(

            new DeliveryChangeEntityId("1003", "234567891"),
            "delivery-change-id",
            LocalDate.now(), TimeSlotCode.getDescriptionFor("53"), "53", true,
            null, REDELIVERY_REQUEST),
        new DeliveryChangeEntity(
            new DeliveryChangeEntityId("1003", "23456789"),
            "delivery-change-id",
            LocalDate.now(), TimeSlotCode.getDescriptionFor("53"), "53", true,
            null, REDELIVERY_REQUEST)));

    verify(deliveryChangePointsRepository, atMostOnce())
    .save(new DeliveryChangePointEntity("delivery-change-id", 10, false));

    assertThat(deliveryChangeResponse.getChangeId()).isEqualTo("delivery-change-id");
    assertThat(deliveryChangeResponse.getChangeStatus()).isEqualTo(result);
    assertThat(deliveryChangeResponse.getRewardedPoint()).isEqualTo(10);
    assertThat(deliveryChangeResponse.getDeliveryDate()).isEqualTo("20200715");
    assertThat(deliveryChangeResponse.getTimeSlotCode()).isEqualTo("53");
    assertThat(deliveryChangeResponse.getTimeRange()).isEqualTo(TimeSlotCode.getDescriptionFor("53"));

  }

  @Test
  void shouldCombineOmatomeWithNewOrderWithMatchingDateSuccessDeliveryChange() {

    when(idGenerator.generate()).thenReturn("delivery-change-id");

    LinkedList<TrackingInfo> trackingInfoList = new LinkedList<>();
    TrackingInfo trackingInfo1 = new TrackingInfo("23456789", REDELIVERY_REQUEST,
        POINTS_PER_TRACKING_NUMBER, singletonList("item"),"existing-delivery-change-id");
    TrackingInfo trackingInfo2 = new TrackingInfo("234567892", REDELIVERY_REQUEST,
        POINTS_PER_TRACKING_NUMBER, singletonList("item"),null);

    TrackingInfo trackingInfo3 = new TrackingInfo("234567891", REDELIVERY_REQUEST,
        POINTS_PER_TRACKING_NUMBER, singletonList("item"),"existing-delivery-change-id");
    trackingInfoList.add(trackingInfo1);
    trackingInfoList.add(trackingInfo2);
    trackingInfoList.add(trackingInfo3);

    //Request delivery Change Id whose date is different 
    LinkedList<TrackingInfo> trackingInfoForDiffDateList = new LinkedList<>();
    trackingInfoForDiffDateList.add(trackingInfo2);
    HashMap<String, List<TrackingInfo>> result = new HashMap<>();
    result.put("SUCCESS", trackingInfoForDiffDateList);
    result.put("FAILURE", Collections.emptyList());

    List<DeliveryChangeEntity> existingDeliveryChangeEntities = Arrays.asList(
        new DeliveryChangeEntity(new DeliveryChangeEntityId("1003", "23456789"), "existing-delivery-change-id",
            DateUtil.getLocalDate("20200715"), TimeSlotCode.getDescriptionFor("53"), "53", true, null, REDELIVERY_REQUEST),
        new DeliveryChangeEntity(new DeliveryChangeEntityId("1003", "234567891"), "existing-delivery-change-id",
            DateUtil.getLocalDate("20200715"), TimeSlotCode.getDescriptionFor("53"), "53", true, null, REDELIVERY_REQUEST));

    List<DeliveryChangeEntityId> changeRequestIds = new ArrayList<>();
    DeliveryChangeEntityId deliveryChangeEntityId1 = new DeliveryChangeEntityId("1003", "23456789");
    DeliveryChangeEntityId deliveryChangeEntityId2 = new DeliveryChangeEntityId("1003", "234567891");
    changeRequestIds = Arrays.asList(deliveryChangeEntityId1,deliveryChangeEntityId2);

    when(deliveryChangeRepository.findAllById(changeRequestIds)).thenReturn(existingDeliveryChangeEntities);


    when(japanPostService.updateDelivery(trackingInfoForDiffDateList, "20200715", "53",
        "contactNumber")).thenReturn(result);

    DeliveryChangeResponse deliveryChangeResponse = service.modifyDelivery(trackingInfoList,
        "20200715", "53",
        "contactNumber",
        "1003", true);

    verify(deliveryChangeRepository, atMostOnce())
    .saveAll(Arrays.asList(
        new DeliveryChangeEntity(new DeliveryChangeEntityId("1003", "234567891"),
            "delivery-change-id", LocalDate.now(), TimeSlotCode.getDescriptionFor("53"),
            "53", true, "timeSlot", null),
        new DeliveryChangeEntity(new DeliveryChangeEntityId("1003", "23456789"),
            "delivery-change-id", LocalDate.now(), TimeSlotCode.getDescriptionFor("53"), "53", true, "timeSlot", null),
        new DeliveryChangeEntity(new DeliveryChangeEntityId("1003", "234567892"),
            "delivery-change-id", LocalDate.now(), TimeSlotCode.getDescriptionFor("53"), "53", true, "timeSlot", null)));

    verify(deliveryChangePointsRepository, atMostOnce())
    .save(new DeliveryChangePointEntity("delivery-change-id", 30, true));

    assertThat(deliveryChangeResponse.getChangeId()).isEqualTo("delivery-change-id");
    assertThat(deliveryChangeResponse.getChangeStatus()).isEqualTo(result);
    assertThat(deliveryChangeResponse.getRewardedPoint()).isEqualTo(30);
    assertThat(deliveryChangeResponse.getDeliveryDate()).isEqualTo("20200715");
    assertThat(deliveryChangeResponse.getTimeSlotCode()).isEqualTo("53");
    assertThat(deliveryChangeResponse.getTimeRange()).isEqualTo(TimeSlotCode.getDescriptionFor("53"));

  }

  @Test
  void shouldCombineOmatomeWithNewOrderWithNotMatchingDateSuccessDeliveryChange() {
    when(idGenerator.generate()).thenReturn("delivery-change-id");

    LinkedList<TrackingInfo> trackingInfoList = new LinkedList<>();
    TrackingInfo trackingInfo1 = new TrackingInfo("23456789", REDELIVERY_REQUEST,
        POINTS_PER_TRACKING_NUMBER, singletonList("item"),"existing-delivery-change-id");
    TrackingInfo trackingInfo2 = new TrackingInfo("234567892", REDELIVERY_REQUEST,
        POINTS_PER_TRACKING_NUMBER, singletonList("item"),null);

    TrackingInfo trackingInfo3 = new TrackingInfo("234567891", REDELIVERY_REQUEST,
        POINTS_PER_TRACKING_NUMBER, singletonList("item"),"existing-delivery-change-id");
    trackingInfoList.add(trackingInfo1);
    trackingInfoList.add(trackingInfo2);
    trackingInfoList.add(trackingInfo3);

    //Request delivery Change Id whose date is different 
    HashMap<String, List<TrackingInfo>> result = new HashMap<>();
    result.put("SUCCESS", trackingInfoList);
    result.put("FAILURE", Collections.emptyList());

    List<DeliveryChangeEntity> existingDeliveryChangeEntities = Arrays.asList(
        new DeliveryChangeEntity(new DeliveryChangeEntityId("1003", "23456789"), "existing-delivery-change-id",
            DateUtil.getLocalDate("20200715"), TimeSlotCode.getDescriptionFor("53"), "53", true, null, REDELIVERY_REQUEST),
        new DeliveryChangeEntity(new DeliveryChangeEntityId("1003", "234567891"), "existing-delivery-change-id",
            DateUtil.getLocalDate("20200715"), TimeSlotCode.getDescriptionFor("53"), "53", true, null, REDELIVERY_REQUEST));

    List<DeliveryChangeEntityId> changeRequestIds = new ArrayList<>();
    DeliveryChangeEntityId deliveryChangeEntityId1 = new DeliveryChangeEntityId("1003", "23456789");
    DeliveryChangeEntityId deliveryChangeEntityId2 = new DeliveryChangeEntityId("1003", "234567891");
    changeRequestIds = Arrays.asList(deliveryChangeEntityId1,deliveryChangeEntityId2);

    when(deliveryChangeRepository.findAllById(changeRequestIds)).thenReturn(existingDeliveryChangeEntities);


    when(japanPostService.updateDelivery(trackingInfoList, "20200716", "53",
        "contactNumber")).thenReturn(result);

    DeliveryChangeResponse deliveryChangeResponse = service.modifyDelivery(trackingInfoList,
        "20200716", "53",
        "contactNumber",
        "1003", true);

    verify(deliveryChangeRepository, atMostOnce())
    .saveAll(Arrays.asList(
        new DeliveryChangeEntity(new DeliveryChangeEntityId("1003", "234567891"),
            "delivery-change-id", LocalDate.now(), TimeSlotCode.getDescriptionFor("53"),
            "53", true, "timeSlot", null),
        new DeliveryChangeEntity(new DeliveryChangeEntityId("1003", "23456789"),
            "delivery-change-id", LocalDate.now(), TimeSlotCode.getDescriptionFor("53"), "53", true, "timeSlot", null),
        new DeliveryChangeEntity(new DeliveryChangeEntityId("1003", "234567892"),
            "delivery-change-id", LocalDate.now(), TimeSlotCode.getDescriptionFor("53"), "53", true, "timeSlot", null)));

    verify(deliveryChangePointsRepository, atMostOnce())
    .save(new DeliveryChangePointEntity("delivery-change-id", 20, false));

    assertThat(deliveryChangeResponse.getChangeId()).isEqualTo("delivery-change-id");
    assertThat(deliveryChangeResponse.getChangeStatus()).isEqualTo(result);
    //Redelivery date change request so rewards become zero
    assertThat(deliveryChangeResponse.getRewardedPoint()).isEqualTo(0);
    assertThat(deliveryChangeResponse.getDeliveryDate()).isEqualTo("20200716");
    assertThat(deliveryChangeResponse.getTimeSlotCode()).isEqualTo("53");
    assertThat(deliveryChangeResponse.getTimeRange()).isEqualTo(TimeSlotCode.getDescriptionFor("53"));

  }

  @Test
  void shouldCombineOmatomeWithDiffDateChangeFailedAndSuccessDeliveryChange() {
    when(idGenerator.generate()).thenReturn("delivery-change-id");

    LinkedList<TrackingInfo> trackingInfoList = new LinkedList<>();
    LinkedList<TrackingInfo> successTrackingInfoList = new LinkedList<>();
    LinkedList<TrackingInfo> failedTrackingInfoList = new LinkedList<>();

    TrackingInfo trackingInfo1 = new TrackingInfo("23456789", DATE_CHANGE_REQUEST,
        POINTS_PER_TRACKING_NUMBER, singletonList("item"),"existing-delivery-change-id");
    TrackingInfo trackingInfo2 = new TrackingInfo("23456790", DATE_CHANGE_REQUEST,
        POINTS_PER_TRACKING_NUMBER, singletonList("item"),"existing-delivery-change-id");
    TrackingInfo trackingInfo3 = new TrackingInfo("23456791", DATE_CHANGE_REQUEST,
        POINTS_PER_TRACKING_NUMBER, singletonList("item"),"existing-delivery-change-id");
    TrackingInfo trackingInfo4 = new TrackingInfo("23456792", REDELIVERY_REQUEST,
        POINTS_PER_TRACKING_NUMBER, singletonList("item"),null);
    TrackingInfo trackingInfo5 = new TrackingInfo("23456793", REDELIVERY_REQUEST,
        POINTS_PER_TRACKING_NUMBER, singletonList("item"),null);

    successTrackingInfoList.add(trackingInfo2);
    successTrackingInfoList.add(trackingInfo3);
    successTrackingInfoList.add(trackingInfo4);

    failedTrackingInfoList.add(trackingInfo1);
    failedTrackingInfoList.add(trackingInfo5);

    trackingInfoList.add(trackingInfo1);
    trackingInfoList.add(trackingInfo2);
    trackingInfoList.add(trackingInfo3);
    trackingInfoList.add(trackingInfo4);
    trackingInfoList.add(trackingInfo5);
    //Request delivery Change Id whose date is different 
    HashMap<String, List<TrackingInfo>> result = new HashMap<>();
    result.put("SUCCESS", successTrackingInfoList);
    result.put("FAILURE", failedTrackingInfoList);

    List<DeliveryChangeEntity> existingDeliveryChangeEntities = Arrays.asList(
        new DeliveryChangeEntity(new DeliveryChangeEntityId("1003", "23456789"), "existing-delivery-change-id",
            DateUtil.getLocalDate("20200715"), TimeSlotCode.getDescriptionFor("53"), "53", true, null, DATE_CHANGE_REQUEST),
        new DeliveryChangeEntity(new DeliveryChangeEntityId("1003", "23456790"), "existing-delivery-change-id",
            DateUtil.getLocalDate("20200715"), TimeSlotCode.getDescriptionFor("53"), "53", true, null, DATE_CHANGE_REQUEST),
        new DeliveryChangeEntity(new DeliveryChangeEntityId("1003", "23456791"), "existing-delivery-change-id",
            DateUtil.getLocalDate("20200715"), TimeSlotCode.getDescriptionFor("53"), "53", true, null, DATE_CHANGE_REQUEST));

    List<DeliveryChangeEntityId> changeRequestIds = new ArrayList<>();
    DeliveryChangeEntityId deliveryChangeEntityId1 = new DeliveryChangeEntityId("1003", "23456789");
    DeliveryChangeEntityId deliveryChangeEntityId2 = new DeliveryChangeEntityId("1003", "23456790");
    DeliveryChangeEntityId deliveryChangeEntityId3 = new DeliveryChangeEntityId("1003", "23456791");
    changeRequestIds = Arrays.asList(deliveryChangeEntityId1,deliveryChangeEntityId2,deliveryChangeEntityId3);

    when(deliveryChangeRepository.findAllById(changeRequestIds)).thenReturn(existingDeliveryChangeEntities);


    when(japanPostService.updateDelivery(trackingInfoList, "20200716", "53",
        "contactNumber")).thenReturn(result);

    DeliveryChangeResponse deliveryChangeResponse = service.modifyDelivery(trackingInfoList,
        "20200716", "53",
        "contactNumber",
        "1003", true);

    verify(deliveryChangeRepository, atMostOnce())
    .saveAll(Arrays.asList(
        new DeliveryChangeEntity(new DeliveryChangeEntityId("1003", "23456790"),
            "delivery-change-id", LocalDate.now(), TimeSlotCode.getDescriptionFor("53"),
            "53", true, "timeSlot", null),
        new DeliveryChangeEntity(new DeliveryChangeEntityId("1003", "23456791"),
            "delivery-change-id", LocalDate.now(), TimeSlotCode.getDescriptionFor("53"), "53", true, "timeSlot", null),
        new DeliveryChangeEntity(new DeliveryChangeEntityId("1003", "23456792"),
            "delivery-change-id", LocalDate.now(), TimeSlotCode.getDescriptionFor("53"), "53", true, "timeSlot", null)));

    verify(deliveryChangePointsRepository, atMostOnce())
    .save(new DeliveryChangePointEntity("delivery-change-id", 0, false));

    verify(deliveryChangeRepository, times(1)).saveAll(captor.capture());
    List<DeliveryChangeEntity> captureddeliveryChangeEntities = captor.getValue();
    assertEquals(3, captureddeliveryChangeEntities.size());
    assertEquals("delivery-change-id", captureddeliveryChangeEntities.get(0).getDeliveryChangeId());
    assertEquals("delivery-change-id", captureddeliveryChangeEntities.get(1).getDeliveryChangeId());
    assertEquals("delivery-change-id", captureddeliveryChangeEntities.get(2).getDeliveryChangeId());

    verify(deliveryChangePointsRepository, atMostOnce()).deleteAll(Arrays.asList(new DeliveryChangePointEntity("existing-delivery-change-id", 20, true)));

    assertThat(deliveryChangeResponse.getChangeId()).isEqualTo("delivery-change-id");
    assertThat(deliveryChangeResponse.getChangeStatus()).isEqualTo(result);
    //Redelivery date change request so rewards become zero
    assertThat(deliveryChangeResponse.getRewardedPoint()).isEqualTo(0);
    assertThat(deliveryChangeResponse.getDeliveryDate()).isEqualTo("20200716");
    assertThat(deliveryChangeResponse.getTimeSlotCode()).isEqualTo("53");
    assertThat(deliveryChangeResponse.getTimeRange()).isEqualTo(TimeSlotCode.getDescriptionFor("53"));

  }

  @Test
  void shouldCombineOmatomeWithMatchingDateFailedAndSuccessDeliveryChange() {
    when(idGenerator.generate()).thenReturn("delivery-change-id");

    LinkedList<TrackingInfo> trackingInfoList = new LinkedList<>();
    LinkedList<TrackingInfo> successTrackingInfoList = new LinkedList<>();
    LinkedList<TrackingInfo> failedTrackingInfoList = new LinkedList<>();
    LinkedList<TrackingInfo> newTrackingInfoList = new LinkedList<>();

    TrackingInfo trackingInfo1 = new TrackingInfo("23456789", REDELIVERY_REQUEST,
        POINTS_PER_TRACKING_NUMBER, singletonList("item"),"existing-delivery-change-id");
    TrackingInfo trackingInfo2 = new TrackingInfo("23456790", REDELIVERY_REQUEST,
        POINTS_PER_TRACKING_NUMBER, singletonList("item"),"existing-delivery-change-id");
    TrackingInfo trackingInfo3 = new TrackingInfo("23456791", REDELIVERY_REQUEST,
        POINTS_PER_TRACKING_NUMBER, singletonList("item"),null);
    TrackingInfo trackingInfo4 = new TrackingInfo("23456792", REDELIVERY_REQUEST,
        POINTS_PER_TRACKING_NUMBER, singletonList("item"),null);
    TrackingInfo trackingInfo5 = new TrackingInfo("23456793", REDELIVERY_REQUEST,
        POINTS_PER_TRACKING_NUMBER, singletonList("item"),null);

    successTrackingInfoList.add(trackingInfo3);
    successTrackingInfoList.add(trackingInfo4);

    failedTrackingInfoList.add(trackingInfo5);

    trackingInfoList.add(trackingInfo1);
    trackingInfoList.add(trackingInfo2);
    trackingInfoList.add(trackingInfo3);
    trackingInfoList.add(trackingInfo4);
    trackingInfoList.add(trackingInfo5);

    newTrackingInfoList.add(trackingInfo3);
    newTrackingInfoList.add(trackingInfo4);
    newTrackingInfoList.add(trackingInfo5);

    //Request delivery Change Id whose date is different 
    HashMap<String, List<TrackingInfo>> result = new HashMap<>();
    result.put("SUCCESS", successTrackingInfoList);
    result.put("FAILURE", failedTrackingInfoList);

    List<DeliveryChangeEntity> existingDeliveryChangeEntities = Arrays.asList(
        new DeliveryChangeEntity(new DeliveryChangeEntityId("1003", "23456789"), "existing-delivery-change-id",
            DateUtil.getLocalDate("20200715"), TimeSlotCode.getDescriptionFor("53"), "53", true, null, REDELIVERY_REQUEST),
        new DeliveryChangeEntity(new DeliveryChangeEntityId("1003", "23456790"), "existing-delivery-change-id",
            DateUtil.getLocalDate("20200715"), TimeSlotCode.getDescriptionFor("53"), "53", true, null, REDELIVERY_REQUEST));

    List<DeliveryChangeEntityId> changeRequestIds = new ArrayList<>();
    DeliveryChangeEntityId deliveryChangeEntityId1 = new DeliveryChangeEntityId("1003", "23456789");
    DeliveryChangeEntityId deliveryChangeEntityId2 = new DeliveryChangeEntityId("1003", "23456790");
    changeRequestIds = Arrays.asList(deliveryChangeEntityId1,deliveryChangeEntityId2);

    when(deliveryChangeRepository.findAllById(changeRequestIds)).thenReturn(existingDeliveryChangeEntities);


    when(japanPostService.updateDelivery(newTrackingInfoList, "20200715", "53",
        "contactNumber")).thenReturn(result);

    DeliveryChangeResponse deliveryChangeResponse = service.modifyDelivery(trackingInfoList,
        "20200715", "53",
        "contactNumber",
        "1003", true);

    verify(deliveryChangeRepository, atMostOnce())
    .saveAll(Arrays.asList(
        new DeliveryChangeEntity(new DeliveryChangeEntityId("1003", "23456791"),
            "delivery-change-id", LocalDate.now(), TimeSlotCode.getDescriptionFor("53"),
            "53", true, "timeSlot", null),
        new DeliveryChangeEntity(new DeliveryChangeEntityId("1003", "23456792"),
            "delivery-change-id", LocalDate.now(), TimeSlotCode.getDescriptionFor("53"), "53", true, "timeSlot", null)));

    verify(deliveryChangePointsRepository, atMostOnce())
    .save(new DeliveryChangePointEntity("delivery-change-id", 40, false));

    verify(deliveryChangeRepository, times(1)).saveAll(captor.capture());
    List<DeliveryChangeEntity> captureddeliveryChangeEntities = captor.getValue();
    assertEquals(4, captureddeliveryChangeEntities.size());
    assertEquals("delivery-change-id", captureddeliveryChangeEntities.get(0).getDeliveryChangeId());
    assertEquals("delivery-change-id", captureddeliveryChangeEntities.get(1).getDeliveryChangeId());
    assertEquals("delivery-change-id", captureddeliveryChangeEntities.get(2).getDeliveryChangeId());
    assertEquals("delivery-change-id", captureddeliveryChangeEntities.get(3).getDeliveryChangeId());

    verify(deliveryChangePointsRepository, atMostOnce()).deleteAll(Arrays.asList(new DeliveryChangePointEntity("existing-delivery-change-id", 20, true)));

    assertThat(deliveryChangeResponse.getChangeId()).isEqualTo("delivery-change-id");
    assertThat(deliveryChangeResponse.getChangeStatus()).isEqualTo(result);
    //Redelivery date change request so rewards become zero
    assertThat(deliveryChangeResponse.getRewardedPoint()).isEqualTo(40);
    assertThat(deliveryChangeResponse.getDeliveryDate()).isEqualTo("20200715");
    assertThat(deliveryChangeResponse.getTimeSlotCode()).isEqualTo("53");
    assertThat(deliveryChangeResponse.getTimeRange()).isEqualTo(TimeSlotCode.getDescriptionFor("53"));

  }

  @Test
  void shouldCombineOmatomeExistingRedeliveryDateChangeSuccessDeliveryTest() {
    when(idGenerator.generate()).thenReturn("delivery-change-id");

    LinkedList<TrackingInfo> trackingInfoList = new LinkedList<>();
    TrackingInfo trackingInfo1 = new TrackingInfo("23456789", DATE_CHANGE_REQUEST,
        POINTS_PER_TRACKING_NUMBER, singletonList("item"),"existing-delivery-change-id-1");
    TrackingInfo trackingInfo2 = new TrackingInfo("23456790", DATE_CHANGE_REQUEST,
        0, singletonList("item"),"existing-delivery-change-id-2");
    trackingInfoList.add(trackingInfo1);
    trackingInfoList.add(trackingInfo2);

    //Request delivery Change Id whose date is different 
    HashMap<String, List<TrackingInfo>> result = new HashMap<>();
    result.put("SUCCESS", trackingInfoList);
    result.put("FAILURE", Collections.emptyList());

    List<DeliveryChangeEntity> existingDeliveryChangeEntities = Arrays.asList(
        new DeliveryChangeEntity(new DeliveryChangeEntityId("1003", "23456789"), "existing-delivery-change-id-1",
            DateUtil.getLocalDate("20200715"), TimeSlotCode.getDescriptionFor("53"), "53", true, null, DATE_CHANGE_REQUEST),
        new DeliveryChangeEntity(new DeliveryChangeEntityId("1003", "23456790"), "existing-delivery-change-id-2",
            DateUtil.getLocalDate("20200715"), TimeSlotCode.getDescriptionFor("53"), "53", true, null, DATE_CHANGE_REQUEST));

    List<DeliveryChangeEntityId> changeRequestIds = new ArrayList<>();
    DeliveryChangeEntityId deliveryChangeEntityId1 = new DeliveryChangeEntityId("1003", "23456789");
    DeliveryChangeEntityId deliveryChangeEntityId2 = new DeliveryChangeEntityId("1003", "23456790");
    changeRequestIds = Arrays.asList(deliveryChangeEntityId1,deliveryChangeEntityId2);

    when(deliveryChangeRepository.findAllById(changeRequestIds)).thenReturn(existingDeliveryChangeEntities);


    when(japanPostService.updateDelivery(trackingInfoList, "20200716", "53",
        "contactNumber")).thenReturn(result);

    DeliveryChangeResponse deliveryChangeResponse = service.modifyDelivery(trackingInfoList,
        "20200716", "53",
        "contactNumber",
        "1003", true);

    verify(deliveryChangeRepository, atMostOnce())
    .saveAll(Arrays.asList(
        new DeliveryChangeEntity(new DeliveryChangeEntityId("1003", "23456789"),
            "delivery-change-id", LocalDate.now(), TimeSlotCode.getDescriptionFor("53"), "53", true, "timeSlot", null),
        new DeliveryChangeEntity(new DeliveryChangeEntityId("1003", "23456790"),
            "delivery-change-id", LocalDate.now(), TimeSlotCode.getDescriptionFor("53"), "53", true, "timeSlot", null)));

    verify(deliveryChangePointsRepository, atMostOnce())
    .save(new DeliveryChangePointEntity("delivery-change-id", 20, false));

    verify(deliveryChangeRepository, times(1)).saveAll(captor.capture());
    List<DeliveryChangeEntity> captureddeliveryChangeEntities = captor.getValue();
    assertEquals(2, captureddeliveryChangeEntities.size());
    assertEquals("delivery-change-id", captureddeliveryChangeEntities.get(0).getDeliveryChangeId());
    assertEquals("delivery-change-id", captureddeliveryChangeEntities.get(1).getDeliveryChangeId());
    assertEquals(DateUtil.getLocalDate("20200716"), captureddeliveryChangeEntities.get(0).getDeliveryDate());
    assertEquals(DateUtil.getLocalDate("20200716"), captureddeliveryChangeEntities.get(1).getDeliveryDate());

    verify(deliveryChangePointsRepository, atMostOnce()).deleteAll(Arrays.asList(new DeliveryChangePointEntity("existing-delivery-change-id", 20, true)));

    assertThat(deliveryChangeResponse.getChangeId()).isEqualTo("delivery-change-id");
    assertThat(deliveryChangeResponse.getChangeStatus()).isEqualTo(result);
    //Redelivery date change request so rewards become zero
    assertThat(deliveryChangeResponse.getRewardedPoint()).isEqualTo(0);
    assertThat(deliveryChangeResponse.getDeliveryDate()).isEqualTo("20200716");
    assertThat(deliveryChangeResponse.getTimeSlotCode()).isEqualTo("53");
    assertThat(deliveryChangeResponse.getTimeRange()).isEqualTo(TimeSlotCode.getDescriptionFor("53"));

  }

  @Test
  void shouldCombineOmatomeExistingRedeliveryOfDiffDateChangeSuccessDeliveryTest() {
    when(idGenerator.generate()).thenReturn("delivery-change-id");

    LinkedList<TrackingInfo> trackingInfoList = new LinkedList<>();
    TrackingInfo trackingInfo1 = new TrackingInfo("23456789", DATE_CHANGE_REQUEST,
        POINTS_PER_TRACKING_NUMBER, singletonList("item"),"existing-delivery-change-id-1");
    TrackingInfo trackingInfo2 = new TrackingInfo("23456790", DATE_CHANGE_REQUEST,
        POINTS_PER_TRACKING_NUMBER, singletonList("item"),"existing-delivery-change-id-2");
    TrackingInfo trackingInfo3 = new TrackingInfo("23456790", REDELIVERY_REQUEST,
        POINTS_PER_TRACKING_NUMBER, singletonList("item"),null);
    trackingInfoList.add(trackingInfo1);
    trackingInfoList.add(trackingInfo2);
    trackingInfoList.add(trackingInfo3);

    //Request delivery Change Id whose date is different 
    HashMap<String, List<TrackingInfo>> result = new HashMap<>();
    result.put("SUCCESS", trackingInfoList);
    result.put("FAILURE", Collections.emptyList());

    List<DeliveryChangeEntity> existingDeliveryChangeEntities = Arrays.asList(
        new DeliveryChangeEntity(new DeliveryChangeEntityId("1003", "23456789"), "existing-delivery-change-id-1",
            DateUtil.getLocalDate("20200715"), TimeSlotCode.getDescriptionFor("53"), "53", true, null, DATE_CHANGE_REQUEST),
        new DeliveryChangeEntity(new DeliveryChangeEntityId("1003", "23456790"), "existing-delivery-change-id-2",
            DateUtil.getLocalDate("20200716"), TimeSlotCode.getDescriptionFor("53"), "53", true, null, DATE_CHANGE_REQUEST));

    List<DeliveryChangeEntityId> changeRequestIds = new ArrayList<>();
    DeliveryChangeEntityId deliveryChangeEntityId1 = new DeliveryChangeEntityId("1003", "23456789");
    DeliveryChangeEntityId deliveryChangeEntityId2 = new DeliveryChangeEntityId("1003", "23456790");
    changeRequestIds = Arrays.asList(deliveryChangeEntityId1,deliveryChangeEntityId2);

    when(deliveryChangeRepository.findAllById(changeRequestIds)).thenReturn(existingDeliveryChangeEntities);


    when(japanPostService.updateDelivery(trackingInfoList, "20200716", "53",
        "contactNumber")).thenReturn(result);

    DeliveryChangeResponse deliveryChangeResponse = service.modifyDelivery(trackingInfoList,
        "20200716", "53",
        "contactNumber",
        "1003", true);

    verify(deliveryChangeRepository, atMostOnce())
    .saveAll(Arrays.asList(
        new DeliveryChangeEntity(new DeliveryChangeEntityId("1003", "23456789"),
            "delivery-change-id", LocalDate.now(), TimeSlotCode.getDescriptionFor("53"), "53", true, "timeSlot", null),
        new DeliveryChangeEntity(new DeliveryChangeEntityId("1003", "23456790"),
            "delivery-change-id", LocalDate.now(), TimeSlotCode.getDescriptionFor("53"), "53", true, "timeSlot", null)));

    verify(deliveryChangePointsRepository, atMostOnce())
    .save(new DeliveryChangePointEntity("delivery-change-id", 0, false));

    verify(deliveryChangeRepository, times(1)).saveAll(captor.capture());
    List<DeliveryChangeEntity> captureddeliveryChangeEntities = captor.getValue();
    assertEquals(3, captureddeliveryChangeEntities.size());
    assertEquals("delivery-change-id", captureddeliveryChangeEntities.get(0).getDeliveryChangeId());
    assertEquals("delivery-change-id", captureddeliveryChangeEntities.get(1).getDeliveryChangeId());
    assertEquals("delivery-change-id", captureddeliveryChangeEntities.get(2).getDeliveryChangeId());
    assertEquals(DateUtil.getLocalDate("20200716"), captureddeliveryChangeEntities.get(0).getDeliveryDate());
    assertEquals(DateUtil.getLocalDate("20200716"), captureddeliveryChangeEntities.get(1).getDeliveryDate());
    assertEquals(DateUtil.getLocalDate("20200716"), captureddeliveryChangeEntities.get(2).getDeliveryDate());

    verify(deliveryChangePointsRepository, atMostOnce()).deleteAll(Arrays.asList(new DeliveryChangePointEntity("existing-delivery-change-id-1", 20, true)));

    assertThat(deliveryChangeResponse.getChangeId()).isEqualTo("delivery-change-id");
    assertThat(deliveryChangeResponse.getChangeStatus()).isEqualTo(result);
    //Redelivery date change request so rewards become zero
    assertThat(deliveryChangeResponse.getRewardedPoint()).isEqualTo(0);
    assertThat(deliveryChangeResponse.getDeliveryDate()).isEqualTo("20200716");
    assertThat(deliveryChangeResponse.getTimeSlotCode()).isEqualTo("53");
    assertThat(deliveryChangeResponse.getTimeRange()).isEqualTo(TimeSlotCode.getDescriptionFor("53"));

  }


  @Test
  void shouldGetAvailableDates() {
    LinkedHashMap<String, Set<String>> availableDates = new LinkedHashMap<>();
    HashSet<String> timeSlotCodes = new LinkedHashSet<>();
    timeSlotCodes.add("00");
    timeSlotCodes.add("53");
    timeSlotCodes.add("56");
    availableDates.put("20200930", timeSlotCodes);
    availableDates.put("20201001", timeSlotCodes);

    Map<String, List<TimeSlot>> expected = new LinkedHashMap<>();
    List<TimeSlot> expectedTimeSlot = new ArrayList<>();
    TimeSlot timeSlot1 = new TimeSlot("00", TimeSlotCode.getDescriptionFor("00"), false);
    TimeSlot timeSlot2 = new TimeSlot("53", TimeSlotCode.getDescriptionFor("53"), true);
    TimeSlot timeSlot3 = new TimeSlot("56", TimeSlotCode.getDescriptionFor("56"), false);

    expectedTimeSlot.add(timeSlot1);
    expectedTimeSlot.add(timeSlot2);
    expectedTimeSlot.add(timeSlot3);
    expected.put("20200930", expectedTimeSlot);
    expected.put("20201001", expectedTimeSlot);

    when(ecoDeliverySlotChecker.isEligible(any(), anyString(), any()))
    .thenReturn(false);
    when(ecoDeliverySlotChecker.isEligible("20200930", "53", "1003"))
    .thenReturn(true);
    when(ecoDeliverySlotChecker.isEligible("20201001", "53", "1003"))
    .thenReturn(true);

    LinkedList<TrackingInfo> trackingInfoList = new LinkedList<>();
    trackingInfoList.add(new TrackingInfo("23456789", REDELIVERY_REQUEST,

        POINTS_PER_TRACKING_NUMBER, singletonList("item"),null));
    trackingInfoList.add(new TrackingInfo("2345678", REDELIVERY_REQUEST,
        POINTS_PER_TRACKING_NUMBER, singletonList("item"),null));

    when(japanPostService.getCommonAvailableDates(trackingInfoList))
    .thenReturn(availableDates);

    Map<String, List<TimeSlot>> response = service
        .availableDates(trackingInfoList, "1003");

    assertThat(response.size()).isEqualTo(2);
    assertThat(response.get("20200930").size()).isEqualTo(3);
    assertThat(response.get("20200930").get(0)).isEqualToComparingFieldByField(timeSlot1);
    assertThat(response.get("20200930").get(1)).isEqualToComparingFieldByField(timeSlot2);
    assertThat(response.get("20200930").get(2)).isEqualToComparingFieldByField(timeSlot3);

    assertThat(response.get("20201001").size()).isEqualTo(3);
    assertThat(response.get("20201001").get(0)).isEqualToComparingFieldByField(timeSlot1);
    assertThat(response.get("20201001").get(1)).isEqualToComparingFieldByField(timeSlot2);
    assertThat(response.get("20201001").get(2)).isEqualToComparingFieldByField(timeSlot3);
  }



  @Test
  void shouldGetOnlyPreviouslySelectedDatesForDateChangeRequest() {

    TimeSlot timeSlot1 = new TimeSlot("56", TimeSlotCode.getDescriptionFor("56"), false);

    when(ecoDeliverySlotChecker.isEligible(any(), anyString(), any()))
    .thenReturn(false);

    LinkedList<TrackingInfo> trackingInfoList = new LinkedList<>();
    trackingInfoList.add(new TrackingInfo("12345", DATE_CHANGE_REQUEST,
        POINTS_PER_TRACKING_NUMBER, singletonList("item"),"1"));
    trackingInfoList.add(new TrackingInfo("67890", DATE_CHANGE_REQUEST,
        POINTS_PER_TRACKING_NUMBER, singletonList("item"),null));


    LocalDate tomorrow = LocalDate.now().plusDays(1);
    DeliveryChangeEntityId deliveryChangeId  = new DeliveryChangeEntityId("1003","12345");


    DeliveryChangeEntity deliveryChangeInfo = new DeliveryChangeEntity(
        deliveryChangeId, "1", tomorrow,
        "20:00~21:00", "56", false, null, DATE_CHANGE_REQUEST);

    lenient().when(deliveryChangeRepository.findById(deliveryChangeId)).thenReturn(Optional.of(deliveryChangeInfo));

    Map<String, List<TimeSlot>> response = service
        .availableDates(trackingInfoList, "1003");

    String formattedTomorrowDate = DateUtil.format(deliveryChangeInfo.getDeliveryDate());

    assertThat(response.size()).isEqualTo(1);
    assertThat(response.get(formattedTomorrowDate).size()).isEqualTo(1);
    assertThat(response.get(formattedTomorrowDate).get(0)).isEqualToComparingFieldByField(timeSlot1);

  }
  @Test
  void shouldGetOnlyPreviouslySelectedDatesForRedeliveryRequest() {

    TimeSlot timeSlot1 = new TimeSlot("54", TimeSlotCode.getDescriptionFor("54"), false);

    when(ecoDeliverySlotChecker.isEligible(any(), anyString(), any()))
    .thenReturn(false);

    LinkedList<TrackingInfo> trackingInfoList = new LinkedList<>();
    trackingInfoList.add(new TrackingInfo("12345", DATE_CHANGE_REQUEST,
        POINTS_PER_TRACKING_NUMBER, singletonList("item"),"1"));
    trackingInfoList.add(new TrackingInfo("67890", REDELIVERY_REQUEST,
        POINTS_PER_TRACKING_NUMBER, singletonList("item"),null));

    LocalDate tomorrow = LocalDate.now().plusDays(1);
    DeliveryChangeEntityId deliveryChangeId  = new DeliveryChangeEntityId("1003","12345");


    DeliveryChangeEntity deliveryChangeInfo = new DeliveryChangeEntity(
        deliveryChangeId, "1", tomorrow,
        "16:00~18:00", "54", false, null, DATE_CHANGE_REQUEST);

    lenient().when(deliveryChangeRepository.findById(deliveryChangeId)).thenReturn(Optional.of(deliveryChangeInfo));

    Map<String, List<TimeSlot>> response = service
        .availableDates(trackingInfoList, "1003");

    String formattedTomorrowDate = DateUtil.format(deliveryChangeInfo.getDeliveryDate());

    assertThat(response.size()).isEqualTo(1);
    assertThat(response.get(formattedTomorrowDate).size()).isEqualTo(1);
    assertThat(response.get(formattedTomorrowDate).get(0)).isEqualToComparingFieldByField(timeSlot1);

  }

  @Test
  void shouldGetAllAvailableDatesForDateChangeRequest() {
    LinkedHashMap<String, Set<String>> availableDates = new LinkedHashMap<>();
    HashSet<String> timeSlotCodes = new LinkedHashSet<>();
    timeSlotCodes.add("00");
    timeSlotCodes.add("53");
    timeSlotCodes.add("56");
    availableDates.put("20200930", timeSlotCodes);
    availableDates.put("20201001", timeSlotCodes);

    Map<String, List<TimeSlot>> expected = new LinkedHashMap<>();
    List<TimeSlot> expectedTimeSlot = new ArrayList<>();
    TimeSlot timeSlot1 = new TimeSlot("00", TimeSlotCode.getDescriptionFor("00"), false);
    TimeSlot timeSlot2 = new TimeSlot("53", TimeSlotCode.getDescriptionFor("53"), true);
    TimeSlot timeSlot3 = new TimeSlot("56", TimeSlotCode.getDescriptionFor("56"), false);

    expectedTimeSlot.add(timeSlot1);
    expectedTimeSlot.add(timeSlot2);
    expectedTimeSlot.add(timeSlot3);
    expected.put("20200930", expectedTimeSlot);
    expected.put("20201001", expectedTimeSlot);

    when(ecoDeliverySlotChecker.isEligible(any(), anyString(), any()))
    .thenReturn(false);
    when(ecoDeliverySlotChecker.isEligible("20200930", "53", "1003"))
    .thenReturn(true);
    when(ecoDeliverySlotChecker.isEligible("20201001", "53", "1003"))
    .thenReturn(true);

    LinkedList<TrackingInfo> trackingInfoList = new LinkedList<>();
    trackingInfoList.add(new TrackingInfo("12345", REDELIVERY_REQUEST,
        POINTS_PER_TRACKING_NUMBER, singletonList("item"),"1"));
    trackingInfoList.add(new TrackingInfo("67890", DATE_CHANGE_REQUEST,
        POINTS_PER_TRACKING_NUMBER, singletonList("item"),null));

    LocalDate tomorrow = LocalDate.now().plusDays(1);
    DeliveryChangeEntityId deliveryChangeId  = new DeliveryChangeEntityId("1003","12345");


    DeliveryChangeEntity deliveryChangeInfo = new DeliveryChangeEntity(
        deliveryChangeId, "1", tomorrow,
        "20:00~21:00", "56", false, null, DATE_CHANGE_REQUEST);

    lenient().when(deliveryChangeRepository.findById(deliveryChangeId)).thenReturn(Optional.of(deliveryChangeInfo));

    when(japanPostService.getCommonAvailableDates(trackingInfoList))
    .thenReturn(availableDates);

    Map<String, List<TimeSlot>> response = service
        .availableDates(trackingInfoList, "1003");

    assertThat(response.size()).isEqualTo(2);
    assertThat(response.get("20200930").size()).isEqualTo(3);
    assertThat(response.get("20200930").get(0)).isEqualToComparingFieldByField(timeSlot1);
    assertThat(response.get("20200930").get(1)).isEqualToComparingFieldByField(timeSlot2);
    assertThat(response.get("20200930").get(2)).isEqualToComparingFieldByField(timeSlot3);

    assertThat(response.get("20201001").size()).isEqualTo(3);
    assertThat(response.get("20201001").get(0)).isEqualToComparingFieldByField(timeSlot1);
    assertThat(response.get("20201001").get(1)).isEqualToComparingFieldByField(timeSlot2);
    assertThat(response.get("20201001").get(2)).isEqualToComparingFieldByField(timeSlot3);
  }

  @Test
  void shouldGetAllAvailableDatesForRedeliveryRequest() {
    LinkedHashMap<String, Set<String>> availableDates = new LinkedHashMap<>();
    HashSet<String> timeSlotCodes = new LinkedHashSet<>();
    timeSlotCodes.add("00");
    timeSlotCodes.add("53");
    timeSlotCodes.add("56");
    availableDates.put("20200930", timeSlotCodes);
    availableDates.put("20201001", timeSlotCodes);

    Map<String, List<TimeSlot>> expected = new LinkedHashMap<>();
    List<TimeSlot> expectedTimeSlot = new ArrayList<>();
    TimeSlot timeSlot1 = new TimeSlot("00", TimeSlotCode.getDescriptionFor("00"), false);
    TimeSlot timeSlot2 = new TimeSlot("53", TimeSlotCode.getDescriptionFor("53"), true);
    TimeSlot timeSlot3 = new TimeSlot("56", TimeSlotCode.getDescriptionFor("56"), false);

    expectedTimeSlot.add(timeSlot1);
    expectedTimeSlot.add(timeSlot2);
    expectedTimeSlot.add(timeSlot3);
    expected.put("20200930", expectedTimeSlot);
    expected.put("20201001", expectedTimeSlot);

    when(ecoDeliverySlotChecker.isEligible(any(), anyString(), any()))
    .thenReturn(false);
    when(ecoDeliverySlotChecker.isEligible("20200930", "53", "1003"))
    .thenReturn(true);
    when(ecoDeliverySlotChecker.isEligible("20201001", "53", "1003"))
    .thenReturn(true);

    LinkedList<TrackingInfo> trackingInfoList = new LinkedList<>();
    trackingInfoList.add(new TrackingInfo("12345", REDELIVERY_REQUEST,
        POINTS_PER_TRACKING_NUMBER, singletonList("item"),"1"));
    trackingInfoList.add(new TrackingInfo("67890", REDELIVERY_REQUEST,
        POINTS_PER_TRACKING_NUMBER, singletonList("item"),null));

    LocalDate tomorrow = LocalDate.now().plusDays(1);
    DeliveryChangeEntityId deliveryChangeId  = new DeliveryChangeEntityId("1003","12345");


    DeliveryChangeEntity deliveryChangeInfo = new DeliveryChangeEntity(
        deliveryChangeId, "1", tomorrow,
        "20:00~21:00", "56", false, null, DATE_CHANGE_REQUEST);

    lenient().when(deliveryChangeRepository.findById(deliveryChangeId)).thenReturn(Optional.of(deliveryChangeInfo));

    when(japanPostService.getCommonAvailableDates(trackingInfoList))
    .thenReturn(availableDates);

    Map<String, List<TimeSlot>> response = service
        .availableDates(trackingInfoList, "1003");

    assertThat(response.size()).isEqualTo(2);
    assertThat(response.get("20200930").size()).isEqualTo(3);
    assertThat(response.get("20200930").get(0)).isEqualToComparingFieldByField(timeSlot1);
    assertThat(response.get("20200930").get(1)).isEqualToComparingFieldByField(timeSlot2);
    assertThat(response.get("20200930").get(2)).isEqualToComparingFieldByField(timeSlot3);

    assertThat(response.get("20201001").size()).isEqualTo(3);
    assertThat(response.get("20201001").get(0)).isEqualToComparingFieldByField(timeSlot1);
    assertThat(response.get("20201001").get(1)).isEqualToComparingFieldByField(timeSlot2);
    assertThat(response.get("20201001").get(2)).isEqualToComparingFieldByField(timeSlot3);
  }
}