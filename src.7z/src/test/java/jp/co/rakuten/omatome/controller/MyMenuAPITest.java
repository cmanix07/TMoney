package jp.co.rakuten.omatome.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.net.URI;

import org.junit.jupiter.api.Test;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.util.UriComponentsBuilder;

import jp.co.rakuten.omatome.response.MyMenuResponse;
import jp.co.rakuten.omatome.utils.OmatomeConstants;

public class MyMenuAPITest extends BaseControllerTest{

	@Test
	public void myMenuApiTest() {
		headers.add("DEVICE_ID", "1");
		httpRequestEntity = new HttpEntity<>(headers);
		String myMenyApiUrl = baseUrl + "/myMenu";
		UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(myMenyApiUrl);
		URI requestUri = builder.build().encode().toUri();
 		ResponseEntity<MyMenuResponse> response = template.exchange(requestUri, HttpMethod.GET, httpRequestEntity, MyMenuResponse.class);
		
		assertEquals(HttpStatus.OK,response.getStatusCode());
		assertEquals(OmatomeConstants.APP_LIST_URL,response.getBody().getAppListUrl());
		assertEquals(OmatomeConstants.PRIVACY_POLICY_URL,response.getBody().getPrivacyPolicyUrl());
		assertEquals(OmatomeConstants.LICENSE_URL,response.getBody().getLicenseUrl());
		assertEquals(true,response.getBody().isNotificationEnabled());
	}
	
}
