package jp.co.rakuten.omatome.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.net.URI;

import org.junit.jupiter.api.Test;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.util.UriComponentsBuilder;

public class UpdateNotificationAPITest extends BaseControllerTest{

	@Test
	public void updateNotificationApiTest() {
		headers.add("DEVICE_ID", "1");
		httpRequestEntity = new HttpEntity<>(headers);
		String updateNotificationApiUrl = baseUrl + "/update-notification?notificationEnable=true";
		UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(updateNotificationApiUrl);
		URI requestUri = builder.build().encode().toUri();
 		ResponseEntity<?> response = template.exchange(requestUri, HttpMethod.POST, httpRequestEntity,Object.class);
		
		assertEquals(HttpStatus.OK,response.getStatusCode());
		
	}
	
}
