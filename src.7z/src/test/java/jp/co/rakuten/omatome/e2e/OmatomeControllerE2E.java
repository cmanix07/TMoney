package jp.co.rakuten.omatome.e2e;

import static java.util.Collections.singletonList;
import static jp.co.rakuten.omatome.utils.OmatomeConstants.POINTS_PER_TRACKING_NUMBER;
import static jp.co.rakuten.omatome.utils.OmatomeConstants.REDELIVERY_REQUEST;

import java.util.LinkedList;

import org.junit.jupiter.api.Test;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;

import jp.co.rakuten.omatome.model.TrackingInfo;
import jp.co.rakuten.omatome.request.ModifyDeliveryRequest;
import jp.co.rakuten.omatome.response.DeliveryChangeResponse;

public class OmatomeControllerE2E extends BaseE2ETest{
  public static final String CONTACT_NUMBER = "01234567890";
  public static final String COMPANY_NUMBER = "1003";
  
  @Test
  public void shouldDateChangeOneTrackingNumber_Scenario_01() {
   
    HttpHeaders headers = new HttpHeaders();
    headers.set("RAE_ACCESS_TOKEN", token);      
   
    
    LinkedList<TrackingInfo> trackingInfoList = new LinkedList<>();
    TrackingInfo trackingInfo1 = new TrackingInfo("8000000001", REDELIVERY_REQUEST,
        POINTS_PER_TRACKING_NUMBER, singletonList("item"),null);
    trackingInfoList.add(trackingInfo1);
    
    ModifyDeliveryRequest modifyDeliveryRequest = new ModifyDeliveryRequest(trackingInfoList, "20200801","53","1003",true);
    HttpEntity<ModifyDeliveryRequest> request = new HttpEntity<>(modifyDeliveryRequest, headers);
    ResponseEntity<?> response = template.postForEntity(deliveryChangeUrl, request, DeliveryChangeResponse.class);
    System.out.println(response);
  }
  
}
