package jp.co.rakuten.omatome.controller;

import static jp.co.rakuten.omatome.utils.OmatomeConstants.SUCCESS_RESPONSE_CODE;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;

import java.net.URI;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.util.UriComponentsBuilder;

import jp.co.rakuten.omatome.response.PointAllocationHistoryResponseDTO;
import jp.co.rakuten.omatome.response.PointAllocationInfo;

public class PointAllocationHistoryTest extends BaseControllerTest {

	private String pointHistoryUri = "";

	@BeforeAll
	public void init() {
		httpRequestEntity = new HttpEntity<>(headers);
		pointHistoryUri = baseUrl + "/point-history";
	}

	@Test
	public void testPointAllocationHistoryApi() {
		UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(pointHistoryUri);
		URI requestUri = builder.build().encode().toUri();
		ResponseEntity<PointAllocationHistoryResponseDTO> response = template.exchange(requestUri, HttpMethod.GET,
				httpRequestEntity, PointAllocationHistoryResponseDTO.class);

		assertEquals(HttpStatus.OK,response.getStatusCode());
		
		PointAllocationInfo pointAllocationInfo = response.getBody().getPointHistoryList().get(0);
		assertPointAllocationHistoryData(pointAllocationInfo, "1001",0, null, "1003",false);
		pointAllocationInfo = response.getBody().getPointHistoryList().get(1);
		assertPointAllocationHistoryData(pointAllocationInfo, "1002,1003",0, null, "1003",true);
		pointAllocationInfo = response.getBody().getPointHistoryList().get(2);
		assertPointAllocationHistoryData(pointAllocationInfo, "4001",10, "4002", "1028",true);
		pointAllocationInfo = response.getBody().getPointHistoryList().get(3);
		assertPointAllocationHistoryData(pointAllocationInfo, "4004,4005",20, null, "1028",true);
		pointAllocationInfo = response.getBody().getPointHistoryList().get(4);
		assertPointAllocationHistoryData(pointAllocationInfo, "4006",0, null, "1028",false);
	}
	
	
	public void assertPointAllocationHistoryData(
			PointAllocationInfo pointAllocationInfo,String trackingNumber,
			Integer points,String pointNotAllocatedTrackingNumber,
			String companyNumber,boolean annotationFlag) {
		assertEquals(trackingNumber,pointAllocationInfo.getTrackingNumber());
		assertEquals(points,pointAllocationInfo.getPoints());
		assertEquals(pointNotAllocatedTrackingNumber,pointAllocationInfo.getPointNotAllocatedTrackingNumber());
		assertEquals(companyNumber,pointAllocationInfo.getCompanyNumber());
		assertEquals(annotationFlag,pointAllocationInfo.isAnnotationFlag());
		
	}
	
}
