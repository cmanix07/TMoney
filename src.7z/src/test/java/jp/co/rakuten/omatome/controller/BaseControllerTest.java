package jp.co.rakuten.omatome.controller;

import jp.co.rakuten.omatome.Application;
import org.json.JSONObject;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestInstance.Lifecycle;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@ExtendWith({SpringExtension.class, MockitoExtension.class})
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT, classes = {Application.class})
@TestInstance(Lifecycle.PER_CLASS)
public abstract class BaseControllerTest {

	/**
	 * The root testing url
	 */
	private static final String HTTP_LOCALHOST = "http://localhost:";

	/**
	 * The root path uri of our tested api
	 */
	@Value("${server.servlet.context-path}")
	public static String rootpath;

	/**
	 * The random port choosen by spring for the tomcat server
	 */
	@LocalServerPort
	public int port;

	/**
	 * Base url of the service
	 */
	public String baseUrl;

	public String myOrderApiUrl;

	public String token;
	
	private String headerAuthorization 	= 	"Authorization";

	/**
	 * Http client used for the tests
	 */
	@Autowired
	public TestRestTemplate template;
	
	public HttpEntity<?> httpRequestEntity;
	
	public HttpHeaders headers = new HttpHeaders();

	@BeforeAll
	public void setUp() {
		baseUrl = HTTP_LOCALHOST + port + OmatomeController.API_PATH;
		myOrderApiUrl = baseUrl + "/myOrders";

		String accessTokenUrl = HTTP_LOCALHOST + port + "/accesstoken";
		String data = "{ \n" + "\"username\":\"omatome_user\",\n" + "\"password\":\"omatome@dev2020\"\n" + "}";
		ResponseEntity<?> response = template.postForEntity(accessTokenUrl, data, JSONObject.class);
		token = response.getHeaders().get("Authorization").toString();
	
		headers.setContentType(MediaType.APPLICATION_JSON);
		List<MediaType> acceptableMediaTypes = new ArrayList<>();
		acceptableMediaTypes.add(MediaType.APPLICATION_JSON);
		headers.setAccept(acceptableMediaTypes);
		token = token.replaceAll("\\[", "");
		token = token.replaceAll("\\]", "");

		headers.add(headerAuthorization,token );
		headers.add("RAE_ACCESS_TOKEN", getRAEToken());
		
	}

	public String getRAEToken(){
      HttpHeaders headers = new HttpHeaders();
      headers.add("Content-Type", MediaType.APPLICATION_FORM_URLENCODED.toString());

      MultiValueMap<String, String> params = new LinkedMultiValueMap<>();

      params.add("grant_type", "password");
      params.add("client_id", "omatomeuser_android");
      params.add("client_secret", "suRxWrWULQrBDLjXaSWdkJDJM9HF_02t6CLh9l3ftpSq");
      params.add("scope",
        "90days@Refresh,pnp_common_sethistorystatus,pnp_common_getunreadcount,pnp_android_denytype_update,pnp_android_denytype_check,pnp_common_pushedhistory,30days@Access,pnp_android_register,pnp_android_unregister");
      params.add("username", "logintest30@test.test");
      params.add("password", "111111");

      HttpEntity<MultiValueMap<String, String>> entity = new HttpEntity<>(params, headers);


      Map body = template
        .postForEntity("http://stg-wappeng302zd.zd.rakuten.co.jp/engine/token", entity, Map.class).getBody();
      return body.get("access_token").toString();
    }


}
