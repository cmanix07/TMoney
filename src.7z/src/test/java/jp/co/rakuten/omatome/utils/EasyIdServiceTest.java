package jp.co.rakuten.omatome.utils;

import jp.co.rakuten.omatome.exception.OmatomeException;
import jp.co.rakuten.omatome.response.rae.EasyIdResponse;
import jp.co.rakuten.omatome.response.rae.TokenResponse;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.platform.runner.JUnitPlatform;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.atMostOnce;
import static org.mockito.Mockito.lenient;

@ExtendWith(MockitoExtension.class)
@RunWith(JUnitPlatform.class)
class EasyIdServiceTest {
  @Mock
  private RestTemplate restTemplate;


  @Test
  void shouldGetEasyIdFromRAEToken() {
    String clientId = "omatomeuser_server";
    String raeToken = "wertyuiolkjhgfghj";
    String clientSecret = "0AQMfru5xcG1oaH_oAF152MpHANzPn_mGqTI6jIx6bD2";
    EasyIdService easyIdService = new EasyIdService(restTemplate, "baseUrl", clientId, clientSecret);


    lenient().when(restTemplate
      .postForEntity("baseUrl/engine/token", accessTokenRequest(clientId, clientSecret), TokenResponse.class))
      .thenReturn(ResponseEntity.ok().body(new TokenResponse("access_token")));

    lenient().when(restTemplate
      .postForEntity("baseUrl/engine/api/Auth/AccessValidate/20170207", easyIdRequest(raeToken), EasyIdResponse.class))
      .thenReturn(ResponseEntity.ok().body(new EasyIdResponse("easyId")));

    String easyId = easyIdService.getEasyId(raeToken);

    assertThat(easyId).isEqualTo("easyId");
    Mockito.verify(restTemplate, atMostOnce()).postForEntity("", easyIdRequest(raeToken), EasyIdResponse.class);
  }

  @Test
  void shouldThrowOmatomeExceptionIfEasyIdIsNull() {
    String clientId = "omatomeuser_server";
    String raeToken = "wertyuiolkjhgfghj";
    String clientSecret = "0AQMfru5xcG1oaH_oAF152MpHANzPn_mGqTI6jIx6bD2";
    EasyIdService easyIdService = new EasyIdService(restTemplate, "baseUrl", clientId, clientSecret);


    lenient().when(restTemplate
      .postForEntity("baseUrl/engine/token", accessTokenRequest(clientId, clientSecret), TokenResponse.class))
      .thenReturn(ResponseEntity.ok().body(new TokenResponse("access_token")));

    lenient().when(restTemplate
      .postForEntity("baseUrl/engine/api/Auth/AccessValidate/20170207", easyIdRequest(raeToken), EasyIdResponse.class))
      .thenReturn(ResponseEntity.ok().body(new EasyIdResponse(null)));

    Assertions.assertThrows(OmatomeException.class, () -> easyIdService.getEasyId(raeToken));
  }

  @Test
  void shouldThrowOmatomeExceptionIfFailureDuringGettingEasyId() {
    String clientId = "omatomeuser_server";
    String raeToken = "wertyuiolkjhgfghj";
    String clientSecret = "0AQMfru5xcG1oaH_oAF152MpHANzPn_mGqTI6jIx6bD2";
    EasyIdService easyIdService = new EasyIdService(restTemplate, "baseUrl", clientId, clientSecret);


    lenient().when(restTemplate
      .postForEntity("baseUrl/engine/token", accessTokenRequest(clientId, clientSecret), TokenResponse.class))
      .thenReturn(ResponseEntity.ok().body(new TokenResponse("access_token")));

    lenient().when(restTemplate
      .postForEntity("baseUrl/engine/api/Auth/AccessValidate/20170207", easyIdRequest(raeToken), EasyIdResponse.class))
      .thenThrow(RuntimeException.class);

    Assertions.assertThrows(OmatomeException.class, () -> easyIdService.getEasyId(raeToken));
  }

  private HttpEntity<MultiValueMap<String, String>> accessTokenRequest(String clientId, String clientSecret) {
    HttpHeaders headers = new HttpHeaders();
    headers.add("Content-Type", MediaType.APPLICATION_FORM_URLENCODED.toString());
    MultiValueMap<String, String> params = new LinkedMultiValueMap<>();
    params.add("client_id", clientId);
    params.add("client_secret", clientSecret);
    params.add("scope", "rae_access_validate");
    params.add("grant_type", "client_credentials");

    return new HttpEntity<>(params, headers);
  }

  private HttpEntity<MultiValueMap<String, String>> easyIdRequest(String raeToken) {
    HttpHeaders headers = new HttpHeaders();
    headers.add("Content-Type", MediaType.APPLICATION_FORM_URLENCODED.toString());
    headers.add("Authorization", "OAuth2 " + "access_token");

    MultiValueMap<String, String> params = new LinkedMultiValueMap<>();
    params.add("validate_token", raeToken);
    params.add("validate_scope", "pnp_common_sethistorystatus");

    return new HttpEntity<>(params, headers);
  }

}