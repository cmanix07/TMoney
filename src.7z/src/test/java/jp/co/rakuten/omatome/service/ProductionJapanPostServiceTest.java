package jp.co.rakuten.omatome.service;

import com.gargoylesoftware.htmlunit.ElementNotFoundException;
import com.gargoylesoftware.htmlunit.FailingHttpStatusCodeException;
import com.gargoylesoftware.htmlunit.WebClient;
import com.gargoylesoftware.htmlunit.html.*;
import jp.co.rakuten.omatome.exception.JapanPostProcessingException;
import jp.co.rakuten.omatome.model.TrackingInfo;
import jp.co.rakuten.omatome.service.japanpost.production.ProductionJapanPostService;
import jp.co.rakuten.omatome.utils.ThreadSafeWebClientGenerator;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.platform.runner.JUnitPlatform;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;

import java.io.IOException;
import java.util.*;

import static java.util.Collections.singletonList;
import static jp.co.rakuten.omatome.service.japanpost.production.ProductionJapanPostService.*;
import static jp.co.rakuten.omatome.utils.OmatomeConstants.*;
import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.lenient;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
@RunWith(JUnitPlatform.class)
class ProductionJapanPostServiceTest {

  @Mock
  private ThreadSafeWebClientGenerator threadSafeWebClientGenerator;

  @Mock
  private WebClient webClient;

  @Mock
  private HtmlForm form;

  @Mock
  private HtmlInput input;

  @Mock
  private List<HtmlInput> list;

  @Mock
  private HtmlRadioButtonInput htmlRadioButtonInput;

  @Mock
  private HtmlTable htmlTable;

  @Mock
  private HtmlPage htmlPage;

  @Mock
  private HtmlTableRow htmlTableRow;

  @Mock
  private HtmlTableCell htmlTableCell;

  @Mock
  private DomNode domNode;

  @Mock
  private NamedNodeMap namedNodeMap;

  @Mock
  private Node node;

  private ProductionJapanPostService productionJapanPostService;
  private LinkedHashMap<String, Set<String>> expectedAvailableDateAndTimeSlots;
  private HashSet<String> timeSlots;

  @BeforeEach
  void setUp() throws IOException {
    setUpMocksForAvailableDates(Arrays
      .asList("20200611", "20200612", "20200613", "20200614", "20200612", "20200613", "20200614", "20200615"));
    productionJapanPostService = new ProductionJapanPostService("", threadSafeWebClientGenerator);

    expectedAvailableDateAndTimeSlots = new LinkedHashMap<>();
    timeSlots = new LinkedHashSet<>();
    timeSlots.addAll(Arrays.asList("00", "51", "52", "53", "54", "55", "57", "56"));
  }

  @Test
  void shouldCallJPAPIAndGetTheDatesAvailableForChange() {
    expectedAvailableDateAndTimeSlots.put("20200611", timeSlots);
    expectedAvailableDateAndTimeSlots.put("20200612", timeSlots);
    expectedAvailableDateAndTimeSlots.put("20200613", timeSlots);
    expectedAvailableDateAndTimeSlots.put("20200614", timeSlots);

    Map<String, Set<String>> commonAvailableDates = productionJapanPostService
      .getCommonAvailableDates(Collections.singletonList(new TrackingInfo("123456789", REDELIVERY_REQUEST,
        POINTS_PER_TRACKING_NUMBER, singletonList("item"),null)));

    assertThat(commonAvailableDates).isEqualTo(expectedAvailableDateAndTimeSlots);
  }

  @Test
  void shouldReturnCommonDeliveryDatesForAllTrackingNumbersForRedeliveryRequest() {
    expectedAvailableDateAndTimeSlots.put("20200612", timeSlots);
    expectedAvailableDateAndTimeSlots.put("20200613", timeSlots);
    expectedAvailableDateAndTimeSlots.put("20200614", timeSlots);

    Map<String, Set<String>> commonAvailableDates = productionJapanPostService
      .getCommonAvailableDates(Arrays.asList(
        new TrackingInfo("123456789", REDELIVERY_REQUEST,
          POINTS_PER_TRACKING_NUMBER, singletonList("item"),null),
        new TrackingInfo("4567891288", REDELIVERY_REQUEST,
          POINTS_PER_TRACKING_NUMBER, singletonList("item"),null)));

    assertThat(commonAvailableDates).isEqualTo(expectedAvailableDateAndTimeSlots);
  }

  @Test
  void shouldReturnCommonDeliveryDatesForAllTrackingNumbersForDateChangeRequest() {
    expectedAvailableDateAndTimeSlots.put("20200612", timeSlots);
    expectedAvailableDateAndTimeSlots.put("20200613", timeSlots);
    expectedAvailableDateAndTimeSlots.put("20200614", timeSlots);

    Map<String, Set<String>> commonAvailableDates = productionJapanPostService
      .getCommonAvailableDates(Arrays.asList(
        new TrackingInfo("123456789", DATE_CHANGE_REQUEST,
          POINTS_PER_TRACKING_NUMBER, singletonList("item"),null),
        new TrackingInfo("4567891288", DATE_CHANGE_REQUEST,
          POINTS_PER_TRACKING_NUMBER, singletonList("item"),null)));

    assertThat(commonAvailableDates).isEqualTo(expectedAvailableDateAndTimeSlots);
  }

  @Test
  void shouldReturnEmptyIfNoCommonDates() throws IOException {
    setUpMocksForAvailableDates(Arrays
      .asList("20200611", "20200612", "20200613", "20200614", "20200615", "20200616", "20200617", "20200618"));

    Map<String, Set<String>> availableDates = productionJapanPostService
      .getCommonAvailableDates(Arrays.asList(
        new TrackingInfo("123456789", REDELIVERY_REQUEST,
          POINTS_PER_TRACKING_NUMBER, singletonList("item"),null),
        new TrackingInfo("4567891288", REDELIVERY_REQUEST,
          POINTS_PER_TRACKING_NUMBER, singletonList("item"),null)));

    assertThat(availableDates.size()).isEqualTo(0);
  }

  @Test
  void shouldReturnDatesInOrder() throws IOException {
    setUpMocksForAvailableDates(Arrays
      .asList("20201229", "20201230", "20201231", "20210101", "20201231", "20210101", "20210102", "20210103"));
    expectedAvailableDateAndTimeSlots.put("20201231", timeSlots);
    expectedAvailableDateAndTimeSlots.put("20210101", timeSlots);

    Map<String, Set<String>> commonAvailableDates = productionJapanPostService
      .getCommonAvailableDates(Arrays.asList(
        new TrackingInfo("123456789", REDELIVERY_REQUEST,
          POINTS_PER_TRACKING_NUMBER, singletonList("item"),null),
        new TrackingInfo("4567891288", REDELIVERY_REQUEST,
          POINTS_PER_TRACKING_NUMBER, singletonList("item"),null)));

    assertThat(commonAvailableDates).isEqualTo(expectedAvailableDateAndTimeSlots);
  }

  @Test
  void shouldThrowErrorIfChangeForTrackingNumberIsNotSupportedByJapanPost() {
    lenient().when(htmlPage.getFormByName(DELI_FIRST_DELIVERY_INPUT_ACTION_FORM))
      .thenReturn(form)
      .thenReturn(form);

    Assertions.assertThrows(JapanPostProcessingException.class, () -> productionJapanPostService
      .getCommonAvailableDates(Arrays.asList(
        new TrackingInfo("123456789", REDELIVERY_REQUEST,
          POINTS_PER_TRACKING_NUMBER, singletonList("item"),null),
        new TrackingInfo("4567891288", REDELIVERY_REQUEST,
          POINTS_PER_TRACKING_NUMBER, singletonList("item"),null))));
  }

  @Test
  void shouldReturnEmptyAvailableDatesIfNoTrackingNumber() {
    Map<String, Set<String>> availableDates = productionJapanPostService
      .getCommonAvailableDates(Collections.emptyList());

    assertThat(availableDates.size()).isEqualTo(0);

    availableDates = productionJapanPostService
      .getCommonAvailableDates(null);

    assertThat(availableDates.size()).isEqualTo(0);
  }

  @Test
  void shouldThrowExceptionInCaseFailureWhenGettingDataFromJapanPost() {
    lenient().when(htmlTable.getRows())
      .thenThrow(new FailingHttpStatusCodeException("", null));

    Assertions.assertThrows(JapanPostProcessingException.class, () -> productionJapanPostService
      .getCommonAvailableDates(Arrays.asList(
        new TrackingInfo("123456789", REDELIVERY_REQUEST,
          POINTS_PER_TRACKING_NUMBER, singletonList("item"),null),
        new TrackingInfo("4567891288", REDELIVERY_REQUEST,
          POINTS_PER_TRACKING_NUMBER, singletonList("item"),null))));
  }

  @Test
  void shouldSubmitDateAndTimeChangeToJapanPost() {
    when(htmlPage.getFormByName(DELIVERY_DETAIL_FORM)).thenReturn(form);
    when(htmlPage.getFormByName(DELIVERY_CONFIRM_FORM)).thenReturn(form);
    when(form.getInputByValue("20200613,56")).thenReturn(input);
    when(form.getInputByName("submit")).thenReturn(input);

    LinkedList<TrackingInfo> trackingInfoList = new LinkedList<>();
    trackingInfoList.add(new TrackingInfo("123456789", REDELIVERY_REQUEST,
      POINTS_PER_TRACKING_NUMBER, singletonList("item"),null));
    trackingInfoList.add(new TrackingInfo("4567891288", REDELIVERY_REQUEST,
      POINTS_PER_TRACKING_NUMBER, singletonList("item"),null));

    Map<String, List<TrackingInfo>> result = productionJapanPostService.updateDelivery(trackingInfoList,
      "20200613", "56", "phoneNumber");

    assertTrue(result.get("SUCCESS").containsAll(trackingInfoList));
  }

  @Test
  void shouldContinueEvenIfChangingDeliveryDateFailsForSomeTrackingNumbers() {
    when(htmlPage.getFormByName(DELIVERY_DETAIL_FORM)).thenReturn(form);
    when(htmlPage.getFormByName(DELIVERY_CONFIRM_FORM)).thenReturn(form);
    when(form.getInputByValue("20200613,56"))
      .thenThrow(ElementNotFoundException.class)
      .thenReturn(input);
    when(form.getInputByName("submit")).thenReturn(input);

    LinkedList<TrackingInfo> trackingInfoList = new LinkedList<>();
    trackingInfoList.add(new TrackingInfo("123456789", REDELIVERY_REQUEST,
      POINTS_PER_TRACKING_NUMBER, singletonList("item"),null));
    trackingInfoList.add(new TrackingInfo("4567891288", REDELIVERY_REQUEST,
      POINTS_PER_TRACKING_NUMBER, singletonList("item"),null));

    Map<String, List<TrackingInfo>> result = productionJapanPostService.updateDelivery(trackingInfoList,
      "20200613", "56", "phoneNumber");

    assertThat(result.get("SUCCESS").get(0).getTrackingNumber()).isEqualTo("4567891288");
    assertThat(result.get("FAILURE").get(0).getTrackingNumber()).isEqualTo("123456789");
  }

  private void setUpMocksForAvailableDates(List<String> dates) throws IOException {
    lenient().when(threadSafeWebClientGenerator.generate()).thenReturn(webClient);

    lenient().when(webClient.getPage(anyString()))
      .thenReturn(htmlPage);

    lenient().when(htmlPage.getFormByName(DELI_DELIVERY_RECEIPT_ACTION_FORM))
      .thenReturn(form);
    lenient().when(htmlPage.getFormByName(DELI_FIRST_DELIVERY_INPUT_ACTION_FORM))
      .thenReturn(form)
      .thenThrow(ElementNotFoundException.class)
      .thenReturn(form)
      .thenThrow(ElementNotFoundException.class);

    lenient().when(form.getInputsByName(anyString()))
      .thenReturn(list);

    lenient().when(list.get(0))
      .thenReturn(input);
    lenient().when(form.getInputByName(anyString()))
      .thenReturn(input);
    lenient().when(form.getRadioButtonsByName(anyString()))
      .thenReturn(Collections.singletonList(htmlRadioButtonInput));
    lenient().when(input.click())
      .thenReturn(htmlPage);

    lenient().when(htmlPage.getByXPath(ProductionJapanPostService.AVAILABLE_DATES_TABLE_XPATH))
      .thenReturn(Collections.singletonList(htmlTable));

    lenient().when(htmlTable.getRows())
      .thenReturn(Arrays.asList(
        htmlTableRow, htmlTableRow,
        htmlTableRow, htmlTableRow,
        htmlTableRow, htmlTableRow));
    lenient().when(htmlTableRow.getCells())
      .thenReturn(Arrays.asList(
        htmlTableCell,
        htmlTableCell, htmlTableCell,
        htmlTableCell, htmlTableCell,
        htmlTableCell, htmlTableCell,
        htmlTableCell, htmlTableCell));
    lenient().when(htmlTableRow.getCell(0))
      .thenReturn(htmlTableCell);
    lenient().when(htmlTableRow.getCell(anyInt()))
      .thenReturn(htmlTableCell);

    lenient().when(htmlTableCell.getFirstChild()).thenReturn(domNode);
    lenient().when(domNode.getAttributes()).thenReturn(namedNodeMap);
    lenient().when(namedNodeMap.getLength()).thenReturn(1);
    lenient().when(namedNodeMap.getNamedItem("value")).thenReturn(node);

    //for two tracking numbers
    lenient().when(node.getTextContent())
      .thenReturn(dates.get(0) + ",00").thenReturn(dates.get(0) + ",51")
      .thenReturn(dates.get(0) + ",52").thenReturn(dates.get(0) + ",53")
      .thenReturn(dates.get(0) + ",54").thenReturn(dates.get(0) + ",55")
      .thenReturn(dates.get(0) + ",57").thenReturn(dates.get(0) + ",56")

      .thenReturn(dates.get(1) + ",00").thenReturn(dates.get(1) + ",51")
      .thenReturn(dates.get(1) + ",52").thenReturn(dates.get(1) + ",53")
      .thenReturn(dates.get(1) + ",54").thenReturn(dates.get(1) + ",55")
      .thenReturn(dates.get(1) + ",57").thenReturn(dates.get(1) + ",56")

      .thenReturn(dates.get(2) + ",00").thenReturn(dates.get(2) + ",51")
      .thenReturn(dates.get(2) + ",52").thenReturn(dates.get(2) + ",53")
      .thenReturn(dates.get(2) + ",54").thenReturn(dates.get(2) + ",55")
      .thenReturn(dates.get(2) + ",57").thenReturn(dates.get(2) + ",56")

      .thenReturn(dates.get(3) + ",00").thenReturn(dates.get(3) + ",51")
      .thenReturn(dates.get(3) + ",52").thenReturn(dates.get(3) + ",53")
      .thenReturn(dates.get(3) + ",54").thenReturn(dates.get(3) + ",55")
      .thenReturn(dates.get(3) + ",57").thenReturn(dates.get(3) + ",56")

      .thenReturn(dates.get(4) + ",00").thenReturn(dates.get(4) + ",51")
      .thenReturn(dates.get(4) + ",52").thenReturn(dates.get(4) + ",53")
      .thenReturn(dates.get(4) + ",54").thenReturn(dates.get(4) + ",55")
      .thenReturn(dates.get(4) + ",57").thenReturn(dates.get(4) + ",56")

      .thenReturn(dates.get(5) + ",00").thenReturn(dates.get(5) + ",51")
      .thenReturn(dates.get(5) + ",52").thenReturn(dates.get(5) + ",53")
      .thenReturn(dates.get(5) + ",54").thenReturn(dates.get(5) + ",55")
      .thenReturn(dates.get(5) + ",57").thenReturn(dates.get(5) + ",56")

      .thenReturn(dates.get(6) + ",00").thenReturn(dates.get(6) + ",51")
      .thenReturn(dates.get(6) + ",52").thenReturn(dates.get(6) + ",53")
      .thenReturn(dates.get(6) + ",54").thenReturn(dates.get(6) + ",55")
      .thenReturn(dates.get(6) + ",57").thenReturn(dates.get(6) + ",56")

      .thenReturn(dates.get(7) + ",00").thenReturn(dates.get(7) + ",51")
      .thenReturn(dates.get(7) + ",52").thenReturn(dates.get(7) + ",53")
      .thenReturn(dates.get(7) + ",54").thenReturn(dates.get(7) + ",55")
      .thenReturn(dates.get(7) + ",57").thenReturn(dates.get(7) + ",56");

  }
}