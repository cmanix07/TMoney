package jp.co.rakuten.omatome.controller;

/*@ExtendWith(MockitoExtension.class)
@TestInstance(Lifecycle.PER_CLASS)*/
public class PointAllocationHistoryUnitTest {
/*	
	*//**
		 * The root testing url
		 */
	/*
	private static final String HTTP_LOCALHOST = "http://localhost:";
	
	*//**
		 * The root path uri of our tested api
		 */
	/*
	@Value("${server.servlet.context-path}")
	public static String rootpath;
	
	*//**
		 * The random port choosen by spring for the tomcat server
		 */
	/*
	@LocalServerPort
	public int port;
	
	*//**
		 * Base url of the service
		 */
	/*
	public String baseUrl;
	
	public String myOrderApiUrl;
	
	public String token;
	
	private String headerAuthorization 	= 	"Authorization";
	
	*//**
		 * Http client used for the tests
		 *//*
			@Autowired
			public TestRestTemplate template;
			
			public HttpEntity<?> httpRequestEntity;
			
			public HttpHeaders headers = new HttpHeaders();
			
			static WireMockServer wireMockServer;
			
			@BeforeAll
			public void setUp() {
			wireMockServer = new WireMockServer(9999);
			wireMockServer.start();
			
			baseUrl = HTTP_LOCALHOST + port + OmatomeController.API_PATH;
			myOrderApiUrl = baseUrl + "/myOrders";
			
			String accessTokenUrl = HTTP_LOCALHOST + port + "/accesstoken";
			String data = "{ \n" + "\"username\":\"omatome_user\",\n" + "\"password\":\"omatome@dev2020\"\n" + "}";
			ResponseEntity<?> response = template.postForEntity(accessTokenUrl, data, JSONObject.class);
			token = response.getHeaders().get("Authorization").toString();
			
			headers.setContentType(MediaType.APPLICATION_JSON);
			List<MediaType> acceptableMediaTypes = new ArrayList<>();
			acceptableMediaTypes.add(MediaType.APPLICATION_JSON);
			headers.setAccept(acceptableMediaTypes);
			token = token.replaceAll("\\[", "");
			token = token.replaceAll("\\]", "");
			
			headers.add(headerAuthorization,token );
			headers.add("easyId", "1");
			
			}
			@Test
			public void shouldHanldeBadRequestException() {
			wireMockServer
			.stubFor(get(urlEqualTo("/point-history"))
					.willReturn(aResponse()
							.withHeader("Content-Type", "Application/json; charset=Shift_JIS")
							.withHeader("Connection", "close")
							.withHeader("Transfer-Encoding", "chunked")
							.withStatus(401)
							.withBody("{\"status\": \"401\", \"message\": \"A failure occurred as client is not initialized. Please initialize the RediClient.\"}")));
			
			
			
			}
			*/

}
