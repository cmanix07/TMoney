package jp.co.rakuten.omatome.service;

import static org.junit.Assert.assertNull;
import static org.junit.jupiter.api.Assertions.assertEquals;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

import jp.co.rakuten.omatome.entity.DeliveryInfoEntity;
import jp.co.rakuten.omatome.entity.OmatomeTrackingNumberRange;
import jp.co.rakuten.omatome.entity.OmatomeTrackingNumberRangeId;
import jp.co.rakuten.omatome.model.DeliveryChangeRequestInfo;
import jp.co.rakuten.omatome.model.OrderDetails;
import jp.co.rakuten.omatome.response.MyOrderResponseDTO;
import jp.co.rakuten.omatome.utils.OmatomeConstants;
import jp.co.rakuten.omatome.utils.OmatomeHelper;
import jp.co.rakuten.omatome.utils.ResponseUtils;

@ExtendWith(MockitoExtension.class)
class ResponseUtilsTest {

  @InjectMocks
  private ResponseUtils responseUtils;

  @InjectMocks
  private OmatomeHelper omatomeHelper;

  private List<OrderDetails> orderDetailsList;
  
  private List<DeliveryChangeRequestInfo> deliveryChangeRequestInfoList;
  
  private List<OmatomeTrackingNumberRange> omatomeTrackingNumberRangeList;
  
  private String deliveryRequestUrl = "http://localhost/deliveryRequestURL";
  private String redeliveryRequestUrl = "http://localhost/redeliveryRequestURL";
  
  private LocalDate today;
  private LocalDate tomorrow;

  @BeforeEach
  void setUp() {
    today = LocalDate.now();
    tomorrow = today.plusDays(1);
  }

  @Test
  public void singleNonOmatomeOrdersWithMultipleBasketAndNoDeliveryInfoDataTest() {
    orderDetailsList = new ArrayList<>();
    deliveryChangeRequestInfoList = new ArrayList<>();
    orderDetailsList.add(createOrderDetails("1001", "1003", "12345678901", 1l, "1001ItemName", 1l));
    orderDetailsList.add(createOrderDetails("1001", "1003", null , 2l, "1001ItemName1", 2l));
    Map<String,DeliveryInfoEntity> deliveryInfoMap = new HashMap<>();

    deliveryChangeRequestInfoList = new ArrayList<>();
    
    omatomeTrackingNumberRangeList = new ArrayList<>();
    OmatomeTrackingNumberRange omatomeTrackingNumberRange = createOmatomeTrackingNumberRange("1003", 12345678900l, 12345678910l);
    omatomeTrackingNumberRangeList.add(omatomeTrackingNumberRange);

    MyOrderResponseDTO myOrderResponseDto = responseUtils.getMyOrderResponse(orderDetailsList, deliveryInfoMap, 
    		omatomeHelper.getChangeRequestGroupInfoMap(deliveryChangeRequestInfoList), omatomeTrackingNumberRangeList);
    assertEquals(OmatomeConstants.SUCCESS_RESPONSE_CODE, myOrderResponseDto.getResponseCode());
    assertEquals(0, myOrderResponseDto.getShippingList().size());
  }

  @Test
  public void singleNonOmatomeOrdersWithMultipleBasketTest() {
    orderDetailsList = new ArrayList<>();
    deliveryChangeRequestInfoList = new ArrayList<>();
    orderDetailsList.add(createOrderDetails("1001", "1003", "12345678901", 1l, "1001ItemName", 1l));
    orderDetailsList.add(createOrderDetails("1001", "1003", null , 2l, "1001ItemName1", 2l));
    Map<String,DeliveryInfoEntity> deliveryInfoMap = new HashMap<>();

    String key = omatomeHelper.getDeliveryInfoKey("12345678901", "1003", "1001");
    DeliveryInfoEntity deliveryInfo = createDeliveryInfoEntity("1001", "1003", "12345678901", 2, deliveryRequestUrl, null, today);
    deliveryInfoMap.put(key, deliveryInfo);

    deliveryChangeRequestInfoList = new ArrayList<>();
    
    omatomeTrackingNumberRangeList = new ArrayList<>();
    OmatomeTrackingNumberRange omatomeTrackingNumberRange = createOmatomeTrackingNumberRange("1003", 12345678900l, 12345678910l);
    omatomeTrackingNumberRangeList.add(omatomeTrackingNumberRange);

    MyOrderResponseDTO myOrderResponseDto = responseUtils.getMyOrderResponse(orderDetailsList, deliveryInfoMap, 
    		omatomeHelper.getChangeRequestGroupInfoMap(deliveryChangeRequestInfoList), omatomeTrackingNumberRangeList);
    assertEquals(OmatomeConstants.SUCCESS_RESPONSE_CODE, myOrderResponseDto.getResponseCode());
    assertEquals(1, myOrderResponseDto.getShippingList().size());
    assertEquals(1, myOrderResponseDto.getShippingList().get(0).getTrackingNumberDetails().size());
    assertEquals(1, myOrderResponseDto.getShippingList().get(0).getTrackingNumberDetails().get(0).getOrderList().size());
    assertEquals(2, myOrderResponseDto.getShippingList().get(0).getTrackingNumberDetails().get(0).getOrderList().get(0).getItemDetails().size());
    assertEquals(OmatomeConstants.DATE_CHANGE_REQUEST, myOrderResponseDto.getShippingList().get(0).getTrackingNumberDetails().get(0).getChangeType());
    assertEquals(true, myOrderResponseDto.getShippingList().get(0).isDeliveryDateToday());
    assertEquals(OmatomeConstants.DATE_CHANGE_REQUEST, myOrderResponseDto.getShippingList().get(0).getChangeTypeDisplay());

  }

  @Test
  public void multipleNonOmatomeOrdersWithMultipleBasketAndTrackingNumberNullTest() {
    orderDetailsList = new ArrayList<>();
    deliveryChangeRequestInfoList = new ArrayList<>();
    orderDetailsList.add(createOrderDetails("1001", "1003", "12345678901", 1l, "1001ItemName", 1l));
    orderDetailsList.add(createOrderDetails("1002", "1003", null , 2l, "1002ItemName1", 2l));
    Map<String,DeliveryInfoEntity> deliveryInfoMap = new HashMap<>();
    
    String key = omatomeHelper.getDeliveryInfoKey("12345678901", "1003", "1001");
    DeliveryInfoEntity deliveryInfo = createDeliveryInfoEntity("1001", "1003", "12345678901", 4, deliveryRequestUrl, null, tomorrow);
    deliveryInfoMap.put(key, deliveryInfo);

    deliveryChangeRequestInfoList = new ArrayList<>();
    
    omatomeTrackingNumberRangeList = new ArrayList<>();
    OmatomeTrackingNumberRange omatomeTrackingNumberRange = createOmatomeTrackingNumberRange("1003", 12345678900l, 12345678910l);
    omatomeTrackingNumberRangeList.add(omatomeTrackingNumberRange);

    MyOrderResponseDTO myOrderResponseDto = responseUtils.getMyOrderResponse(orderDetailsList, deliveryInfoMap, 
    		omatomeHelper.getChangeRequestGroupInfoMap(deliveryChangeRequestInfoList), omatomeTrackingNumberRangeList);
    assertEquals(OmatomeConstants.SUCCESS_RESPONSE_CODE, myOrderResponseDto.getResponseCode());
    assertEquals(1, myOrderResponseDto.getShippingList().size());
    assertEquals(false, myOrderResponseDto.getShippingList().get(0).isDeliveryDateToday());
    assertEquals(1, myOrderResponseDto.getShippingList().get(0).getTrackingNumberDetails().size());
    assertEquals(1, myOrderResponseDto.getShippingList().get(0).getTrackingNumberDetails().get(0).getOrderList().size());
    assertEquals(1, myOrderResponseDto.getShippingList().get(0).getTrackingNumberDetails().get(0).getOrderList().get(0).getItemDetails().size());
    assertEquals(OmatomeConstants.DATE_CHANGE_REQUEST, myOrderResponseDto.getShippingList().get(0).getTrackingNumberDetails().get(0).getChangeType());
    assertEquals(OmatomeConstants.DATE_CHANGE_REQUEST, myOrderResponseDto.getShippingList().get(0).getChangeTypeDisplay());

  }

  @Test
  public void multipleNonOmatomeOrdersWithMultipleBasketAndTrackingNumberNullInBetweenTest() {
    orderDetailsList = new ArrayList<>();
    deliveryChangeRequestInfoList = new ArrayList<>();
    orderDetailsList.add(createOrderDetails("1001", "1003", "12345678901", 1l, "1001ItemName1", 1l));
    orderDetailsList.add(createOrderDetails("1001", "1003", null, 1l, "1001ItemName2", 1l));
    orderDetailsList.add(createOrderDetails("1002", "1003", null , 2l, "1002ItemName", 2l));
    orderDetailsList.add(createOrderDetails("1003", "1003", "12345678902" , 2l, "1003ItemName1", 2l));
    orderDetailsList.add(createOrderDetails("1003", "1003", null , 2l, "1003ItemName2", 2l));
    Map<String,DeliveryInfoEntity> deliveryInfoMap = new HashMap<>();
    
    String key = omatomeHelper.getDeliveryInfoKey("12345678901", "1003", "1001");
    DeliveryInfoEntity deliveryInfo = createDeliveryInfoEntity("1001", "1003", "12345678901", 2, deliveryRequestUrl, null, today);
    deliveryInfoMap.put(key, deliveryInfo);
    
    deliveryInfo = createDeliveryInfoEntity("1003", "1003", "12345678902", 3, deliveryRequestUrl, null, today);
    key = omatomeHelper.getDeliveryInfoKey("12345678902", "1003", "1003");
    deliveryInfoMap.put(key, deliveryInfo);
    
    deliveryChangeRequestInfoList = new ArrayList<>();
    
    omatomeTrackingNumberRangeList = new ArrayList<>();
    OmatomeTrackingNumberRange omatomeTrackingNumberRange = createOmatomeTrackingNumberRange("1003", 12345678900l, 12345678910l);
    omatomeTrackingNumberRangeList.add(omatomeTrackingNumberRange);

    MyOrderResponseDTO myOrderResponseDto = responseUtils.getMyOrderResponse(orderDetailsList, deliveryInfoMap, 
    		omatomeHelper.getChangeRequestGroupInfoMap(deliveryChangeRequestInfoList), omatomeTrackingNumberRangeList);
    assertEquals(OmatomeConstants.SUCCESS_RESPONSE_CODE, myOrderResponseDto.getResponseCode());
    assertEquals(2, myOrderResponseDto.getShippingList().size());
    assertEquals(1, myOrderResponseDto.getShippingList().get(0).getTrackingNumberDetails().size());
    assertEquals(1, myOrderResponseDto.getShippingList().get(0).getTrackingNumberDetails().get(0).getOrderList().size());
    assertEquals(2, myOrderResponseDto.getShippingList().get(0).getTrackingNumberDetails().get(0).getOrderList().get(0).getItemDetails().size());
    assertEquals(1, myOrderResponseDto.getShippingList().get(1).getTrackingNumberDetails().get(0).getOrderList().size());
    assertEquals(2, myOrderResponseDto.getShippingList().get(1).getTrackingNumberDetails().get(0).getOrderList().get(0).getItemDetails().size());

  }

  @Test
  public void multipleNonOmatomeOrdersWithSingleBasketAndPointValidationTest() {
    orderDetailsList = new ArrayList<>();
    deliveryChangeRequestInfoList = new ArrayList<>();
    orderDetailsList.add(createOrderDetails("1001", "1003", "12345678901", 1l, "1001ItemName", 1l));
    orderDetailsList.add(createOrderDetails("1002", "1003", "12345678902", 1l, "1002ItemName", 1l));
    Map<String,DeliveryInfoEntity> deliveryInfoMap = new HashMap<>();
    
    String key = omatomeHelper.getDeliveryInfoKey("12345678901", "1003", "1001");
    DeliveryInfoEntity deliveryInfo = createDeliveryInfoEntity("1001", "1003", "12345678901", 2, deliveryRequestUrl, null, tomorrow);
    deliveryInfoMap.put(key, deliveryInfo);
    
    key = omatomeHelper.getDeliveryInfoKey("12345678902", "1003", "1002");
    deliveryInfo = createDeliveryInfoEntity("1002", "1003", "12345678902", 2, deliveryRequestUrl, null, tomorrow);
    deliveryInfoMap.put(key, deliveryInfo);
    
    deliveryChangeRequestInfoList = new ArrayList<>();
    
    omatomeTrackingNumberRangeList = new ArrayList<>();
    OmatomeTrackingNumberRange omatomeTrackingNumberRange = createOmatomeTrackingNumberRange("1003", 12345678900l, 12345678910l);
    omatomeTrackingNumberRangeList.add(omatomeTrackingNumberRange);

    MyOrderResponseDTO myOrderResponseDto = responseUtils.getMyOrderResponse(orderDetailsList, deliveryInfoMap, 
    		omatomeHelper.getChangeRequestGroupInfoMap(deliveryChangeRequestInfoList), omatomeTrackingNumberRangeList);
    assertEquals(OmatomeConstants.SUCCESS_RESPONSE_CODE, myOrderResponseDto.getResponseCode());
    assertEquals(2, myOrderResponseDto.getShippingList().size());
    assertEquals(1, myOrderResponseDto.getShippingList().get(0).getTrackingNumberDetails().size());
    assertEquals(1, myOrderResponseDto.getShippingList().get(1).getTrackingNumberDetails().size());
    assertEquals(10, myOrderResponseDto.getShippingList().get(1).getPoints());
  }

  @Test
  public void multipleNonOmatomeOrdersWithSingleBasketAndInvalidJPDeliveryStatusForDeliveryRequestTest() {
    orderDetailsList = new ArrayList<>();
    deliveryChangeRequestInfoList = new ArrayList<>();
    orderDetailsList.add(createOrderDetails("1001", "1003", "12345678901", 1l, "1001ItemName", 1l));
    orderDetailsList.add(createOrderDetails("1002", "1003", "12345678902", 1l, "1002ItemName", 1l));
    Map<String,DeliveryInfoEntity> deliveryInfoMap = new HashMap<>();
    
    String key = omatomeHelper.getDeliveryInfoKey("12345678901", "1003", "1001");
    DeliveryInfoEntity deliveryInfo = createDeliveryInfoEntity("1001", "1003", "12345678901", 6, deliveryRequestUrl, null, tomorrow);
    deliveryInfoMap.put(key, deliveryInfo);
    
    key = omatomeHelper.getDeliveryInfoKey("12345678902", "1003", "1002");
    deliveryInfo = createDeliveryInfoEntity("1002", "1003", "12345678902", 2, deliveryRequestUrl, null, tomorrow);
    deliveryInfoMap.put(key, deliveryInfo);
    
    deliveryChangeRequestInfoList = new ArrayList<>();
    
    omatomeTrackingNumberRangeList = new ArrayList<>();
    OmatomeTrackingNumberRange omatomeTrackingNumberRange = createOmatomeTrackingNumberRange("1003", 12345678900l, 12345678910l);
    omatomeTrackingNumberRangeList.add(omatomeTrackingNumberRange);

    MyOrderResponseDTO myOrderResponseDto = responseUtils.getMyOrderResponse(orderDetailsList, deliveryInfoMap, 
    		omatomeHelper.getChangeRequestGroupInfoMap(deliveryChangeRequestInfoList), omatomeTrackingNumberRangeList);
    assertEquals(OmatomeConstants.SUCCESS_RESPONSE_CODE, myOrderResponseDto.getResponseCode());
    assertEquals(1, myOrderResponseDto.getShippingList().size());
    assertEquals(1, myOrderResponseDto.getShippingList().get(0).getTrackingNumberDetails().size());
  }

  @Test
  public void multipleNonOmatomeOrdersWithSingleBasketAndInvalidJPDeliveryStatusTest() {
    orderDetailsList = new ArrayList<>();
    deliveryChangeRequestInfoList = new ArrayList<>();
    orderDetailsList.add(createOrderDetails("1001", "1003", "12345678901", 1l, "1001ItemName", 1l));
    orderDetailsList.add(createOrderDetails("1002", "1003", "12345678902", 1l, "1002ItemName", 1l));
    Map<String,DeliveryInfoEntity> deliveryInfoMap = new HashMap<>();
    
    String key = omatomeHelper.getDeliveryInfoKey("12345678901", "1003", "1001");
    DeliveryInfoEntity deliveryInfo = createDeliveryInfoEntity("1001", "1003", "12345678901", 6, deliveryRequestUrl, null, today);
    deliveryInfoMap.put(key, deliveryInfo);
    
    key = omatomeHelper.getDeliveryInfoKey("12345678902", "1003", "1002");
    deliveryInfo = createDeliveryInfoEntity("1002", "1003", "12345678902", 2, null, redeliveryRequestUrl, today);
    deliveryInfoMap.put(key, deliveryInfo);
    
    deliveryChangeRequestInfoList = new ArrayList<>();
    
    omatomeTrackingNumberRangeList = new ArrayList<>();
    OmatomeTrackingNumberRange omatomeTrackingNumberRange = createOmatomeTrackingNumberRange("1003", 12345678900l, 12345678910l);
    omatomeTrackingNumberRangeList.add(omatomeTrackingNumberRange);

    MyOrderResponseDTO myOrderResponseDto = responseUtils.getMyOrderResponse(orderDetailsList, deliveryInfoMap, 
    		omatomeHelper.getChangeRequestGroupInfoMap(deliveryChangeRequestInfoList), omatomeTrackingNumberRangeList);
    assertEquals(OmatomeConstants.SUCCESS_RESPONSE_CODE, myOrderResponseDto.getResponseCode());
    assertEquals(0, myOrderResponseDto.getShippingList().size());
  }

  @Test
  public void multipleNonOmatomeOrdersWithSingleBasketAndJPDeliveryStatusCompletedTest() {
    orderDetailsList = new ArrayList<>();
    deliveryChangeRequestInfoList = new ArrayList<>();
    orderDetailsList.add(createOrderDetails("1001", "1003", "12345678901", 1l, "1001ItemName", 1l));
    orderDetailsList.add(createOrderDetails("1002", "1003", "12345678902", 1l, "1002ItemName", 1l));
    Map<String,DeliveryInfoEntity> deliveryInfoMap = new HashMap<>();
    
    String key = omatomeHelper.getDeliveryInfoKey("12345678901", "1003", "1001");
    DeliveryInfoEntity deliveryInfo = createDeliveryInfoEntity("1001", "1003", "12345678901", 7, deliveryRequestUrl, null, today);
    deliveryInfoMap.put(key, deliveryInfo);
    
    key = omatomeHelper.getDeliveryInfoKey("12345678902", "1003", "1002");
    deliveryInfo = createDeliveryInfoEntity("1002", "1003", "12345678902", 7, null, redeliveryRequestUrl, today);
    deliveryInfoMap.put(key, deliveryInfo);
    
    deliveryChangeRequestInfoList = new ArrayList<>();
    
    omatomeTrackingNumberRangeList = new ArrayList<>();
    OmatomeTrackingNumberRange omatomeTrackingNumberRange = createOmatomeTrackingNumberRange("1003", 12345678900l, 12345678910l);
    omatomeTrackingNumberRangeList.add(omatomeTrackingNumberRange);

    MyOrderResponseDTO myOrderResponseDto = responseUtils.getMyOrderResponse(orderDetailsList, deliveryInfoMap, 
    		omatomeHelper.getChangeRequestGroupInfoMap(deliveryChangeRequestInfoList), omatomeTrackingNumberRangeList);
    assertEquals(OmatomeConstants.SUCCESS_RESPONSE_CODE, myOrderResponseDto.getResponseCode());
    assertEquals(0, myOrderResponseDto.getShippingList().size());
  }

  @Test
  public void multipleNonOmatomeOrdersWithSingleBasketAndInvalidExpressDeliveryStatusForDeliveryRequestTest() {
    orderDetailsList = new ArrayList<>();
    deliveryChangeRequestInfoList = new ArrayList<>();
    orderDetailsList.add(createOrderDetails("1001", "1028", "123456789012", 1l, "1001ItemName", 1l));
    orderDetailsList.add(createOrderDetails("1002", "1028", "123456789023", 1l, "1002ItemName", 1l));
    Map<String,DeliveryInfoEntity> deliveryInfoMap = new HashMap<>();
    
    String key = omatomeHelper.getDeliveryInfoKey("123456789012", "1028", "1001");
    DeliveryInfoEntity deliveryInfo = createDeliveryInfoEntity("1001", "1028", "123456789012", 6, deliveryRequestUrl, null, tomorrow);
    deliveryInfoMap.put(key, deliveryInfo);
    
    key = omatomeHelper.getDeliveryInfoKey("123456789023", "1028", "1002");
    deliveryInfo = createDeliveryInfoEntity("1002", "1028", "123456789023", 10, deliveryRequestUrl, null, tomorrow);
    deliveryInfoMap.put(key, deliveryInfo);
    
    deliveryChangeRequestInfoList = new ArrayList<>();
    
    omatomeTrackingNumberRangeList = new ArrayList<>();
    OmatomeTrackingNumberRange omatomeTrackingNumberRange = createOmatomeTrackingNumberRange("1028", 123456789000l, 123456789100l);
    omatomeTrackingNumberRangeList.add(omatomeTrackingNumberRange);

    MyOrderResponseDTO myOrderResponseDto = responseUtils.getMyOrderResponse(orderDetailsList, deliveryInfoMap, 
    		omatomeHelper.getChangeRequestGroupInfoMap(deliveryChangeRequestInfoList), omatomeTrackingNumberRangeList);
    assertEquals(OmatomeConstants.SUCCESS_RESPONSE_CODE, myOrderResponseDto.getResponseCode());
    assertEquals(1, myOrderResponseDto.getShippingList().size());
    assertEquals(1, myOrderResponseDto.getShippingList().get(0).getTrackingNumberDetails().size());
  }

  @Test
  public void multipleNonOmatomeOrdersWithSingleBasketAndDeliveryAndRedeliveryUrlTest() {
    orderDetailsList = new ArrayList<>();
    deliveryChangeRequestInfoList = new ArrayList<>();
    orderDetailsList.add(createOrderDetails("1001", "1003", "12345678901", 1l, "1001ItemName", 1l));
    orderDetailsList.add(createOrderDetails("1002", "1003", "12345678902", 1l, "1002ItemName", 1l));
    Map<String,DeliveryInfoEntity> deliveryInfoMap = new HashMap<>();
    
    String key = omatomeHelper.getDeliveryInfoKey("12345678901", "1003", "1001");
    DeliveryInfoEntity deliveryInfo = createDeliveryInfoEntity("1001", "1003", "12345678901", 2, deliveryRequestUrl, null, tomorrow);
    deliveryInfoMap.put(key, deliveryInfo);
    
    key = omatomeHelper.getDeliveryInfoKey("12345678902", "1003", "1002");
    deliveryInfo = createDeliveryInfoEntity("1002", "1003", "12345678902", 5, null, redeliveryRequestUrl, tomorrow);
    deliveryInfoMap.put(key, deliveryInfo);
    
    deliveryChangeRequestInfoList = new ArrayList<>();
    
    omatomeTrackingNumberRangeList = new ArrayList<>();
    OmatomeTrackingNumberRange omatomeTrackingNumberRange = createOmatomeTrackingNumberRange("1003", 12345678900l, 12345678910l);
    omatomeTrackingNumberRangeList.add(omatomeTrackingNumberRange);

    MyOrderResponseDTO myOrderResponseDto = responseUtils.getMyOrderResponse(orderDetailsList, deliveryInfoMap, 
    		omatomeHelper.getChangeRequestGroupInfoMap(deliveryChangeRequestInfoList), omatomeTrackingNumberRangeList);
    assertEquals(OmatomeConstants.SUCCESS_RESPONSE_CODE, myOrderResponseDto.getResponseCode());
    assertEquals(2, myOrderResponseDto.getShippingList().size());
    assertEquals(1, myOrderResponseDto.getShippingList().get(0).getTrackingNumberDetails().size());
    assertEquals(1, myOrderResponseDto.getShippingList().get(1).getTrackingNumberDetails().size());
  }

  @Test
  public void multipleNonOmatomeOrdersWithSingleBasketAndDeliveryIsNullAndRedeliveryUrlNotNullTest() {
    orderDetailsList = new ArrayList<>();
    deliveryChangeRequestInfoList = new ArrayList<>();
    orderDetailsList.add(createOrderDetails("1001", "1003", "12345678901", 1l, "1001ItemName", 1l));
    orderDetailsList.add(createOrderDetails("1002", "1003", "12345678902", 1l, "1002ItemName", 1l));
    Map<String,DeliveryInfoEntity> deliveryInfoMap = new HashMap<>();
    
    String key = omatomeHelper.getDeliveryInfoKey("12345678901", "1003", "1001");
    DeliveryInfoEntity deliveryInfo = createDeliveryInfoEntity("1001", "1003", "12345678901", 2, null, null, today);
    deliveryInfoMap.put(key, deliveryInfo);
    
    key = omatomeHelper.getDeliveryInfoKey("12345678902", "1003", "1002");
    deliveryInfo = createDeliveryInfoEntity("1002", "1003", "12345678902", 5, null, redeliveryRequestUrl, today);
    deliveryInfoMap.put(key, deliveryInfo);
    
    deliveryChangeRequestInfoList = new ArrayList<>();
    
    omatomeTrackingNumberRangeList = new ArrayList<>();
    OmatomeTrackingNumberRange omatomeTrackingNumberRange = createOmatomeTrackingNumberRange("1003", 12345678900l, 12345678910l);
    omatomeTrackingNumberRangeList.add(omatomeTrackingNumberRange);

    MyOrderResponseDTO myOrderResponseDto = responseUtils.getMyOrderResponse(orderDetailsList, deliveryInfoMap, 
    		omatomeHelper.getChangeRequestGroupInfoMap(deliveryChangeRequestInfoList), omatomeTrackingNumberRangeList);
    assertEquals(OmatomeConstants.SUCCESS_RESPONSE_CODE, myOrderResponseDto.getResponseCode());
    assertEquals(1, myOrderResponseDto.getShippingList().size());
    assertEquals(1, myOrderResponseDto.getShippingList().get(0).getTrackingNumberDetails().size());
    assertEquals(OmatomeConstants.REDELIVERY_REQUEST, myOrderResponseDto.getShippingList().get(0).getTrackingNumberDetails().get(0).getChangeType());
    assertEquals(OmatomeConstants.REDELIVERY_REQUEST, myOrderResponseDto.getShippingList().get(0).getChangeTypeDisplay());
  }

  @Test
  public void multipleNonOmatomeOrdersWithSingleBasketAndDeliveryIsNullAndRedeliveryUrlIsNullTest() {
    orderDetailsList = new ArrayList<>();
    deliveryChangeRequestInfoList = new ArrayList<>();
    orderDetailsList.add(createOrderDetails("1001", "1003", "12345678901", 1l, "1001ItemName", 1l));
    orderDetailsList.add(createOrderDetails("1002", "1003", "12345678902", 1l, "1002ItemName", 1l));
    Map<String,DeliveryInfoEntity> deliveryInfoMap = new HashMap<>();
    
    String key = omatomeHelper.getDeliveryInfoKey("12345678901", "1003", "1001");
    DeliveryInfoEntity deliveryInfo = createDeliveryInfoEntity("1001", "1003", "12345678901", 2, null, null, today);
    deliveryInfoMap.put(key, deliveryInfo);
    
    key = omatomeHelper.getDeliveryInfoKey("12345678902", "1003", "1002");
    deliveryInfo = createDeliveryInfoEntity("1002", "1003", "12345678902", 5, null, null, today);
    deliveryInfoMap.put(key, deliveryInfo);
    
    deliveryChangeRequestInfoList = new ArrayList<>();
    
    omatomeTrackingNumberRangeList = new ArrayList<>();
    OmatomeTrackingNumberRange omatomeTrackingNumberRange = createOmatomeTrackingNumberRange("1003", 12345678900l, 12345678910l);
    omatomeTrackingNumberRangeList.add(omatomeTrackingNumberRange);

    MyOrderResponseDTO myOrderResponseDto = responseUtils.getMyOrderResponse(orderDetailsList, deliveryInfoMap, 
    		omatomeHelper.getChangeRequestGroupInfoMap(deliveryChangeRequestInfoList), omatomeTrackingNumberRangeList);
    assertEquals(OmatomeConstants.SUCCESS_RESPONSE_CODE, myOrderResponseDto.getResponseCode());
    assertEquals(0, myOrderResponseDto.getShippingList().size());
  }
  
  @Test
  public void multipleNonOmatomeOrdersWithSameTrackingNumberForNonOmatomeOrdersTest() {
    orderDetailsList = new ArrayList<>();
    deliveryChangeRequestInfoList = new ArrayList<>();
    orderDetailsList.add(createOrderDetails("1001", "1003", "12345678901", 1l, "1001ItemName", 1l));
    orderDetailsList.add(createOrderDetails("1002", "1003", "12345678901" , 2l, "1002ItemName1", 2l));
    Map<String,DeliveryInfoEntity> deliveryInfoMap = new HashMap<>();
    
    String key = omatomeHelper.getDeliveryInfoKey("12345678901","1003", "1001");
    DeliveryInfoEntity deliveryInfo = createDeliveryInfoEntity("1001", "1003", "12345678901", 3, deliveryRequestUrl, null, tomorrow);
    deliveryInfoMap.put(key, deliveryInfo);
    key = omatomeHelper.getDeliveryInfoKey("12345678901","1003", "1002");
    deliveryInfo = createDeliveryInfoEntity("1002", "1003", "12345678901", 3, deliveryRequestUrl, null, tomorrow);
    deliveryInfoMap.put(key, deliveryInfo);

    deliveryChangeRequestInfoList = new ArrayList<>();
    
    omatomeTrackingNumberRangeList = new ArrayList<>();
    OmatomeTrackingNumberRange omatomeTrackingNumberRange = createOmatomeTrackingNumberRange("1003", 12345678900l, 12345678910l);
    omatomeTrackingNumberRangeList.add(omatomeTrackingNumberRange);

    MyOrderResponseDTO myOrderResponseDto = responseUtils.getMyOrderResponse(orderDetailsList, deliveryInfoMap, 
    		omatomeHelper.getChangeRequestGroupInfoMap(deliveryChangeRequestInfoList), omatomeTrackingNumberRangeList);
    assertEquals(OmatomeConstants.SUCCESS_RESPONSE_CODE, myOrderResponseDto.getResponseCode());
    assertEquals(1, myOrderResponseDto.getShippingList().size());
    assertEquals(1, myOrderResponseDto.getShippingList().get(0).getTrackingNumberDetails().size());
    assertEquals(2, myOrderResponseDto.getShippingList().get(0).getTrackingNumberDetails().get(0).getOrderList().size());
    assertEquals(OmatomeConstants.DATE_CHANGE_REQUEST, myOrderResponseDto.getShippingList().get(0).getTrackingNumberDetails().get(0).getChangeType());

  }
  
  @Test
  public void multipleDeliveryCompanyForNonOmatomeOrdersTest() {
    orderDetailsList = new ArrayList<>();
    deliveryChangeRequestInfoList = new ArrayList<>();
    orderDetailsList.add(createOrderDetails("1001", "1003", "12345678901", 1l, "1001ItemName", 1l));
    orderDetailsList.add(createOrderDetails("1002", "1003", "12345678901" , 2l, "1002ItemName1", 2l));
    orderDetailsList.add(createOrderDetails("2001", "1028", "123456789023" , 1l, "2001ItemName", 1l));
    orderDetailsList.add(createOrderDetails("2002", "1028", "123456789023" , 2l, "2002ItemName1", 2l));
    Map<String,DeliveryInfoEntity> deliveryInfoMap = new HashMap<>();
    
    String key = omatomeHelper.getDeliveryInfoKey("12345678901","1003", "1001");
    DeliveryInfoEntity deliveryInfo = createDeliveryInfoEntity("1001", "1003", "12345678901", 2, deliveryRequestUrl, null, today);
    deliveryInfoMap.put(key, deliveryInfo);
    key = omatomeHelper.getDeliveryInfoKey("12345678901","1003", "1002");
    deliveryInfo = createDeliveryInfoEntity("1002", "1003", "12345678901", 2, deliveryRequestUrl, null, today);
    deliveryInfoMap.put(key, deliveryInfo);
    
    key = omatomeHelper.getDeliveryInfoKey("123456789023","1028", "2001");
    deliveryInfo = createDeliveryInfoEntity("2001", "1028", "123456789023", 2, deliveryRequestUrl, null, today);
    deliveryInfoMap.put(key, deliveryInfo);
    key = omatomeHelper.getDeliveryInfoKey("123456789023","1028", "2002");
    deliveryInfo = createDeliveryInfoEntity("2002", "1028", "123456789023", 2, deliveryRequestUrl, null, today);
    deliveryInfoMap.put(key, deliveryInfo);

    deliveryChangeRequestInfoList = new ArrayList<>();
    
    omatomeTrackingNumberRangeList = new ArrayList<>();
    OmatomeTrackingNumberRange omatomeTrackingNumberRange = createOmatomeTrackingNumberRange("1003", 12345678900l, 12345678910l);
    omatomeTrackingNumberRangeList.add(omatomeTrackingNumberRange);
    omatomeTrackingNumberRange = createOmatomeTrackingNumberRange("1028", 123456789000l, 123456789100l);
    omatomeTrackingNumberRangeList.add(omatomeTrackingNumberRange);

    MyOrderResponseDTO myOrderResponseDto = responseUtils.getMyOrderResponse(orderDetailsList, deliveryInfoMap, 
    		omatomeHelper.getChangeRequestGroupInfoMap(deliveryChangeRequestInfoList), omatomeTrackingNumberRangeList);
    assertEquals(OmatomeConstants.SUCCESS_RESPONSE_CODE, myOrderResponseDto.getResponseCode());
    assertEquals(2, myOrderResponseDto.getShippingList().size());
    assertEquals(1, myOrderResponseDto.getShippingList().get(0).getTrackingNumberDetails().size());
    assertEquals(2, myOrderResponseDto.getShippingList().get(0).getTrackingNumberDetails().get(0).getOrderList().size());
    assertEquals(1, myOrderResponseDto.getShippingList().get(1).getTrackingNumberDetails().size());
    assertEquals(2, myOrderResponseDto.getShippingList().get(1).getTrackingNumberDetails().get(0).getOrderList().size());

  }
  
  @Test
  public void multipleDeliveryCompanyWithInvalidTrackingNumberForNonOmatomeOrdersTest() {
    orderDetailsList = new ArrayList<>();
    deliveryChangeRequestInfoList = new ArrayList<>();
    //Invalid tracking number for JP
    orderDetailsList.add(createOrderDetails("1001", "1003", "1234567890", 1l, "1001ItemName", 1l));
    orderDetailsList.add(createOrderDetails("1002", "1003", "12345678901" , 2l, "1002ItemName1", 2l));
    //Invalid tracking number for EXP
    orderDetailsList.add(createOrderDetails("2001", "1028", "12345678902" , 1l, "2001ItemName", 1l));
    orderDetailsList.add(createOrderDetails("2002", "1028", "123456789023" , 2l, "2002ItemName1", 2l));
    Map<String,DeliveryInfoEntity> deliveryInfoMap = new HashMap<>();
    
    String key = omatomeHelper.getDeliveryInfoKey("1234567890","1003", "1001");
    DeliveryInfoEntity deliveryInfo = createDeliveryInfoEntity("1001", "1003", "1234567890", 2, deliveryRequestUrl, null, tomorrow);
    deliveryInfoMap.put(key, deliveryInfo);
    key = omatomeHelper.getDeliveryInfoKey("12345678901","1003", "1002");
    deliveryInfo = createDeliveryInfoEntity("1002", "1003", "12345678901", 2, deliveryRequestUrl, null, tomorrow);
    deliveryInfoMap.put(key, deliveryInfo);
    
    key = omatomeHelper.getDeliveryInfoKey("12345678902","1028", "2001");
    deliveryInfo = createDeliveryInfoEntity("2001", "1028", "12345678902", 2, deliveryRequestUrl, null, tomorrow);
    deliveryInfoMap.put(key, deliveryInfo);
    key = omatomeHelper.getDeliveryInfoKey("123456789023","1028", "2002");
    deliveryInfo = createDeliveryInfoEntity("2002", "1028", "123456789023", 2, deliveryRequestUrl, null, tomorrow);
    deliveryInfoMap.put(key, deliveryInfo);

    deliveryChangeRequestInfoList = new ArrayList<>();
    
    omatomeTrackingNumberRangeList = new ArrayList<>();
    OmatomeTrackingNumberRange omatomeTrackingNumberRange = createOmatomeTrackingNumberRange("1003", 12345678900l, 12345678910l);
    omatomeTrackingNumberRangeList.add(omatomeTrackingNumberRange);
    omatomeTrackingNumberRange = createOmatomeTrackingNumberRange("1028", 123456789000l, 123456789100l);
    omatomeTrackingNumberRangeList.add(omatomeTrackingNumberRange);

    MyOrderResponseDTO myOrderResponseDto = responseUtils.getMyOrderResponse(orderDetailsList, deliveryInfoMap, 
    		omatomeHelper.getChangeRequestGroupInfoMap(deliveryChangeRequestInfoList), omatomeTrackingNumberRangeList);
    assertEquals(OmatomeConstants.SUCCESS_RESPONSE_CODE, myOrderResponseDto.getResponseCode());
    assertEquals(2, myOrderResponseDto.getShippingList().size());
    assertEquals(1, myOrderResponseDto.getShippingList().get(0).getTrackingNumberDetails().size());
    assertEquals(1, myOrderResponseDto.getShippingList().get(0).getTrackingNumberDetails().get(0).getOrderList().size());
    assertEquals(1, myOrderResponseDto.getShippingList().get(1).getTrackingNumberDetails().size());
    assertEquals(1, myOrderResponseDto.getShippingList().get(1).getTrackingNumberDetails().get(0).getOrderList().size());

  }
  
  @Test
  public void singleOrderNumberWithOmatomeIdTest() {
    orderDetailsList = new ArrayList<>();
    deliveryChangeRequestInfoList = new ArrayList<>();
    orderDetailsList.add(createOrderDetails("1001", "1003", "12345678901", 1l, "1001ItemName", 1l));
    orderDetailsList.add(createOrderDetails("1002", "1003", "12345678902" , 2l, "1002ItemName1", 2l));
    Map<String,DeliveryInfoEntity> deliveryInfoMap = new HashMap<>();
    
    String key = omatomeHelper.getDeliveryInfoKey("12345678901", "1003", "1001");
    DeliveryInfoEntity deliveryInfo = createDeliveryInfoEntity("1001", "1003", "12345678901", 2, deliveryRequestUrl, null, today);
    deliveryInfoMap.put(key, deliveryInfo);

    key = omatomeHelper.getDeliveryInfoKey("12345678902", "1003", "1002");
    deliveryInfo = createDeliveryInfoEntity("1002", "1003", "12345678902", 2, deliveryRequestUrl, null, tomorrow);
    deliveryInfoMap.put(key, deliveryInfo);

    DeliveryChangeRequestInfo entity = createDeliveryChangeRequestInfoEntity("12345678901", "1003", "1", 1, 0, null);
    deliveryChangeRequestInfoList.add(entity);
    
    omatomeTrackingNumberRangeList = new ArrayList<>();
    OmatomeTrackingNumberRange omatomeTrackingNumberRange = createOmatomeTrackingNumberRange("1003", 12345678900l, 12345678910l);
    omatomeTrackingNumberRangeList.add(omatomeTrackingNumberRange);

    MyOrderResponseDTO myOrderResponseDto = responseUtils.getMyOrderResponse(orderDetailsList, deliveryInfoMap, 
    		omatomeHelper.getChangeRequestGroupInfoMap(deliveryChangeRequestInfoList), omatomeTrackingNumberRangeList);
    assertEquals(OmatomeConstants.SUCCESS_RESPONSE_CODE, myOrderResponseDto.getResponseCode());
    assertEquals(2, myOrderResponseDto.getShippingList().size());
    assertEquals(false, myOrderResponseDto.getShippingList().get(0).isDeliveryDateToday());
    assertEquals(true, myOrderResponseDto.getShippingList().get(1).isDeliveryDateToday());
    assertEquals("1", myOrderResponseDto.getShippingList().get(1).getChangeRequestId());
    assertEquals(false, myOrderResponseDto.getShippingList().get(1).isOkihaiOrder());
    assertEquals(1, myOrderResponseDto.getShippingList().get(1).getTrackingNumberDetails().size());
    assertEquals(1, myOrderResponseDto.getShippingList().get(1).getTrackingNumberDetails().get(0).getOrderList().size());

  }
  
  @Test
  public void multipleOrderNumberWithOmatomeIdAndMultipleDeliveryCarrierAndPointValidationTest() {
    orderDetailsList = new ArrayList<>();
    deliveryChangeRequestInfoList = new ArrayList<>();
    orderDetailsList.add(createOrderDetails("1001", "1003", "12345678901", 1l, "1001ItemName", 1l));
    orderDetailsList.add(createOrderDetails("1002", "1003", "12345678902" , 2l, "1002ItemName1", 2l));
    orderDetailsList.add(createOrderDetails("1003", "1028", "123456789012" , 2l, "1003ItemName", 2l));
    Map<String,DeliveryInfoEntity> deliveryInfoMap = new HashMap<>();
    
    String key = omatomeHelper.getDeliveryInfoKey("12345678901", "1003", "1001");
    DeliveryInfoEntity deliveryInfo = createDeliveryInfoEntity("1001", "1003", "12345678901", 3, deliveryRequestUrl, null, today);
    deliveryInfoMap.put(key, deliveryInfo);

    key = omatomeHelper.getDeliveryInfoKey("12345678902", "1003", "1002");
    deliveryInfo = createDeliveryInfoEntity("1002", "1003", "12345678902", 3, deliveryRequestUrl, null, today);
    deliveryInfoMap.put(key, deliveryInfo);

    key = omatomeHelper.getDeliveryInfoKey("123456789012", "1028", "1003");
    deliveryInfo = createDeliveryInfoEntity("1003", "1028", "123456789012", 2, deliveryRequestUrl, null, today);
    deliveryInfoMap.put(key, deliveryInfo);

    DeliveryChangeRequestInfo entity = createDeliveryChangeRequestInfoEntity("12345678901", "1003", "1", 1, 20, null);
    deliveryChangeRequestInfoList.add(entity);
    entity = createDeliveryChangeRequestInfoEntity("12345678902", "1003", "1", 1, 20, null);
    deliveryChangeRequestInfoList.add(entity);
    entity = createDeliveryChangeRequestInfoEntity("123456789012", "1028", "2", 1, 10, "okihai");
    deliveryChangeRequestInfoList.add(entity);
    
    omatomeTrackingNumberRangeList = new ArrayList<>();
    OmatomeTrackingNumberRange omatomeTrackingNumberRange = createOmatomeTrackingNumberRange("1003", 12345678900l, 12345678910l);
    omatomeTrackingNumberRangeList.add(omatomeTrackingNumberRange);
    omatomeTrackingNumberRange = createOmatomeTrackingNumberRange("1028", 123456789000l, 123456789100l);
    omatomeTrackingNumberRangeList.add(omatomeTrackingNumberRange);

    MyOrderResponseDTO myOrderResponseDto = responseUtils.getMyOrderResponse(orderDetailsList, deliveryInfoMap, 
    		omatomeHelper.getChangeRequestGroupInfoMap(deliveryChangeRequestInfoList), omatomeTrackingNumberRangeList);
    assertEquals(OmatomeConstants.SUCCESS_RESPONSE_CODE, myOrderResponseDto.getResponseCode());
    assertEquals(2, myOrderResponseDto.getShippingList().size());
    assertEquals("1", myOrderResponseDto.getShippingList().get(0).getChangeRequestId());
    assertEquals(20, myOrderResponseDto.getShippingList().get(0).getPoints());
    assertEquals(false, myOrderResponseDto.getShippingList().get(0).isOkihaiOrder());
    assertEquals(2, myOrderResponseDto.getShippingList().get(0).getTrackingNumberDetails().size());
    assertEquals(1, myOrderResponseDto.getShippingList().get(0).getTrackingNumberDetails().get(0).getOrderList().size());
    assertEquals("2", myOrderResponseDto.getShippingList().get(1).getChangeRequestId());
    assertEquals(true, myOrderResponseDto.getShippingList().get(1).isOkihaiOrder());
    assertEquals(1, myOrderResponseDto.getShippingList().get(1).getTrackingNumberDetails().size());

  }
  
  @Test
  public void multipleShippingListWithOmatomeAndNonOmatomeOrdersTest() {
    orderDetailsList = new ArrayList<>();
    deliveryChangeRequestInfoList = new ArrayList<>();
    orderDetailsList.add(createOrderDetails("1001", "1003", "12345678901", 1l, "1001ItemName", 1l));
    orderDetailsList.add(createOrderDetails("1002", "1003", "12345678902" , 2l, "1002ItemName1", 2l));
    orderDetailsList.add(createOrderDetails("1003", "1003", "12345678903" , 2l, "1002ItemName1", 2l));

    Map<String,DeliveryInfoEntity> deliveryInfoMap = new HashMap<>();
    
    String key = omatomeHelper.getDeliveryInfoKey("12345678901", "1003", "1001");
    DeliveryInfoEntity deliveryInfo = createDeliveryInfoEntity("1001", "1003", "12345678901", 2, deliveryRequestUrl, null, tomorrow);
    deliveryInfoMap.put(key, deliveryInfo);

    key = omatomeHelper.getDeliveryInfoKey("12345678902", "1003", "1002");
    deliveryInfo = createDeliveryInfoEntity("1002", "1003", "12345678902", 4, deliveryRequestUrl, null, tomorrow);
    deliveryInfoMap.put(key, deliveryInfo);
    
    key = omatomeHelper.getDeliveryInfoKey("12345678903", "1003", "1003");
    deliveryInfo = createDeliveryInfoEntity("1003", "1003", "12345678903", 3, deliveryRequestUrl, null, tomorrow);
    deliveryInfoMap.put(key, deliveryInfo);

    DeliveryChangeRequestInfo entity = createDeliveryChangeRequestInfoEntity("12345678901", "1003", "1", 1, 20, null);
    deliveryChangeRequestInfoList.add(entity);
    entity = createDeliveryChangeRequestInfoEntity("12345678902", "1003", "1", 1, 20, null);
    deliveryChangeRequestInfoList.add(entity);
    
    omatomeTrackingNumberRangeList = new ArrayList<>();
    OmatomeTrackingNumberRange omatomeTrackingNumberRange = createOmatomeTrackingNumberRange("1003", 12345678900l, 12345678910l);
    omatomeTrackingNumberRangeList.add(omatomeTrackingNumberRange);

    MyOrderResponseDTO myOrderResponseDto = responseUtils.getMyOrderResponse(orderDetailsList, deliveryInfoMap, 
    		omatomeHelper.getChangeRequestGroupInfoMap(deliveryChangeRequestInfoList), omatomeTrackingNumberRangeList);
    assertEquals(OmatomeConstants.SUCCESS_RESPONSE_CODE, myOrderResponseDto.getResponseCode());
    assertEquals(2, myOrderResponseDto.getShippingList().size());
    assertEquals("1", myOrderResponseDto.getShippingList().get(1).getChangeRequestId());
    assertEquals(20, myOrderResponseDto.getShippingList().get(1).getPoints());
    assertNull(myOrderResponseDto.getShippingList().get(0).getChangeRequestId());
    assertEquals(1, myOrderResponseDto.getShippingList().get(0).getTrackingNumberDetails().size());
    assertEquals(false, myOrderResponseDto.getShippingList().get(1).isOkihaiOrder());
    assertEquals(2, myOrderResponseDto.getShippingList().get(1).getTrackingNumberDetails().size());
    assertEquals(1, myOrderResponseDto.getShippingList().get(1).getTrackingNumberDetails().get(0).getOrderList().size());

  }
  
  @Test
  public void multipleShippingListWithOmatomeAndNonOmatomeOrdersTest1() {
    orderDetailsList = new ArrayList<>();
    deliveryChangeRequestInfoList = new ArrayList<>();
    orderDetailsList.add(createOrderDetails("1001", "1003", "12345678901", 1l, "1001ItemName", 1l));
    orderDetailsList.add(createOrderDetails("1002", "1003", "12345678902" , 2l, "1002ItemName1", 2l));
    orderDetailsList.add(createOrderDetails("1003", "1003", "12345678903" , 2l, "1003ItemName1", 2l));

    Map<String,DeliveryInfoEntity> deliveryInfoMap = new HashMap<>();
    
    String key = omatomeHelper.getDeliveryInfoKey("12345678901", "1003", "1001");
    DeliveryInfoEntity deliveryInfo = createDeliveryInfoEntity("1001", "1003", "12345678901", 2, deliveryRequestUrl, null, today);
    deliveryInfoMap.put(key, deliveryInfo);

    key = omatomeHelper.getDeliveryInfoKey("12345678902", "1003", "1002");
    deliveryInfo = createDeliveryInfoEntity("1002", "1003", "12345678902", 2, deliveryRequestUrl, null, tomorrow);
    deliveryInfoMap.put(key, deliveryInfo);
    
    key = omatomeHelper.getDeliveryInfoKey("12345678903", "1003", "1003");
    deliveryInfo = createDeliveryInfoEntity("1003", "1003", "12345678903", 2, deliveryRequestUrl, null, tomorrow);
    deliveryInfoMap.put(key, deliveryInfo);

    DeliveryChangeRequestInfo entity = createDeliveryChangeRequestInfoEntity("12345678901", "1003", "1", 1, 10, "okihai");
    deliveryChangeRequestInfoList.add(entity);
    entity = createDeliveryChangeRequestInfoEntity("12345678903", "1003", "1", 1, 10, "okihai");
    deliveryChangeRequestInfoList.add(entity);
    
    omatomeTrackingNumberRangeList = new ArrayList<>();
    OmatomeTrackingNumberRange omatomeTrackingNumberRange = createOmatomeTrackingNumberRange("1003", 12345678900l, 12345678910l);
    omatomeTrackingNumberRangeList.add(omatomeTrackingNumberRange);

    MyOrderResponseDTO myOrderResponseDto = responseUtils.getMyOrderResponse(orderDetailsList, deliveryInfoMap, 
    		omatomeHelper.getChangeRequestGroupInfoMap(deliveryChangeRequestInfoList), omatomeTrackingNumberRangeList);
    assertEquals(OmatomeConstants.SUCCESS_RESPONSE_CODE, myOrderResponseDto.getResponseCode());
    assertEquals(2, myOrderResponseDto.getShippingList().size());
    assertEquals("1", myOrderResponseDto.getShippingList().get(1).getChangeRequestId());
    assertNull(myOrderResponseDto.getShippingList().get(0).getChangeRequestId());
    assertEquals(1, myOrderResponseDto.getShippingList().get(0).getTrackingNumberDetails().size());
    assertEquals(true, myOrderResponseDto.getShippingList().get(1).isOkihaiOrder());
    assertEquals(2, myOrderResponseDto.getShippingList().get(1).getTrackingNumberDetails().size());
    assertEquals(1, myOrderResponseDto.getShippingList().get(1).getTrackingNumberDetails().get(0).getOrderList().size());

  }
  
  @Test
  public void multipleShippingListWithOmatomeAndNonOmatomeOrdersWithJPTrackingNumberOutOfRangeTest() {
    orderDetailsList = new ArrayList<>();
    deliveryChangeRequestInfoList = new ArrayList<>();
    orderDetailsList.add(createOrderDetails("1001", "1003", "12345678901", 1l, "1001ItemName", 1l));
    orderDetailsList.add(createOrderDetails("1002", "1003", "12345678912" , 2l, "1002ItemName1", 2l));//out of range
    orderDetailsList.add(createOrderDetails("1003", "1003", "12345678903" , 2l, "1003ItemName1", 2l));

    Map<String,DeliveryInfoEntity> deliveryInfoMap = new HashMap<>();
    
    String key = omatomeHelper.getDeliveryInfoKey("12345678901", "1003", "1001");
    DeliveryInfoEntity deliveryInfo = createDeliveryInfoEntity("1001", "1003", "12345678901", 2, deliveryRequestUrl, null, today);
    deliveryInfoMap.put(key, deliveryInfo);

    key = omatomeHelper.getDeliveryInfoKey("12345678912", "1003", "1002");
    deliveryInfo = createDeliveryInfoEntity("1002", "1003", "12345678912", 2, deliveryRequestUrl, null, tomorrow);
    deliveryInfoMap.put(key, deliveryInfo);
    
    key = omatomeHelper.getDeliveryInfoKey("12345678903", "1003", "1003");
    deliveryInfo = createDeliveryInfoEntity("1003", "1003", "12345678903", 2, deliveryRequestUrl, null, tomorrow);
    deliveryInfoMap.put(key, deliveryInfo);

    DeliveryChangeRequestInfo entity = createDeliveryChangeRequestInfoEntity("12345678901", "1003", "1", 1, 10, "okihai");
    deliveryChangeRequestInfoList.add(entity);
    entity = createDeliveryChangeRequestInfoEntity("12345678903", "1003", "1", 1, 10, "okihai");
    deliveryChangeRequestInfoList.add(entity);
    
    omatomeTrackingNumberRangeList = new ArrayList<>();
    //define range
    OmatomeTrackingNumberRange omatomeTrackingNumberRange = createOmatomeTrackingNumberRange("1003", 12345678900l, 12345678910l);
    omatomeTrackingNumberRangeList.add(omatomeTrackingNumberRange);

    MyOrderResponseDTO myOrderResponseDto = responseUtils.getMyOrderResponse(orderDetailsList, deliveryInfoMap, 
    		omatomeHelper.getChangeRequestGroupInfoMap(deliveryChangeRequestInfoList), omatomeTrackingNumberRangeList);
    assertEquals(OmatomeConstants.SUCCESS_RESPONSE_CODE, myOrderResponseDto.getResponseCode());
    assertEquals(1, myOrderResponseDto.getShippingList().size());
    assertEquals("1", myOrderResponseDto.getShippingList().get(0).getChangeRequestId());
    assertEquals(true, myOrderResponseDto.getShippingList().get(0).isOkihaiOrder());
    assertEquals(2, myOrderResponseDto.getShippingList().get(0).getTrackingNumberDetails().size());
    assertEquals(1, myOrderResponseDto.getShippingList().get(0).getTrackingNumberDetails().get(0).getOrderList().size());

  }
  
  @Test
  public void multipleDeliveryCompanyForNonOmatomeOrdersAndTrackingNumberOutOfRangeforJPAndExpressTest() {
    orderDetailsList = new ArrayList<>();
    deliveryChangeRequestInfoList = new ArrayList<>();
    orderDetailsList.add(createOrderDetails("1001", "1003", "12345678901", 1l, "1001ItemName", 1l));
    orderDetailsList.add(createOrderDetails("1002", "1003", "12345678921" , 2l, "1002ItemName1", 2l));//out of range
    orderDetailsList.add(createOrderDetails("2001", "1028", "123456789023" , 1l, "2001ItemName", 1l));
    orderDetailsList.add(createOrderDetails("2002", "1028", "123456789223" , 2l, "2002ItemName1", 2l));//out of range
    Map<String,DeliveryInfoEntity> deliveryInfoMap = new HashMap<>();
    
    String key = omatomeHelper.getDeliveryInfoKey("12345678901","1003", "1001");
    DeliveryInfoEntity deliveryInfo = createDeliveryInfoEntity("1001", "1003", "12345678901", 2, deliveryRequestUrl, null, today);
    deliveryInfoMap.put(key, deliveryInfo);
    key = omatomeHelper.getDeliveryInfoKey("12345678921","1003", "1002");
    deliveryInfo = createDeliveryInfoEntity("1002", "1003", "12345678921", 2, deliveryRequestUrl, null, today);
    deliveryInfoMap.put(key, deliveryInfo);
    
    key = omatomeHelper.getDeliveryInfoKey("123456789023","1028", "2001");
    deliveryInfo = createDeliveryInfoEntity("2001", "1028", "123456789023", 2, deliveryRequestUrl, null, today);
    deliveryInfoMap.put(key, deliveryInfo);
    key = omatomeHelper.getDeliveryInfoKey("123456789223","1028", "2002");
    deliveryInfo = createDeliveryInfoEntity("2002", "1028", "123456789223", 2, deliveryRequestUrl, null, today);
    deliveryInfoMap.put(key, deliveryInfo);

    deliveryChangeRequestInfoList = new ArrayList<>();
    
    omatomeTrackingNumberRangeList = new ArrayList<>();
    //define range for JP
    OmatomeTrackingNumberRange omatomeTrackingNumberRange = createOmatomeTrackingNumberRange("1003", 12345678900l, 12345678910l);
    omatomeTrackingNumberRangeList.add(omatomeTrackingNumberRange);
    //define range for Express
    omatomeTrackingNumberRange = createOmatomeTrackingNumberRange("1028", 123456789000l, 123456789100l);
    omatomeTrackingNumberRangeList.add(omatomeTrackingNumberRange);

    MyOrderResponseDTO myOrderResponseDto = responseUtils.getMyOrderResponse(orderDetailsList, deliveryInfoMap, 
    		omatomeHelper.getChangeRequestGroupInfoMap(deliveryChangeRequestInfoList), omatomeTrackingNumberRangeList);
    assertEquals(OmatomeConstants.SUCCESS_RESPONSE_CODE, myOrderResponseDto.getResponseCode());
    assertEquals(2, myOrderResponseDto.getShippingList().size());
    assertEquals(1, myOrderResponseDto.getShippingList().get(0).getTrackingNumberDetails().size());
    assertEquals(1, myOrderResponseDto.getShippingList().get(0).getTrackingNumberDetails().get(0).getOrderList().size());
    assertEquals(1, myOrderResponseDto.getShippingList().get(1).getTrackingNumberDetails().size());
    assertEquals(1, myOrderResponseDto.getShippingList().get(1).getTrackingNumberDetails().get(0).getOrderList().size());

  }
  
  private OrderDetails createOrderDetails(String orderNumber,String companyNumber, String trackingNumber,
		  Long itemId,String itemName,Long basketId) {
	  OrderDetails orderDetails = new OrderDetails();
	  orderDetails.setBasketId(basketId);
	  orderDetails.setCompanyNumber(companyNumber);
	  orderDetails.setItemId(itemId);
	  orderDetails.setItemName(itemName);
	  orderDetails.setTrackingNumber(trackingNumber);
	  orderDetails.setOrderNumber(orderNumber);
	  return orderDetails;
  }
  
  private DeliveryInfoEntity createDeliveryInfoEntity(String orderNumber, String companyNumber,
		  String trackingNumber, Integer deliveryStatus, String deliveryRequestUrl, String redeliveryRequestUrl, LocalDate date) {
	  
	  DeliveryInfoEntity deliveryInfo = new DeliveryInfoEntity();
	  deliveryInfo.setDeliveryStatus(deliveryStatus);
	  deliveryInfo.setDeliveryRequestUrl(deliveryRequestUrl);
	  deliveryInfo.setRedeliveryRequestUrl(redeliveryRequestUrl);
	  deliveryInfo.setDeliveryDate(date);
	  deliveryInfo.setChangeTimestamp(LocalDateTime.now().minusDays(1));

	  return deliveryInfo;
  }
  
  private DeliveryChangeRequestInfo createDeliveryChangeRequestInfoEntity(String trackingNumber, String companyNumber, 
		  String id, Integer omatomeFlag, Integer point, String requestOkihaiPlace1) {

	  DeliveryChangeRequestInfo changeRequestInfo = new DeliveryChangeRequestInfo();
	  changeRequestInfo.setChangeRequestId(id);
	  changeRequestInfo.setOmatomeFlag(omatomeFlag);
	  changeRequestInfo.setCompanyNumber(companyNumber);
	  changeRequestInfo.setTrackingNumber(trackingNumber);
	  changeRequestInfo.setPoints(point);
	  changeRequestInfo.setRequestOkihaiPlace1(requestOkihaiPlace1);
	  changeRequestInfo.setChangeTimestamp(LocalDateTime.now());

	  return changeRequestInfo;
  }

  private OmatomeTrackingNumberRange createOmatomeTrackingNumberRange(String companyNumber, Long trackingNumberBegin, Long trackingNumberEnd) {
	  OmatomeTrackingNumberRange omatomeTrackingNumberRange = new OmatomeTrackingNumberRange();
	  OmatomeTrackingNumberRangeId omatomeTrackingNumberRangeId = new OmatomeTrackingNumberRangeId();
	  omatomeTrackingNumberRangeId.setCompanyNumber(companyNumber);
	  omatomeTrackingNumberRangeId.setRangeType(OmatomeConstants.RANGE_TYPE);
	  omatomeTrackingNumberRangeId.setTrackingNumberBegin(trackingNumberBegin);
	  omatomeTrackingNumberRangeId.setTrackingNumberEnd(trackingNumberEnd);
	  omatomeTrackingNumberRange.setOmatomeTrackingNumberRangeId(omatomeTrackingNumberRangeId);
	  return omatomeTrackingNumberRange;
  }
}
