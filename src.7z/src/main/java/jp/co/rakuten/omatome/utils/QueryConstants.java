package jp.co.rakuten.omatome.utils;

public class QueryConstants {

	public static final String FETCH_ORDER_DELIVERY_STATUS = " select * from delivery_info where  ";

	public static final String FETCH_ORDER_DATA = " select distinct orderBaseInfo.order_number as orderNumber, orderBaseInfo.opp_flag as oppFlag, " +
			" orderBasketInfo.original_tracking_number as originalNonOnePayTrackingNumber, orderBasketInfo.delivery_company_number as nonOnePayDeliveryCompanyNumber, " +
			" orderShippingInfo.original_tracking_number as originalOnePayTrackingNumber, orderShippingInfo.delivery_company_number as onePayDeliveryCompanyNumber,  " +
			" orderBasketInfo.item_id as itemId, orderBasketInfo.item_name as itemName, orderBasketInfo.basket_id as basketId, " +
			" orderBaseInfo.wish_delivery_date as wishDeliveryDate, orderBaseInfo.order_date as orderDate, " +
			" orderBaseInfo.shop_name as shopName, orderBaseInfo.delivery_name as deliveryName " +
			" from order_base_info orderBaseInfo " +
			" left join order_basket_info orderBasketInfo on orderBasketInfo.order_number = orderBaseInfo.order_number " + 
			" left join order_shipping_info orderShippingInfo on orderShippingInfo.order_number = orderBaseInfo.order_number and  orderShippingInfo.basket_id = orderBasketInfo.basket_id " +
			" where orderBaseInfo.easy_id  = (:easyId) and  " +
			" ( orderBasketInfo.delivery_company_number in (:companyNumbers) or orderShippingInfo.delivery_company_number in (:companyNumbers) ) " +
			" and orderBaseInfo.delivery_name in (:deliveryNames) and orderBaseInfo.change_timestamp >= sysdate - 90 " + 
			" order by  basketId, originalNonOnePayTrackingNumber, originalOnePayTrackingNumber ";
	
	public static final String FETCH_CHANGE_REQUEST_DATA = " select deliveryChangeRequestInfo.tracking_number as trackingNumber, " +
			" deliveryChangeRequestInfo.delivery_company_number as companyNumber, deliveryChangeRequestInfo.change_request_id as changeRequestId, " + 
			" deliveryChangeRequestInfo.delivery_date as deliveryDate, deliveryChangeRequestInfo.delivery_time as deliveryTime, deliveryChangeRequestInfo.delivery_status as deliveryStatus, " +
			" deliveryChangeRequestInfo.request_okihai_place_1 as requestOkihaiPlace1, deliveryChangeRequestInfo.request_okihai_place_2 as requestOkihaiPlace2, " +
			" deliveryChangeRequestInfo.okihai_remarks as okihaiRemarks, deliveryChangeRequestGroupInfo.omatome_flag as omatomeFlag, deliveryChangeRequestGroupInfo.point as points, " +
			" deliveryChangeRequestInfo.change_timestamp as changeTimestamp " +
			" from delivery_change_request_group_info deliveryChangeRequestGroupInfo " + 
			" left join delivery_change_request_info deliveryChangeRequestInfo on deliveryChangeRequestInfo.change_request_id = deliveryChangeRequestGroupInfo.change_id where ";
	
	private QueryConstants() {
		throw new IllegalStateException("Utility class");
	}
}