package jp.co.rakuten.omatome.response;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import lombok.Data;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
  "responseCode",
  "responseMessage",
  "shippingList"
})
@Data
public class MyOrderResponseDTO implements Serializable {

  private static final long serialVersionUID = -8841697717522784371L;

  @JsonProperty("responseCode")
  private String responseCode;
  @JsonProperty("responseMessage")
  private String responseMessage;
  @JsonProperty("shippingList")
  private List<ShippingList> shippingList;

}
