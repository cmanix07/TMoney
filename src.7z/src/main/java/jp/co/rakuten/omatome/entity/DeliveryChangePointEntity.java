package jp.co.rakuten.omatome.entity;

import java.io.Serializable;
import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

@Entity
@EntityListeners(AuditingEntityListener.class)
@Table(name = "DELIVERY_CHANGE_REQUEST_GROUP_INFO")
public class DeliveryChangePointEntity implements Serializable {
  @Id
  @Column(name = "CHANGE_ID")
  private String changeId;

  @Column(name = "POINT")
  private Integer point;

  @Column(name = "OMATOME_FLAG")
  private boolean omatomeFlag;

  @CreatedDate
  @Column(name = "CREATE_TIMESTAMP")
  private LocalDateTime createTimestamp;

  @LastModifiedDate
  @Column(name = "CHANGE_TIMESTAMP")
  private LocalDateTime changeTimestamp;
  
  public DeliveryChangePointEntity() {
  }

  public DeliveryChangePointEntity(String changeId, Integer point, boolean omatomeFlag) {
    this.changeId = changeId;
    this.point = point;
    this.omatomeFlag = omatomeFlag;
  }

  public String getChangeId() {
    return changeId;
  }

  public Integer getPoint() {
    return point;
  }

  public boolean getOmatomeFlag() {
    return omatomeFlag;
  }
}
