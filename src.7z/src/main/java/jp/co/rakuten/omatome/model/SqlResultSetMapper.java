package jp.co.rakuten.omatome.model;

import java.time.LocalDate;
import java.time.LocalDateTime;

import javax.persistence.ColumnResult;
import javax.persistence.ConstructorResult;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.SqlResultSetMapping;
import javax.persistence.SqlResultSetMappings;

import lombok.Data;

@Data
@Entity
@SqlResultSetMappings({
@SqlResultSetMapping(name = "fetchMyOrders", classes = @ConstructorResult(
  targetClass = OrderDetails.class,
  columns = {
	      @ColumnResult(name = "orderNumber", type = String.class),
	      @ColumnResult(name = "oppFlag", type = Integer.class),

	      @ColumnResult(name = "originalNonOnePayTrackingNumber", type = String.class),
	      @ColumnResult(name = "nonOnePayDeliveryCompanyNumber", type = String.class),
	      @ColumnResult(name = "originalOnePayTrackingNumber", type = String.class),
	      @ColumnResult(name = "onePayDeliveryCompanyNumber", type = String.class),
	      
	      @ColumnResult(name = "itemId", type = Long.class),
	      @ColumnResult(name = "itemName", type = String.class),
	      @ColumnResult(name = "basketId", type = Long.class),
	      @ColumnResult(name = "wishDeliveryDate", type = LocalDate.class),
	      @ColumnResult(name = "orderDate", type = LocalDateTime.class),
	      @ColumnResult(name = "shopName", type = String.class),
	      @ColumnResult(name = "deliveryName", type = String.class),
      }
  )),
@SqlResultSetMapping(name = "fetchChangeRequestOrders", classes = @ConstructorResult(
		  targetClass = DeliveryChangeRequestInfo.class,
		  columns = {
		      @ColumnResult(name = "trackingNumber", type = String.class),
		      @ColumnResult(name = "companyNumber", type = String.class),
		      @ColumnResult(name = "changeRequestId", type = String.class),
		      
		      @ColumnResult(name = "deliveryDate", type = LocalDate.class),
		      @ColumnResult(name = "deliveryTime", type = String.class),
		      @ColumnResult(name = "deliveryStatus", type = Integer.class),
		      
		      @ColumnResult(name = "requestOkihaiPlace1", type = String.class),
		      @ColumnResult(name = "requestOkihaiPlace2", type = String.class),
		      @ColumnResult(name = "okihaiRemarks", type = String.class),
		      
		      @ColumnResult(name = "omatomeFlag", type = Integer.class),
		      @ColumnResult(name = "points", type = Integer.class),

		      @ColumnResult(name = "changeTimestamp", type = LocalDateTime.class),
		      
	      }
	  ))
})


public class SqlResultSetMapper {
  @Id
  private long id;
}
