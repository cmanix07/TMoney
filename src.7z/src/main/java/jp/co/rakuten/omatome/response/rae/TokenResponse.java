package jp.co.rakuten.omatome.response.rae;

public class TokenResponse {
  private String access_token;

  public TokenResponse() {
  }

  public TokenResponse(String access_token) {
    this.access_token = access_token;
  }

  public String getAccess_token() {
    return access_token;
  }
}
