package jp.co.rakuten.omatome.config;

import jp.co.rakuten.omatome.service.japanpost.development.DevelopmentJapanPostService;
import jp.co.rakuten.omatome.service.japanpost.production.ProductionJapanPostService;
import jp.co.rakuten.omatome.utils.EcoDeliverySlotChecker;
import jp.co.rakuten.omatome.utils.IdGenerator;
import jp.co.rakuten.omatome.utils.ThreadSafeWebClientGenerator;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.client.RestTemplate;

import java.util.List;

@Configuration
public class BeanConfiguration {

  @Value("${japan-post.baseUrl}")
  private String japanPostBaseUrl;

  @Value("#{'${eco.days.jp}'.split(',')}")
  private List<String> jpEcoDays;

  @Value("#{'${eco.days.rExpress}'.split(',')}")
  private List<String> rExpressEcoDays;

  @Value("#{'${eco.timeslot.jp}'.split(',')}")
  private List<String> jpEcoTimeSlots;

  @Value("#{'${eco.timeslot.rExpress}'.split(',')}")
  private List<String> rExpressEcoTimeSlots;

  @Bean
  public ThreadSafeWebClientGenerator webClientGenerator() {
    return new ThreadSafeWebClientGenerator();
  }

  @Bean
  @ConditionalOnProperty(
    value = "japan-post.service.type",
    havingValue = "production",
    matchIfMissing = false)
  @Qualifier("japanPostService")
  public ProductionJapanPostService japanPostService(ThreadSafeWebClientGenerator threadSafeWebClientGenerator) {
    return new ProductionJapanPostService(japanPostBaseUrl, threadSafeWebClientGenerator);
  }

  @Bean
  @ConditionalOnProperty(
    value = "japan-post.service.type",
    havingValue = "test",
    matchIfMissing = false)
  @Qualifier("japanPostService")
  public DevelopmentJapanPostService testJapanPostService() {
    return new DevelopmentJapanPostService(japanPostBaseUrl);
  }

  @Bean
  public IdGenerator idGenerator() {
    return new IdGenerator();
  }

  @Bean
  public EcoDeliverySlotChecker ecoDeliverySlotChecker() {
    return new EcoDeliverySlotChecker(jpEcoDays, jpEcoTimeSlots, rExpressEcoDays, rExpressEcoTimeSlots);
  }

  @Bean
  public RestTemplate restTemplate() {
    return new RestTemplate();
  }
}
