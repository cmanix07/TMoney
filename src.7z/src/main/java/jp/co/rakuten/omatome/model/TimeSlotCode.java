package jp.co.rakuten.omatome.model;

import java.util.EnumSet;
import java.util.Objects;

public enum TimeSlotCode {

  NOT_SPECIFY("00", "NOT_SPECIFY"),
  FIFTY_ONE("51", "08:00~12:00"),
  FIFTY_TWO("52", "12:00~14:00"),
  FIFTY_THREE("53", "14:00~16:00"),
  FIFTY_FOUR("54", "16:00~18:00"),
  FIFTY_FIVE("55", "18:00~20:00"),
  FIFTY_SEVEN("57", "19:00~21:00"),
  FIFTY_SIX("56", "20:00~21:00");

  private final String code;
  private final String description;

  TimeSlotCode(String code, String description) {
    this.code = code;
    this.description = description;
  }

  public static String getDescriptionFor(final String code) {
    return EnumSet
      .allOf(TimeSlotCode.class)
      .stream()
      .filter(e -> Objects.equals(e.getCode(), code))
      .findFirst().get().getTimeSlot();
  }

  public String getCode() {
    return code;
  }

  public String getTimeSlot() {
    return description;
  }
}
