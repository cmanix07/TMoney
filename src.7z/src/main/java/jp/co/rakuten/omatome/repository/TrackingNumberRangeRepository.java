package jp.co.rakuten.omatome.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import jp.co.rakuten.omatome.entity.OmatomeTrackingNumberRange;
import jp.co.rakuten.omatome.entity.OmatomeTrackingNumberRangeId;

@Repository
public interface TrackingNumberRangeRepository extends JpaRepository<OmatomeTrackingNumberRange,OmatomeTrackingNumberRangeId> {

	 @Query("select omatomeTrackingNumberRange from OmatomeTrackingNumberRange omatomeTrackingNumberRange "
	    		+ "where omatomeTrackingNumberRange.omatomeTrackingNumberRangeId.rangeType =:type")
		public List<OmatomeTrackingNumberRange> getTrackingNumberRangeByType(@Param("type") String type);
}
