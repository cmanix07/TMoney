package jp.co.rakuten.omatome.utils;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class OmatomeConstants {

  public static final String SUCCESS_RESPONSE_CODE = "S-000";
  public static final String SUCCESS_RESPONSE_MESSAGE = "Success";

  //As omatome scope is only JP and Express added as constants 
  public static final String JP_DELIVERY_COMPANY_NUMBER = "1003";
  public static final String EXPRESS_DELIVERY_COMPANY_NUMBER = "1028";
  
  //TODO: TO be update whether to be remove or used in the future
  public static final String JP_DELIVERY_HIST_STATUS_TRANSPORT = "14";
  public static final String JP_DELIVERY_HIST_STATUS_TRANSFER = "61";
  public static final String JP_DELIVERY_HIST_STATUS_RETURN = "62";
  
  //TODO: Get delivery name from omkar
  public static final List<String> DELIVERY_NAME = new ArrayList<>(Arrays.asList("宅配便", "宅配便[特定送料"));
  
  public static final List<Integer> DELIVERY_INVALID_STATUSES_JP = new ArrayList<>(Arrays.asList(7, 10));
  public static final List<Integer> DELIVERY_STATUSES_JP = new ArrayList<>(Arrays.asList(2, 3, 4));
  public static final List<Integer> REDELIVERY_STATUSES_JP = new ArrayList<>(Arrays.asList(4, 5, 6));
  public static final List<Integer> DELIVERY_STATUSES_R_EXPRESS = new ArrayList<>(Arrays.asList(7, 9, 10, 11 ));

  public static final String DATE_CHANGE_REQUEST = "DATE_CHANGE";
  public static final String REDELIVERY_REQUEST = "REDELIVERY";
  
  public static final String YYYY_MM_DD_PATTERN = "yyyy/MM/dd";
  public static final String OMATOME_DEFAULT_ACTION = "おまとめ";
  public static final int POINTS_PER_TRACKING_NUMBER = 10;
  
  
  public static final String PRIVACY_POLICY_URL= "https://privacy.rakuten.co.jp/app/";
  public static final String LICENSE_URL= "https://corp.rakuten.co.jp/copyright/app/";
  public static final String APP_LIST_URL= "https://www.rakuten.co.jp/sitemap/sp/app.html";
  
  public static final int NUMBER_OF_DAYS_DATA = 90;
  
  public static final String RANGE_TYPE="PUSH_POINT_RANGE";

}
