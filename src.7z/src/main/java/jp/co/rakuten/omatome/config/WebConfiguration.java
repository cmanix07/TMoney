package jp.co.rakuten.omatome.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpStatus;
import org.springframework.web.servlet.config.annotation.ViewControllerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@Configuration
public class WebConfiguration implements WebMvcConfigurer {

  private static final String INDEX_PATH = "/";
  private static final String SWAGGER_UI_PATH = "/swagger-ui.html";

  @Override
  public final void addViewControllers(ViewControllerRegistry registry) {
    // Redirect index page to SwaggerUI
    registry.addRedirectViewController(INDEX_PATH, SWAGGER_UI_PATH)
      .setStatusCode(HttpStatus.SEE_OTHER);
  }

}
