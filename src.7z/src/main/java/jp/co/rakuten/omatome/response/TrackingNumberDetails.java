package jp.co.rakuten.omatome.response;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import lombok.Data;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "trackingNumber" ,"linkDeliveryChangeUrl","redeliveryUrl","deliveryStatus","deliveryDate","deliveryTime",
 "companyNumber", "shopName", "changeType", "items", "orderList" })
public class TrackingNumberDetails implements Serializable {

	private static final long serialVersionUID = -4045255092646214676L;

	@JsonProperty("trackingNumber")
	private String trackingNumber;
	
	@JsonProperty("linkDeliveryChangeUrl")
	private String linkDeliveryChangeUrl;
	
	@JsonProperty("redeliveryUrl")
	private String redeliveryUrl;
	
	@JsonProperty("deliveryStatus")
	private Integer deliveryStatus;

	@JsonProperty("deliveryDate")
	private String deliveryDate;

	@JsonProperty("deliveryTime")
	private String deliveryTime;
	
	@JsonProperty("companyNumber")
	private String companyNumber;

	@JsonProperty("shopName")
	private String shopName;

	@JsonProperty("changeType")
	private String changeType;

	@JsonProperty("items")
	private List<ItemInfo> itemList;

	@JsonProperty("orderList")
	private List<OrderInfo> orderList;

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		TrackingNumberDetails other = (TrackingNumberDetails) obj;
		if (trackingNumber == null) {
			if (other.trackingNumber != null)
				return false;
		} else if (!trackingNumber.equals(other.trackingNumber))
			return false;
		return true;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((trackingNumber == null) ? 0 : trackingNumber.hashCode());
		return result;
	}
	
}
