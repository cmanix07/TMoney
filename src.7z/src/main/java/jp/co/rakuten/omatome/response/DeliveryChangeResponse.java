package jp.co.rakuten.omatome.response;

import jp.co.rakuten.omatome.model.TrackingInfo;

import java.util.List;
import java.util.Map;

public class DeliveryChangeResponse {
  private String changeId;
  private Map<String, List<TrackingInfo>> changeStatus;
  private Integer rewardedPoint;
  private String deliveryDate;
  private String timeSlotCode;
  private boolean ecoFlag;
  private String timeRange;

  public DeliveryChangeResponse() {
  }

  public DeliveryChangeResponse(String changeId,
                                Map<String, List<TrackingInfo>> changeStatus,
                                Integer rewardedPoint,
                                String deliveryDate,
                                String timeSlotCode,
                                String timeRange,
                                boolean ecoFlag) {
    this.changeId = changeId;
    this.changeStatus = changeStatus;
    this.rewardedPoint = rewardedPoint;
    this.deliveryDate = deliveryDate;
    this.timeSlotCode = timeSlotCode;
    this.ecoFlag = ecoFlag;
    this.timeRange = timeRange;
  }

  public String getChangeId() {
    return changeId;
  }

  public Map<String, List<TrackingInfo>> getChangeStatus() {
    return changeStatus;
  }

  public Integer getRewardedPoint() {
    return rewardedPoint;
  }

  public String getDeliveryDate() {
    return deliveryDate;
  }

  public String getTimeSlotCode() {
    return timeSlotCode;
  }

  public boolean getEcoFlag() {
    return ecoFlag;
  }

  public String getTimeRange() {
    return timeRange;
  }
}
