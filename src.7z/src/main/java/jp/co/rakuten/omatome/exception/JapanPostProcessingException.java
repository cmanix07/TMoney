package jp.co.rakuten.omatome.exception;

public class JapanPostProcessingException extends RuntimeException {

  public JapanPostProcessingException(String message) {
    super(message);
  }
}
