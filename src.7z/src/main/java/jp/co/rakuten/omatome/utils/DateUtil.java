package jp.co.rakuten.omatome.utils;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import lombok.experimental.UtilityClass;

@UtilityClass
public class DateUtil {

	public static final String DATE_PATTERN_YYYYMMDD = "yyyyMMdd";

	public static final String DATE_PATTERN_YYYYMMDD_HHMM = "yyyy/MM/dd HH:mm";

    public String format(LocalDate date) {
        if (date == null) {
            return null;
        }
        return date.format(DateTimeFormatter.ofPattern(DATE_PATTERN_YYYYMMDD));
    }

    public String format(LocalDateTime date) {
        if (date == null) {
            return null;
        }
        return date.format(DateTimeFormatter.ofPattern(DATE_PATTERN_YYYYMMDD_HHMM));
    }
    
    public String format(String times) {
    	String updatedTime = null;
    	if(times != null) {
	    	String[] time = times.split("-");
	    	updatedTime = time[0].substring(0,2) + ":" + time[0].substring(2) + "~" + 
    			time[1].substring(0,2) + ":" + time[1].substring(2);
    	}
    	return updatedTime;
    }
    
    public LocalDate getLocalDate(String date) {
        return LocalDate.parse(date, DateTimeFormatter.ofPattern(DATE_PATTERN_YYYYMMDD));
    }
}
