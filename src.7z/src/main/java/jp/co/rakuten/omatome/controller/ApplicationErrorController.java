package jp.co.rakuten.omatome.controller;

import jp.co.rakuten.omatome.exception.ApiError;
import jp.co.rakuten.omatome.exception.OmatomeException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import java.util.HashSet;
import java.util.Set;

@Component
@ControllerAdvice
public class ApplicationErrorController extends ResponseEntityExceptionHandler {
  public static final String GE_001 = "GE-001";
  public static final String GE_002 = "GE-002";

  private static Logger log = LoggerFactory.getLogger(ApplicationErrorController.class);

  @Override
  protected ResponseEntity<Object> handleHttpMessageNotReadable(HttpMessageNotReadableException ex,
                                                                HttpHeaders headers, HttpStatus status, WebRequest request) {
    String error = "Invalid syntax for this request was provided.";
    return buildResponseEntity(new ApiError(HttpStatus.BAD_REQUEST, GE_001, error, ex));
  }

  private ResponseEntity<Object> buildResponseEntity(ApiError apiError) {
    return new ResponseEntity<>(apiError, apiError.getStatus());
  }

  @ExceptionHandler(OmatomeException.class)
  protected ResponseEntity<Object> handleOmatomeException(OmatomeException ex) {

    log.info("Error occurred: {}", ex.getErrorMessage());

    ApiError apiError = new ApiError(ex.getStatus());
    apiError.setCode(ex.getErrorCode());
    apiError.setMessage(ex.getMessage());
    return buildResponseEntity(apiError);
  }

  @ExceptionHandler(RuntimeException.class)
  protected ResponseEntity<Object> handleRuntimeServerException(RuntimeException ex) {
    log.error("Error occurred: {}", ex);

    ApiError apiError = new ApiError(HttpStatus.INTERNAL_SERVER_ERROR);
    apiError.setCode("500");
    apiError.setMessage("Unexpected internal server error. Please try after sometime.");
    return buildResponseEntity(apiError);
  }

  @Override
  protected ResponseEntity<Object> handleMethodArgumentNotValid(MethodArgumentNotValidException ex,
                                                                HttpHeaders headers, HttpStatus status, WebRequest request) {

    Set<String> errors = new HashSet<>();
    ex.getBindingResult().getFieldErrors().stream().forEach(error ->
      errors.add(error.getDefaultMessage())
    );
    String errorMessage = String.join(", ", errors);
    ApiError apiError = new ApiError(HttpStatus.BAD_REQUEST);
    apiError.setCode("400");
    apiError.setMessage(errorMessage);
    return buildResponseEntity(apiError);
  }

}
