package jp.co.rakuten.omatome.model;

import jp.co.rakuten.omatome.response.TimeSlot;

import java.util.List;

public class DateTimeSlot {
  private String date;
  private boolean ecoTimeSlotAvailable;
  private List<TimeSlot> timeSlots;

  public DateTimeSlot() {
  }

  public DateTimeSlot(String date, boolean ecoTimeSlotAvailable, List<TimeSlot> timeSlots) {
    this.date = date;
    this.ecoTimeSlotAvailable = ecoTimeSlotAvailable;
    this.timeSlots = timeSlots;
  }

  public String getDate() {
    return date;
  }

  public List<TimeSlot> getTimeSlots() {
    return timeSlots;
  }

  public boolean isEcoTimeSlotAvailable() {
    return ecoTimeSlotAvailable;
  }
}
