package jp.co.rakuten.omatome.response.rae;

public class EasyIdResponse {
  private String easy_id;

  public EasyIdResponse() {
  }

  public EasyIdResponse(String easy_id) {
    this.easy_id = easy_id;
  }

  public String getEasy_id() {
    return easy_id;
  }
}
