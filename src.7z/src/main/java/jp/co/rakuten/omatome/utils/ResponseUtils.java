package jp.co.rakuten.omatome.utils;

import static jp.co.rakuten.omatome.utils.TrackingNumberCleaner.cleanMultipleTrackingNumber;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import jp.co.rakuten.omatome.entity.DeliveryInfoEntity;
import jp.co.rakuten.omatome.entity.OmatomeTrackingNumberRange;
import jp.co.rakuten.omatome.model.DeliveryChangeRequestInfo;
import jp.co.rakuten.omatome.model.OrderDetails;
import jp.co.rakuten.omatome.response.ItemDetails;
import jp.co.rakuten.omatome.response.ItemInfo;
import jp.co.rakuten.omatome.response.MyOrderResponseDTO;
import jp.co.rakuten.omatome.response.OrderInfo;
import jp.co.rakuten.omatome.response.ShippingList;
import jp.co.rakuten.omatome.response.TrackingNumberDetails;


@Component
public class ResponseUtils {

  private static final Logger log = LoggerFactory.getLogger(ResponseUtils.class);

  public MyOrderResponseDTO getMyOrderResponse(List<OrderDetails> orderDetailsList,Map<String, DeliveryInfoEntity> deliveryInfoMap, 
		  Map<String, DeliveryChangeRequestInfo> deliveryChangeRequestInfoMap, List<OmatomeTrackingNumberRange> omatomeTrackingNumberRangeList ) {

    MyOrderResponseDTO myOrderResponseDTO = new MyOrderResponseDTO();
    List<ShippingList> resultShippingList = new ArrayList<>();
    
    //Keeps track of omatome Id and its shippingList or tracking Number and its shipping List
    Map<String, ShippingList> omatomeIdShippingListMap = new HashMap<>();
    
    //Keeps track of trackingnumber and its omatomeId
    Map<String, String> trackingNumberOmatomeIdMap = new HashMap<>();
    
    //Keeps track of trackingNumber and its details
	Map<String, TrackingNumberDetails> trackingNumberDetailsMap = new LinkedHashMap<>();
	
	
    for(OrderDetails orderDetails : orderDetailsList) {
    		
    	String trackingNumber = orderDetails.getTrackingNumber();
    	String orderNumber = orderDetails.getOrderNumber();
    	String companyNumber = orderDetails.getCompanyNumber();
    	
    	if ( trackingNumber == null) {
			Entry<String, TrackingNumberDetails> lastTrackingNumberMap = trackingNumberDetailsMap.entrySet().stream()
					.reduce((first, second) -> second).orElse(null);
			if (lastTrackingNumberMap != null) {
				trackingNumber = lastTrackingNumberMap.getKey();
				TrackingNumberDetails trackingNumberDetail = lastTrackingNumberMap.getValue();
				String lastOrderNumber = trackingNumberDetail.getOrderList().get(0).getOrderNumber();
				if(!lastOrderNumber.equals(orderNumber)) {
					trackingNumber = null;
				}
			}
		}
    	String deliveryInfoKey = getDeliveryInfoKey(trackingNumber, orderDetails.getCompanyNumber(), orderDetails.getOrderNumber());
    	
    	cleanMultipleTrackingNumber(trackingNumber).forEach(cleanedTrackingNumber -> {
    	
	    	String changeRequestIdkey = cleanedTrackingNumber + "-" + orderDetails.getCompanyNumber();
    		DeliveryChangeRequestInfo deliveryChangeRequestInfo = deliveryChangeRequestInfoMap.get(changeRequestIdkey);
	    	DeliveryInfoEntity deliveryInfoEntity = deliveryInfoMap.get(deliveryInfoKey);
    		int point = 0;
    		
	    	String changeRequestId = null;
	    	if(deliveryChangeRequestInfo != null) {
	    		changeRequestId = deliveryChangeRequestInfo.getChangeRequestId();
	    		point = deliveryChangeRequestInfo.getPoints();
				log.info("changeRequestId:{}", changeRequestId);

	    	}

	    	if(trackingNumberOmatomeIdMap.get(changeRequestIdkey) != null) {
	    		changeRequestId = trackingNumberOmatomeIdMap.get(changeRequestIdkey);
	    	}
	    	
	    	ShippingList shippingList = getShippingList( changeRequestId, cleanedTrackingNumber, omatomeIdShippingListMap );
	      	
	    	List<TrackingNumberDetails> trackingNumberDetailsList = shippingList.getTrackingNumberDetails();
	    	if(trackingNumberDetailsList == null) {
	    		trackingNumberDetailsList = new LinkedList<>();
	    	}
	    	
	    	TrackingNumberDetails trackingNumberDetails =  getTrackingNumberDetails( cleanedTrackingNumber, orderDetails, trackingNumberDetailsMap, deliveryInfoMap, deliveryChangeRequestInfo) ;
	    	
	    	if(!invalidTrackingNumber(cleanedTrackingNumber, companyNumber, omatomeTrackingNumberRangeList) && checkDeliveryStatus(changeRequestId, companyNumber, deliveryInfoEntity)) {
		    	List<OrderInfo> orderInfoList = trackingNumberDetails.getOrderList();
		    	List<ItemInfo> itemInfoList = trackingNumberDetails.getItemList();
		    	if(orderInfoList == null) {
		    		orderInfoList = new ArrayList<>();
		    	}
		    	if(itemInfoList == null) {
		    		itemInfoList = new ArrayList<>();
		    	}

		      	if(deliveryInfoEntity != null) {
			  		if(LocalDate.now().equals(deliveryInfoEntity.getDeliveryDate())) {
			  			shippingList.setDeliveryDateToday(true);
			  		}
			  		
			  		if(deliveryChangeRequestInfo == null && (deliveryInfoEntity.getExtendedFlag3() == null || deliveryInfoEntity.getExtendedFlag3() == 0)) {
			    		point = OmatomeConstants.POINTS_PER_TRACKING_NUMBER;
			    	}
		      	}
		    	String orderDate = DateUtil.format(orderDetails.getOrderDate());
		    	OrderInfo orderInfo = new OrderInfo();
		    	orderInfo.setOrderNumber(orderNumber);
		    	orderInfo.setOrderDate(orderDate);
		    	
		    	int index = orderInfoList.indexOf(orderInfo);
		    	
		    	if(index != -1) {
		    		orderInfo = orderInfoList.get(index);
		    		List<ItemDetails> itemDetailsList = orderInfo.getItemDetails();
		    		itemDetailsList.add(getItemDetails(orderDetails));
		    		orderInfo.setItemDetails(itemDetailsList);
		    		
		    	} else {
		    		List<ItemDetails>  itemDetailsList = new LinkedList<>();
		    		itemDetailsList.add(getItemDetails(orderDetails));
		    		orderInfo.setItemDetails(itemDetailsList);
		    		orderInfoList.add(orderInfo);
		    		
		    	}
		    	trackingNumberDetails.setOrderList(orderInfoList);
		    	
		    	ItemInfo itemInfo = new ItemInfo();
		    	itemInfo.setItemName(orderDetails.getItemName());
		    	itemInfo.setOrderDate(orderDate);
		    	itemInfoList.add(itemInfo);
		    	Collections.sort(itemInfoList);
		    	trackingNumberDetails.setItemList(itemInfoList);
		    	
		    	if(!trackingNumberDetailsList.contains(trackingNumberDetails)) {
		    		trackingNumberDetailsList.add(trackingNumberDetails);
			    	shippingList.setDeliveryStatusDisplay(trackingNumberDetails.getDeliveryStatus());
		    		shippingList.setDeliveryDateDisplay(trackingNumberDetails.getDeliveryDate());
		    		shippingList.setDeliveryTimeDisplay(trackingNumberDetails.getDeliveryTime());
		    		shippingList.setCompanyNumberDisplay(trackingNumberDetails.getCompanyNumber());
		    		shippingList.setShopNameDisplay(trackingNumberDetails.getShopName());
		    		shippingList.setItemNameDisplay(orderDetails.getItemName());
		    		shippingList.setTrackingNumberDisplay(trackingNumberDetails.getTrackingNumber());
		    		shippingList.setChangeTypeDisplay(trackingNumberDetails.getChangeType());
		    		if(deliveryChangeRequestInfo != null) {
		    			if(deliveryChangeRequestInfo.getRequestOkihaiPlace1() != null || deliveryChangeRequestInfo.getRequestOkihaiPlace2() != null) {
			    			shippingList.setOkihaiOrder(true);
			    		}else {
			    			shippingList.setOkihaiOrder(false);
			    		}
			    		shippingList.setRequestOkihaiPlace1(deliveryChangeRequestInfo.getRequestOkihaiPlace1());
			    		shippingList.setRequestOkihaiPlace2(deliveryChangeRequestInfo.getRequestOkihaiPlace2());
			    		shippingList.setOkihaiRemarks(deliveryChangeRequestInfo.getOkihaiRemarks());
			    		shippingList.setChangeRequestId(changeRequestId);
		    		}
		    	} else {
		    		//replace the tracking number details object in the list
		    		trackingNumberDetailsList.remove(trackingNumberDetails);
		    		trackingNumberDetailsList.add(trackingNumberDetails);
		    		
		    	}
		    	
		    	shippingList.setTrackingNumberDetails(trackingNumberDetailsList);
		    	shippingList.setPoints(point);
		    	
		    	trackingNumberDetailsMap.put(cleanedTrackingNumber, trackingNumberDetails);

		    	if(deliveryChangeRequestInfo != null && (deliveryChangeRequestInfo.getOmatomeFlag()==1)) {
		    		log.info("deliveryChangeRequestInfo.getOmatomeFlag():{}", deliveryChangeRequestInfo.getOmatomeFlag());

		    		shippingList.setOmatomeOrder(true);
		    		trackingNumberOmatomeIdMap.put(changeRequestIdkey, changeRequestId);
		    		omatomeIdShippingListMap.put(changeRequestId, shippingList);
		    	} else {
		    		shippingList.setOmatomeOrder(false);
		    		omatomeIdShippingListMap.put(cleanedTrackingNumber, shippingList);
		    	}
	    	}
    	
    	});
		
    }

    List<ShippingList> omatomeShippingList = new ArrayList<>();
    for(Map.Entry<String, ShippingList> shippingListMap : omatomeIdShippingListMap.entrySet()) {
    	ShippingList shippingList = shippingListMap.getValue();
    	if(shippingList.isOmatomeOrder()) {
    		omatomeShippingList.add(shippingList);
    	}else {
    		resultShippingList.add(shippingList);
    	}
    }
    
    resultShippingList.addAll(omatomeShippingList);
    myOrderResponseDTO.setShippingList(resultShippingList);
    myOrderResponseDTO.setResponseCode(OmatomeConstants.SUCCESS_RESPONSE_CODE);
    myOrderResponseDTO.setResponseMessage(OmatomeConstants.SUCCESS_RESPONSE_MESSAGE);
    return myOrderResponseDTO;
  }
  
  
  private ItemDetails getItemDetails(OrderDetails orderDetails) {
	ItemDetails itemDetail = new ItemDetails();
	itemDetail.setBasketId(orderDetails.getBasketId());
	itemDetail.setItemId(orderDetails.getItemId());
	itemDetail.setItemName(orderDetails.getItemName());
	return itemDetail;
  }
  
  private ShippingList getShippingList(String omatomeId,String trackingNumber,Map<String,ShippingList> omatomeIdShippingListMap ) {
	ShippingList shippingList = new ShippingList();
	if(omatomeId != null && omatomeIdShippingListMap.get(omatomeId) != null ) {
  		shippingList = omatomeIdShippingListMap.get(omatomeId);
  	} 
  	
  	if(omatomeIdShippingListMap.get(trackingNumber)!= null) {
  		shippingList = omatomeIdShippingListMap.get(trackingNumber);
  	}
  	
  	return shippingList;
  	
  }
  
  private TrackingNumberDetails getTrackingNumberDetails(String trackingNumber,OrderDetails orderDetails,
		  Map<String, TrackingNumberDetails> trackingNumberDetailsMap,Map<String,DeliveryInfoEntity> deliveryInfoMap, DeliveryChangeRequestInfo deliveryChangeRequestInfo  ) {
	TrackingNumberDetails trackingNumberDetails = trackingNumberDetailsMap.get(trackingNumber);
  	if(trackingNumberDetails == null) {
  		trackingNumberDetails = new TrackingNumberDetails();
  	}

  	trackingNumberDetails.setCompanyNumber(orderDetails.getCompanyNumber());
  	trackingNumberDetails.setTrackingNumber(trackingNumber);
  	trackingNumberDetails.setDeliveryDate(DateUtil.format(orderDetails.getWishDeliveryDate()));
  	trackingNumberDetails.setShopName(orderDetails.getShopName());
  	
  	String deliveryInfoKey = getDeliveryInfoKey(trackingNumber, orderDetails.getCompanyNumber(), orderDetails.getOrderNumber());
  	DeliveryInfoEntity deliveryInfo = deliveryInfoMap.get(deliveryInfoKey);
  	if(deliveryInfo != null) {
		trackingNumberDetails.setLinkDeliveryChangeUrl(deliveryInfo.getDeliveryRequestUrl());
		trackingNumberDetails.setRedeliveryUrl(deliveryInfo.getRedeliveryRequestUrl());
  		trackingNumberDetails.setDeliveryStatus(deliveryInfo.getDeliveryStatus());
  		trackingNumberDetails.setDeliveryDate(DateUtil.format(deliveryInfo.getDeliveryDate()));
  		trackingNumberDetails.setDeliveryTime(DateUtil.format(deliveryInfo.getDeliveryTime()));

  		if(deliveryChangeRequestInfo != null && deliveryChangeRequestInfo.getChangeTimestamp() != null && deliveryChangeRequestInfo.getChangeTimestamp().isAfter(deliveryInfo.getChangeTimestamp())) {
	  		trackingNumberDetails.setDeliveryDate(DateUtil.format(deliveryChangeRequestInfo.getDeliveryDate()));
	  		trackingNumberDetails.setDeliveryTime(deliveryChangeRequestInfo.getDeliveryTime());
  		}
  		
  		if(deliveryInfo.getDeliveryRequestUrl()!=null) {
  			trackingNumberDetails.setChangeType(OmatomeConstants.DATE_CHANGE_REQUEST);
  		} else {
  			if(orderDetails.getCompanyNumber().equals(OmatomeConstants.JP_DELIVERY_COMPANY_NUMBER)) {
  				trackingNumberDetails.setChangeType(OmatomeConstants.REDELIVERY_REQUEST);
  			} else {
  				trackingNumberDetails.setChangeType(OmatomeConstants.DATE_CHANGE_REQUEST);
  			}
  		}
  		
  	}
  	return trackingNumberDetails;
  }
  
  public String getDeliveryInfoKey(String trackingNumber,String companyNumber,String orderNumber) {
	  String key = trackingNumber + "-" + companyNumber + "-" + orderNumber;
	  return key;
  }

  public boolean invalidTrackingNumber(String trackingNumber, String companyNumber, List<OmatomeTrackingNumberRange> omatomeTrackingNumberRangeList) {

	  DeliveryCompanyNumber deliveryCompanyNumber = DeliveryCompanyNumber.getDeliveryCompanyNumber(companyNumber);

	  return(deliveryCompanyNumber == null || trackingNumber == null || 
			  !trackingNumber.matches(deliveryCompanyNumber.getTrackingNumberPattern()) || !isWithinTrackingNumberRange(trackingNumber, companyNumber, omatomeTrackingNumberRangeList)); 
		  
  }

  /**
   * 
   * @param trackingNumber
   * @return
   */
  public boolean isWithinTrackingNumberRange(
		  String trackingNumberStr, String companyNumber, List<OmatomeTrackingNumberRange> omatomeTrackingNumberRangeList) {

	  for (OmatomeTrackingNumberRange trackingNumberRange : omatomeTrackingNumberRangeList) {
		  if (companyNumber.equalsIgnoreCase(trackingNumberRange.getOmatomeTrackingNumberRangeId().getCompanyNumber())) {
			  Long trackingNumber = Long.parseLong(trackingNumberStr);
			  if (trackingNumber >= trackingNumberRange.getOmatomeTrackingNumberRangeId().getTrackingNumberBegin()
					  && trackingNumber <= trackingNumberRange.getOmatomeTrackingNumberRangeId()
					  .getTrackingNumberEnd()) {
				  return true;
			  }
		  }

	  }

	  return false;

  }
  
  private boolean checkDeliveryStatus(String changeRequestId, String companyNumber, DeliveryInfoEntity deliveryInfoEntity) {
	  if(changeRequestId == null && deliveryInfoEntity != null && OmatomeConstants.JP_DELIVERY_COMPANY_NUMBER.equals(companyNumber) ) {
		  if((deliveryInfoEntity.getDeliveryRequestUrl() != null && OmatomeConstants.DELIVERY_STATUSES_JP.contains(deliveryInfoEntity.getDeliveryStatus()))
				  || (deliveryInfoEntity.getRedeliveryRequestUrl() != null && OmatomeConstants.REDELIVERY_STATUSES_JP.contains(deliveryInfoEntity.getDeliveryStatus()))){
    		return true;
		  }
	  }else if(changeRequestId != null && deliveryInfoEntity != null && OmatomeConstants.JP_DELIVERY_COMPANY_NUMBER.equals(companyNumber) ) {
		  if(!OmatomeConstants.DELIVERY_INVALID_STATUSES_JP.contains(deliveryInfoEntity.getDeliveryStatus())){
    		return true;
		  }
	  }
	  if(deliveryInfoEntity != null && OmatomeConstants.EXPRESS_DELIVERY_COMPANY_NUMBER.equals(companyNumber) && !OmatomeConstants.DELIVERY_STATUSES_R_EXPRESS.contains(deliveryInfoEntity.getDeliveryStatus())) {
		  return true;
	  }
	  return false;
  }

}