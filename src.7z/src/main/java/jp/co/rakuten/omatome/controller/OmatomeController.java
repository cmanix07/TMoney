package jp.co.rakuten.omatome.controller;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import jp.co.rakuten.omatome.exception.JapanPostProcessingException;
import jp.co.rakuten.omatome.request.AvailableDeliveryDateRequest;
import jp.co.rakuten.omatome.request.ModifyDeliveryRequest;
import jp.co.rakuten.omatome.response.AppMetadataResponse;
import jp.co.rakuten.omatome.response.AvailableDeliveryDatesResponse;
import jp.co.rakuten.omatome.response.DeliveryChangeResponse;

import jp.co.rakuten.omatome.response.MyMenuResponse;

import jp.co.rakuten.omatome.response.MyOrderResponseDTO;
import jp.co.rakuten.omatome.response.PointAllocationHistoryResponseDTO;
import jp.co.rakuten.omatome.response.TimeSlot;
import jp.co.rakuten.omatome.service.DeliveryModificationService;
import jp.co.rakuten.omatome.service.OmatomeService;
import jp.co.rakuten.omatome.service.PointAllocationHistoryService;
import jp.co.rakuten.omatome.utils.EasyIdService;

@Api(value = "OmatomeApi")
@RestController(value = OmatomeController.API_PATH)
@RequestMapping(OmatomeController.API_PATH)
public class OmatomeController {

  public static final String API_PATH = "/omatomeApi";

  private static final Logger LOG = LoggerFactory.getLogger(OmatomeController.class);
  private final DeliveryModificationService deliveryModificationService;
  private final OmatomeService omatomeService;
  private PointAllocationHistoryService pointAllocationHistoryService;
  private EasyIdService easyIdService;

  @Autowired
  public OmatomeController(OmatomeService omatomeService,
                           DeliveryModificationService deliveryModificationService,
                           EasyIdService easyIdService,
                           PointAllocationHistoryService pointAllocationHistoryService) {
    this.omatomeService = omatomeService;
    this.deliveryModificationService = deliveryModificationService;
    this.easyIdService = easyIdService;
    this.pointAllocationHistoryService = pointAllocationHistoryService;
  }

  @ApiOperation(value = "My Order details", response = MyOrderResponseDTO.class)
  @ApiResponses(value = {@ApiResponse(code = 200, message = "successfully fetched my orders "),
    @ApiResponse(code = 400, message = "Bad Request Error"),
    @ApiResponse(code = 401, message = "You are unauthorized to access the requested resource. Please log in."),
    @ApiResponse(code = 403, message = "Your account is not authorized to access the requested resource.")})
  @GetMapping(path = "/myOrders")
  @ResponseBody
  public ResponseEntity<MyOrderResponseDTO> fetchMyOrders(@RequestParam(required = false,name = "companyNumber")  String companyNumber,
                                                          @RequestHeader(name = "RAE_ACCESS_TOKEN") String raeToken) {


    LOG.info("Received request for my orders:{}", companyNumber);

    String easyId = easyIdService.getEasyId(raeToken);

    List<String> companyNumbers = new ArrayList<>();
    if (StringUtils.isNotBlank(companyNumber)) {
      companyNumbers = Arrays.asList(companyNumber.split(","));
    }
    MyOrderResponseDTO myOrderResponseDTO = omatomeService.fetchMyOrders(easyId, companyNumbers);

    LOG.info("Processed request for my orders");
    return ResponseEntity.ok(myOrderResponseDTO);
  }

  @ApiOperation(value = "Available dates for changing delivery date", response = AvailableDeliveryDatesResponse.class)
  @ApiResponses(value = {@ApiResponse(code = 200,
    message = "successfully fetched dates available for changing delivery date"),
    @ApiResponse(code = 400, message = "Bad Request Error"),
    @ApiResponse(code = 401, message = "You are unauthorized to access the requested resource. Please log in."),
    @ApiResponse(code = 403, message = "Your account is not authorized to access the requested resource.")})
  @PostMapping(path = "/available-dates")
  @ResponseBody
  public ResponseEntity<AvailableDeliveryDatesResponse> fetchAvailableDates(
    @RequestBody AvailableDeliveryDateRequest availableDeliveryDateRequest) {

    Map<String, List<TimeSlot>> availableDates = new LinkedHashMap<>();

    LOG.info("Received request to get available dates");

    try {
      availableDates = deliveryModificationService
        .availableDates(
          availableDeliveryDateRequest.getTrackingInfoList(),
          availableDeliveryDateRequest.getCompanyNumber());

      LOG.info("Completed request to get available dates");
    } catch (JapanPostProcessingException e) {
      LOG.warn("Error in processing request for available dates");
    }

    return ResponseEntity.ok(AvailableDeliveryDatesResponse.buildFrom(availableDates));
  }

  @ApiOperation(value = "Change delivery request", response = DeliveryChangeResponse.class)
  @ApiResponses(value = {@ApiResponse(code = 201, message = "successfully created omatome"),
    @ApiResponse(code = 400, message = "Bad Request Error"),
    @ApiResponse(code = 401, message = "You are unauthorized to access the requested resource. Please log in."),
    @ApiResponse(code = 403, message = "Your account is not authorized to access the requested resource.")})
  @PostMapping(path = "/delivery-change")
  @ResponseBody
  public ResponseEntity<?> modifyDelivery(
    @RequestBody ModifyDeliveryRequest modifyDeliveryRequest,@RequestHeader(name = "RAE_ACCESS_TOKEN") String raeToken) {

    LOG.info("Received request to change delivery");
    String easyId = easyIdService.getEasyId(raeToken);
    String contactNumber="";
    DeliveryChangeResponse deliveryChangeResponse = deliveryModificationService
      .modifyDelivery(
        modifyDeliveryRequest.getTrackingInfoList(),
        modifyDeliveryRequest.getDeliveryDate(),
        modifyDeliveryRequest.getTimeSlotCode(),
        contactNumber,
        modifyDeliveryRequest.getCompanyNumber(),
        modifyDeliveryRequest.isEcoFlag());

    LOG.info("Completed request for delivery change");
    return ResponseEntity.accepted().body(deliveryChangeResponse);

  }

  @ApiOperation(value = "register")
  @ApiResponses(value = {@ApiResponse(code = 200, message = "User registered successfully"),
    @ApiResponse(code = 400, message = "Bad Request Error"),
    @ApiResponse(code = 401, message = "You are unauthorized to access the requested resource. Please log in."),
    @ApiResponse(code = 403, message = "Your account is not authorized to access the requested resource.")})
  @PostMapping(path = "/register")
  public void register(@RequestHeader(name = "RAE_ACCESS_TOKEN") String raeToken,
                       @RequestHeader(name = "DEVICE_ID") String deviceId,
                       @RequestHeader(name = "APP_VERSION") String appVersion) {

    String easyId = easyIdService.getEasyId(raeToken);

    LOG.info("Received request for user register");

    omatomeService.register(easyId, deviceId,appVersion);

    LOG.info("Processed request for user register");
  }

  @ApiOperation(value = "Point Allocation history", response = PointAllocationHistoryResponseDTO.class)
  @ApiResponses(value = {@ApiResponse(code = 200, message = "Successfully fetched the point allocated records for easyId"),
    @ApiResponse(code = 400, message = "Bad Request Error"),
    @ApiResponse(code = 401, message = "You are unauthorized to access the requested resource. Please log in."),
    @ApiResponse(code = 403, message = "Your account is not authorized to access the requested resource.")})
  @GetMapping(path = "/point-history")
  public ResponseEntity<PointAllocationHistoryResponseDTO> fetchPointAllocationHistory(@RequestHeader(name = "RAE_ACCESS_TOKEN") String raeToken) {
	Long easyId = Long.parseLong(easyIdService.getEasyId(raeToken));

    LOG.info("Received request of pointallocation history ");
    PointAllocationHistoryResponseDTO responseDTO = pointAllocationHistoryService.fetchPointAllocationHistory(easyId);

    LOG.info("Processed request for pointallocation history ");
    return ResponseEntity.ok(responseDTO);

  }

  
  @ApiOperation(value = "Get App Metadata", response = AppMetadataResponse.class)
  @ApiResponses(value = {@ApiResponse(code = 200, message = "successfully fetched app metadata "),
    @ApiResponse(code = 400, message = "Bad Request Error"),
    @ApiResponse(code = 401, message = "You are unauthorized to access the requested resource. Please log in."),
    @ApiResponse(code = 403, message = "Your account is not authorized to access the requested resource.")})
  @GetMapping(path = "/app-metadata")
  @ResponseBody
  public ResponseEntity<AppMetadataResponse> getAppMetadata() {


    LOG.info("Received request for Get App Metadata");

    AppMetadataResponse appMetadataResponse = omatomeService.getAppMetadata();

    LOG.info("Processed request for Get App Metadata");
    return ResponseEntity.ok(appMetadataResponse);
  }

  @ApiOperation(value = "Update Notification Settings")
  @ApiResponses(value = {@ApiResponse(code = 200, message = "Notification Settings update"),
    @ApiResponse(code = 400, message = "Bad Request Error"),
    @ApiResponse(code = 401, message = "You are unauthorized to access the requested resource. Please log in."),
    @ApiResponse(code = 403, message = "Your account is not authorized to access the requested resource.")})
  @PostMapping(path = "/update-notification")
  public void updateNofication(@RequestHeader(name = "RAE_ACCESS_TOKEN") String raeToken,
                       @RequestHeader(name = "DEVICE_ID") String deviceId,@RequestParam(name="notificationEnable") boolean notificaitonEnable) {

    String easyId = easyIdService.getEasyId(raeToken);

    LOG.info("Received request for updating notification settings");

    omatomeService.updateNotificationSettings(easyId, deviceId, notificaitonEnable);

    LOG.info("Processed request for updating notification settings");
  }
  
  @ApiOperation(value = "Get My Menu", response = MyMenuResponse.class)
  @ApiResponses(value = {@ApiResponse(code = 200, message = "successfully fetched my menu details "),
    @ApiResponse(code = 400, message = "Bad Request Error"),
    @ApiResponse(code = 401, message = "You are unauthorized to access the requested resource. Please log in."),
    @ApiResponse(code = 403, message = "Your account is not authorized to access the requested resource.")})
  @GetMapping(path = "/myMenu")
  @ResponseBody
  public ResponseEntity<MyMenuResponse> myMenu(@RequestHeader(name = "RAE_ACCESS_TOKEN") String raeToken,
		  					@RequestHeader(name = "DEVICE_ID") String deviceId) {

	String easyId = easyIdService.getEasyId(raeToken);

    LOG.info("Received request for My Menu");

    MyMenuResponse myMenuResponse = omatomeService.getMyMenu(easyId,deviceId);

    LOG.info("Processed request for My Menu");
    return ResponseEntity.ok(myMenuResponse);
  }
  
}
