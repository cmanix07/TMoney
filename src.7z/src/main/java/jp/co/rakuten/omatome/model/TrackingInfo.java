package jp.co.rakuten.omatome.model;

import java.util.List;

public class TrackingInfo {
  private String trackingNumber;
  private String requestType;
  private Integer point;
  private List<String> items;
  private String changeRequestId;

  public TrackingInfo() {
  }

  public TrackingInfo(String trackingNumber, String requestType, Integer point, List<String> items,String changeRequestId) {
    this.trackingNumber = trackingNumber;
    this.requestType = requestType;
    this.point = point;
    this.items = items;
    this.changeRequestId = changeRequestId;
  }

  public String getTrackingNumber() {
    return trackingNumber;
  }

  public String getRequestType() {
    return requestType;
  }

  public Integer getPoint() {
    return point;
  }

  public List<String> getItems() {
    return items;
  }

public String getChangeRequestId() {
	return changeRequestId;
}

@Override
public int hashCode() {
  final int prime = 31;
  int result = 1;
  result = prime * result + ((changeRequestId == null) ? 0 : changeRequestId.hashCode());
  result = prime * result + ((items == null) ? 0 : items.hashCode());
  result = prime * result + ((point == null) ? 0 : point.hashCode());
  result = prime * result + ((requestType == null) ? 0 : requestType.hashCode());
  result = prime * result + ((trackingNumber == null) ? 0 : trackingNumber.hashCode());
  return result;
}

@Override
public boolean equals(Object obj) {
  if (this == obj)
    return true;
  if (obj == null)
    return false;
  if (getClass() != obj.getClass())
    return false;
  TrackingInfo other = (TrackingInfo) obj;
  if (changeRequestId == null) {
    if (other.changeRequestId != null)
      return false;
  } else if (!changeRequestId.equals(other.changeRequestId))
    return false;
  if (items == null) {
    if (other.items != null)
      return false;
  } else if (!items.equals(other.items))
    return false;
  if (point == null) {
    if (other.point != null)
      return false;
  } else if (!point.equals(other.point))
    return false;
  if (requestType == null) {
    if (other.requestType != null)
      return false;
  } else if (!requestType.equals(other.requestType))
    return false;
  if (trackingNumber == null) {
    if (other.trackingNumber != null)
      return false;
  } else if (!trackingNumber.equals(other.trackingNumber))
    return false;
  return true;
}
  

  
}
