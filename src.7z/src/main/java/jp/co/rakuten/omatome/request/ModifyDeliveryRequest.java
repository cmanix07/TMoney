package jp.co.rakuten.omatome.request;

import jp.co.rakuten.omatome.model.TrackingInfo;

import java.util.List;

public class ModifyDeliveryRequest {
  private List<TrackingInfo> trackingInfoList;
  private String deliveryDate;
  private String timeSlotCode;
  private String companyNumber;
  private boolean ecoFlag;

  public ModifyDeliveryRequest() {
  }

  public ModifyDeliveryRequest(List<TrackingInfo> trackingInfoList,
      String deliveryDate,
      String timeSlotCode,
      String companyNumber,
      boolean ecoFlag) {

    this.trackingInfoList = trackingInfoList;
    this.deliveryDate = deliveryDate;
    this.timeSlotCode = timeSlotCode;
    this.companyNumber = companyNumber;
    this.ecoFlag = ecoFlag;

  }

  public String getDeliveryDate() {
    return deliveryDate;
  }

  public String getTimeSlotCode() {
    return timeSlotCode;
  }


  public String getCompanyNumber() {
    return companyNumber;
  }

  public List<TrackingInfo> getTrackingInfoList() {
    return trackingInfoList;
  }

  public boolean isEcoFlag() {
    return ecoFlag;
  }
}
