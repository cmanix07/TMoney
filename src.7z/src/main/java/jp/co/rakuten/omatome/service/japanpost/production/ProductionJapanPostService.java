package jp.co.rakuten.omatome.service.japanpost.production;

import com.gargoylesoftware.htmlunit.ElementNotFoundException;
import com.gargoylesoftware.htmlunit.WebClient;
import com.gargoylesoftware.htmlunit.html.*;
import com.google.common.collect.Sets;
import jp.co.rakuten.omatome.exception.JapanPostProcessingException;
import jp.co.rakuten.omatome.model.TrackingInfo;
import jp.co.rakuten.omatome.service.japanpost.JapanPostService;
import jp.co.rakuten.omatome.utils.ThreadSafeWebClientGenerator;
import org.apache.logging.log4j.util.Strings;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.CollectionUtils;
import org.w3c.dom.NamedNodeMap;

import java.io.IOException;
import java.util.*;
import java.util.stream.Collectors;

import static jp.co.rakuten.omatome.utils.OmatomeConstants.DATE_CHANGE_REQUEST;
import static jp.co.rakuten.omatome.utils.OmatomeConstants.REDELIVERY_REQUEST;

public class ProductionJapanPostService implements JapanPostService {
  public static final String DELI_FIRST_DELIVERY_INPUT_ACTION_FORM = "deli_firstDeliveryInputActionForm";
  public static final String DELI_DELIVERY_RECEIPT_ACTION_FORM = "deli_deliveryReceiptActionForm";
  public static final String TRACKING_NUMBER_INPUT = "firstDeliveryInputTrackNo";
  public static final String RECEIVE_PLACE_PAGE_SUBMIT_BUTTON_DATE_CHANGE = "dateChangeSubmit";
  public static final String RECEIVE_PLACE_PAGE_SUBMIT_BUTTON_REDELIVERY = "receriptSubmit";
  public static final String TRACKING_NUMBER_SUBMIT_BUTTON = "submit";
  public static final String RECEIVE_PLACE_SELECTION_RADIO_INPUT = "directionType";
  public static final String AVAILABLE_DATES_TABLE_XPATH = "//*[@id=\"con_no_rnav\"]/table";
  public static final int JAVASCRIPT_LOAD_TIMEOUT_MILLIS = 1000;
  public static final String DELIVERY_DETAIL_FORM = "deli_deliveryDetailHomeActionForm";
  public static final String DELIVERY_CONFIRM_FORM = "deli_deliveryConfirmActionForm";
  private static final Logger LOG = LoggerFactory.getLogger(ProductionJapanPostService.class);
  private final ThreadSafeWebClientGenerator threadSafeWebClientGenerator;
  private final String url;

  public ProductionJapanPostService(String url, ThreadSafeWebClientGenerator threadSafeWebClientGenerator) {
    this.url = url;
    this.threadSafeWebClientGenerator = threadSafeWebClientGenerator;
  }

  @Override
  public Map<String, Set<String>> getCommonAvailableDates(List<TrackingInfo> trackingInfoList) {
    if (CollectionUtils.isEmpty(trackingInfoList)) {
      return new LinkedHashMap<String, Set<String>>();
    }

    List<LinkedHashMap<String, LinkedHashSet<String>>> collect = getAvailableDatesForEachTrackingNumber(trackingInfoList);
    return getCommonDateAndTimeSlot(collect);
  }

  @Override
  public Map<String, List<TrackingInfo>> updateDelivery(List<TrackingInfo> trackingInfoList,
                                                        String date,
                                                        String timeSlotCode,
                                                        String phoneNumber) {
    HashMap<String, List<TrackingInfo>> result = new HashMap<>();
    result.put("SUCCESS", new ArrayList<>());
    result.put("FAILURE", new ArrayList<>());

    trackingInfoList.forEach(trackingInfo -> {
      try (WebClient webClient = threadSafeWebClientGenerator.generate()) {

        HtmlPage page = getAvailableDatesPage(trackingInfo.getRequestType(), trackingInfo.getTrackingNumber(), webClient);

        page = getChangeConfirmationPage(date, timeSlotCode, phoneNumber, webClient, page);

        submitConfirmationPage(webClient, page);

        //TODO: need tracking number to test after submitting confirmation
        result.get("SUCCESS").add(trackingInfo);

      } catch (Exception e) {
        LOG.error("Failed to change delivery date for trackingNumber = {} and requestType = {}",
          trackingInfo.getTrackingNumber(), trackingInfo.getRequestType(), e);
        result.get("FAILURE").add(trackingInfo);
      }

    });
    return result;
  }

  private void submitConfirmationPage(WebClient webClient, HtmlPage page) throws IOException {
    HtmlForm deli_deliveryConfirmActionForm = page.getFormByName(DELIVERY_CONFIRM_FORM);
    deli_deliveryConfirmActionForm.getInputByName("submit").click();

    webClient.waitForBackgroundJavaScript(JAVASCRIPT_LOAD_TIMEOUT_MILLIS);
  }

  private HtmlPage getChangeConfirmationPage(String date, String timeSlotCode, String phoneNumber, WebClient webClient, HtmlPage page) throws IOException {

    HtmlForm form = page.getFormByName(DELIVERY_DETAIL_FORM);

    selectDateAndTime(date, timeSlotCode, form);
    inputContactNumber(phoneNumber, form);

    page = form.getInputByName("submit").click();

    webClient.waitForBackgroundJavaScript(JAVASCRIPT_LOAD_TIMEOUT_MILLIS);
    return page;
  }

  private void inputContactNumber(String phoneNumber, HtmlForm form) throws IOException {
    HtmlInput clientTelNoArea = form.getInputByName("clientTelNoArea");
    clientTelNoArea.type(phoneNumber.substring(0, 3));

    HtmlInput clientTelNoCityExchange = form.getInputByName("clientTelNoCityExchange");
    clientTelNoCityExchange.type(phoneNumber.substring(3, 7));

    HtmlInput clientTelNoMember = form.getInputByName("clientTelNoMember");
    clientTelNoMember.type(phoneNumber.substring(7));
  }

  private void selectDateAndTime(String date, String timeSlotCode, HtmlForm form) throws IOException {
    form.getInputByValue(date + "," + timeSlotCode).click();
  }

  private HtmlPage getPageForAvailableDeliveryDates(String requestType, WebClient webClient, HtmlPage page) throws IOException {
    HtmlForm form;

    form = page.getFormByName(DELI_DELIVERY_RECEIPT_ACTION_FORM);
    List<HtmlRadioButtonInput> directionType = form.getRadioButtonsByName(RECEIVE_PLACE_SELECTION_RADIO_INPUT);
    directionType.get(0).click();


    if (REDELIVERY_REQUEST.equals(requestType)) {
      LOG.info("getting available delivery dates page for redelivery");
      HtmlInput reDelivery = form.getInputByName(RECEIVE_PLACE_PAGE_SUBMIT_BUTTON_REDELIVERY);
      page = reDelivery.click();
    }
    if (DATE_CHANGE_REQUEST.equals(requestType)) {
      LOG.info("getting available delivery dates page for date change");
      HtmlInput dateChange = form.getInputByName(RECEIVE_PLACE_PAGE_SUBMIT_BUTTON_DATE_CHANGE);
      page = dateChange.click();
    }

    webClient.waitForBackgroundJavaScript(JAVASCRIPT_LOAD_TIMEOUT_MILLIS);
    return page;
  }

  private HtmlPage getPageForDeliveryPlaceChange(WebClient webClient, String trackingNumber) throws IOException {
    HtmlPage page;
    page = webClient
      .getPage(url);
    webClient.waitForBackgroundJavaScript(JAVASCRIPT_LOAD_TIMEOUT_MILLIS);

    HtmlForm form = page.getFormByName(DELI_FIRST_DELIVERY_INPUT_ACTION_FORM);
    HtmlInput trackingNumberInput = form.getInputByName(TRACKING_NUMBER_INPUT);
    trackingNumberInput.type(trackingNumber);
    HtmlInput input = form.getInputByName(TRACKING_NUMBER_SUBMIT_BUTTON);

    page = input.click();
    webClient.waitForBackgroundJavaScript(JAVASCRIPT_LOAD_TIMEOUT_MILLIS);
    return page;
  }

  private List<LinkedHashMap<String, LinkedHashSet<String>>> getAvailableDatesForEachTrackingNumber(List<TrackingInfo> trackingInfoList) {

    return trackingInfoList.stream().map(trackingInfo -> {
      WebClient webClient = threadSafeWebClientGenerator.generate();
      LinkedHashMap<String, LinkedHashSet<String>> availableDates;
      LOG.info("getting available delivery dates for {} with request type = {}",
        trackingInfo.getTrackingNumber(), trackingInfo.getRequestType());
      try {

        HtmlPage page = getAvailableDatesPage(trackingInfo.getRequestType(), trackingInfo.getTrackingNumber(), webClient);

        availableDates = extractAvailableDates(page);

      } catch (RuntimeException | IOException e) {
        LOG.error("Failed to get available delivery dates from JapanPost, errorMessage ={}", e.getMessage(), e);
        throw new JapanPostProcessingException("Failed to get available delivery dates from JapanPost");
      } finally {
        webClient.close();
      }

      return availableDates;
    }).collect(Collectors.toList());
  }

  private HtmlPage getAvailableDatesPage(String requestType, String trackingNumber, WebClient webClient) throws IOException {
    HtmlPage page;

    page = getPageForDeliveryPlaceChange(webClient, trackingNumber);

    if (unsupportedTrackingNumber(page)) {
      throw new JapanPostProcessingException(String.format("Change not allowed for tracking number = %s", trackingNumber));
    }

    page = getPageForAvailableDeliveryDates(requestType, webClient, page);
    return page;
  }

  private boolean unsupportedTrackingNumber(HtmlPage page) {
    try {
      //if after submitting tracking number the response is same page
      page.getFormByName(DELI_FIRST_DELIVERY_INPUT_ACTION_FORM);
      return true;
    } catch (ElementNotFoundException e) {
      // Ignore
    }
    return false;
  }

  private LinkedHashMap<String, Set<String>> getCommonDateAndTimeSlot(List<LinkedHashMap<String, LinkedHashSet<String>>> collect) {
    LinkedHashMap<String, Set<String>> commonDateAndTimeSlots = new LinkedHashMap<>();
    Set<String> commonDates = collect.get(0).keySet();

    for (int i = 1; i < collect.size(); i++) {
      commonDates = Sets.intersection(collect.get(i).keySet(), commonDates);
    }

    for (String date : commonDates) {
      Set<String> commonTimeSlots = collect.get(0).get(date);
      for (int i = 1; i < collect.size(); i++) {
        commonTimeSlots = Sets.intersection(collect.get(i).get(date), commonTimeSlots);
      }

      commonDateAndTimeSlots.put(date, commonTimeSlots);
    }

    return commonDateAndTimeSlots;
  }

  private LinkedHashMap<String, LinkedHashSet<String>> extractAvailableDates(HtmlPage page) {
    final HtmlTable table = (HtmlTable) page.getByXPath(AVAILABLE_DATES_TABLE_XPATH).get(0);

    LinkedHashMap<String, LinkedHashSet<String>> availableDateAndTimes = new LinkedHashMap<>();

    List<HtmlTableRow> tableRows = table.getRows();

    //skip the header rows
    for (int i = 2; i < tableRows.size(); i++) {
      HtmlTableRow row = tableRows.get(i);

      LinkedHashSet<String> timeSlots = new LinkedHashSet<>();

      List<HtmlTableCell> cells = row.getCells();

      String date = null;

      // time slot list starts from column 1
      for (int j = 1; j < cells.size(); j++) {
        NamedNodeMap attributes = cells.get(j).getFirstChild().getAttributes();
        if (attributes.getLength() != 0) {
          //value attribute contains "date,timeslot"
          String[] values = attributes.getNamedItem("value").getTextContent().split(",");
          if (Strings.isEmpty(date)) {
            date = values[0];
          }
          timeSlots.add(values[1]);
        }
      }

      availableDateAndTimes.put(date, timeSlots);
    }

    return availableDateAndTimes;
  }

}

