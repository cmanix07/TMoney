package jp.co.rakuten.omatome.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import jp.co.rakuten.omatome.entity.DeliveryChangeEntity;
import jp.co.rakuten.omatome.entity.id.DeliveryChangeEntityId;

@Repository
public interface DeliveryChangeRepository extends JpaRepository<DeliveryChangeEntity, DeliveryChangeEntityId> {
	
	List<DeliveryChangeEntity> findByDeliveryChangeId(String deliveryChangeId);
}
