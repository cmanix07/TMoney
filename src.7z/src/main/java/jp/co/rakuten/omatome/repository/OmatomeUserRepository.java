package jp.co.rakuten.omatome.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import jp.co.rakuten.omatome.entity.OmatomeUserEntity;
import jp.co.rakuten.omatome.entity.OmatomeUserEntityId;

@Repository
public interface OmatomeUserRepository extends JpaRepository<OmatomeUserEntity,OmatomeUserEntityId>  {


}
