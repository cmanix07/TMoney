package jp.co.rakuten.omatome.security;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import io.jsonwebtoken.security.Keys;
import jp.co.rakuten.omatome.exception.OmatomeException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

import javax.servlet.FilterChain;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;


public class JwtAuthenticationFilter extends UsernamePasswordAuthenticationFilter {
  public static final String TOKEN_HEADER = "Authorization";
  static final String TOKEN_PREFIX = "Bearer ";
  private static final String AUTH_LOGIN_URL = "/accesstoken";
  private static final String TOKEN_TYPE = "JWT";
  private static final String TOKEN_ISSUER = "secure-api";
  private static final String TOKEN_AUDIENCE = "secure-app";

  private static final Logger log = LoggerFactory.getLogger(JwtAuthenticationFilter.class);

  private final AuthenticationManager authenticationManager;
  private long expiration;

  private String jwtSecret;

  public JwtAuthenticationFilter(AuthenticationManager authenticationManager, long expiration, String jwtSecret) {
    this.authenticationManager = authenticationManager;
    setFilterProcessesUrl(AUTH_LOGIN_URL);
    this.expiration = expiration;
    this.jwtSecret = jwtSecret;
  }

  @Override
  public Authentication attemptAuthentication(HttpServletRequest request,
                                              HttpServletResponse response) throws AuthenticationException {


    if (!"POST".equalsIgnoreCase(request.getMethod())) {
      throw new OmatomeException("[Omatome API] This method type is not currently supported.", HttpStatus.METHOD_NOT_ALLOWED);
    }
    String data;
    try {
      data = request.getReader().lines().collect(Collectors.joining(System.lineSeparator()));

      ObjectMapper mapper = new ObjectMapper();
      JsonNode requestObj = mapper.readTree(data);
      String username = requestObj.get("username").toString().replace("\"", "");
      String password = requestObj.get("password").toString().replace("\"", "");


      UsernamePasswordAuthenticationToken authenticationToken = new UsernamePasswordAuthenticationToken(username, password);

      return authenticationManager.authenticate(authenticationToken);
    } catch (IOException e) {
      log.warn("Request to AuthenticationToken failed : {}", e);
    }
    return null;
  }

  @Override
  protected void successfulAuthentication(HttpServletRequest request, HttpServletResponse response,
                                          FilterChain filterChain, Authentication authentication) {
    User user = ((User) authentication.getPrincipal());

    List<String> roles = user.getAuthorities()
      .stream()
      .map(GrantedAuthority::getAuthority)
      .collect(Collectors.toList());

    byte[] signingKey = jwtSecret.getBytes();

    String token = Jwts.builder()
      .signWith(Keys.hmacShaKeyFor(signingKey), SignatureAlgorithm.HS512)
      .setHeaderParam("typ", TOKEN_TYPE)
      .setIssuer(TOKEN_ISSUER)
      .setAudience(TOKEN_AUDIENCE)
      .setSubject(user.getUsername())
      .setExpiration(new Date(System.currentTimeMillis() + expiration))
      .claim("rol", roles)
      .compact();

    response.addHeader(TOKEN_HEADER, TOKEN_PREFIX + token);
  }
}
