package jp.co.rakuten.omatome.repository;


import java.time.LocalDate;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import jp.co.rakuten.omatome.entity.PointAllocationHistoryEntity;

@Repository
public interface PointAllocationHistoryRepository  extends JpaRepository<PointAllocationHistoryEntity,String> {

	@Query(value = "select pah.* from POINT_ALLOCATION_HISTORY pah where pah.EASY_ID =:easyId and pah.CREATE_TIMESTAMP >=:fromDate and pah.POINT_ALLOCATED_FLAG = 1",nativeQuery = true)
	public List<PointAllocationHistoryEntity> findByEasyId(@Param("easyId")Long easyId, @Param("fromDate")LocalDate fromDate); 
	
}