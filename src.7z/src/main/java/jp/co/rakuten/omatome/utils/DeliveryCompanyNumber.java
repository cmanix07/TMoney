package jp.co.rakuten.omatome.utils;

import java.util.Arrays;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

public enum DeliveryCompanyNumber {
	/**
	 * ヤマト運輸
	 */
	YAMATO_TRANSPORT("1001","ヤマト運輸", "^\\d{12}$"),

	/**
	 * 佐川急便
	 */
	SAGAWA_EXPRESS("1002", "佐川急便","^(\\d{12}|\\d{10})$"),

	/**
	 * 日本郵便
	 */
	JAPAN_POST("1003","日本郵便", "^\\d{11,12}$"),

	/**
	 * 楽天Express
	 */
	RAKUTEN_EXPRESS("1028", "Rakuten EXPRESS","^\\d{12}$"),

	/**
	 * 西濃運輸
	 */
	SEINO("1004","西濃運輸", "^\\d{10}$"),

	/**
	 * 西部運輸  changed to セイノースーパーエクスプレス (Seino Super Express Co Ltd )  https://www.bloomberg.com/profile/company/SBUNYZ:JP
	 * （伝票番号は10桁、13桁、または15桁の数字で入力してください。）
	 */
	SEIBU_TRANSPORT("1005", "セイノースーパーエクスプレス", "^\\d+$"),

	/**
	 * 福山通運
	 */
	FUKUYAMA_TRANSPORT("1006","福山通運", "^\\d{10,11}$"),

	/**
	 * 名鉄運輸
	 */
	MEITETSU_TRANSPORTATION("1007", "名鉄運輸","^\\d+$"),


	/**
	 * トナミ運輸
	 */
	TONAMI("1008", "トナミ運輸", "^\\d+$"),


	/**
	 * 第一貨物
	 */
	DAIICHI_KAMOTSU("1009","第一貨物",  "^\\d+$"),


	/**
	 * 新潟運輸
	 */
	NIIGATA_UNYU("1010", "新潟運輸","^\\d+$"),


	/**
	 * 中越運送
	 */
	CHUETSU("1011","中越運送", "^\\d+$"),


	/**
	 * 岡山県貨物運送
	 */
	OKAYAMAKEN_FREIGHT_TRANSPORT("1012","岡山県貨物運送", "^\\d+$"),


	/**
	 * 久留米運送
	 */
	KURUME_UNSOU("1013", "久留米運送", "^\\d+$"),


	/**
	 * 山陽自動車運送
	 */
	SANYO_JIDOSHA_UNSOU("1014","山陽自動車運送", "^\\d+$"),


	/**
	 * 日本トラック
	 */
	NIHON_TRUCK("1015", "日本トラック", "^\\d+$"),

	/**
	 * EMS
	 */
	JAPAN_POST_EMS("1017", "EMS", "^[ECRecr][A-Za-z]\\d{9}[Jj][Pp]$"),


	DHL("1018", "DHL","^\\d+$"),

	FEDEX("1019", "FedEx", "^\\d+$"),

	UPS("1020", "UPS",  "^\\d+$"),

	NIPPON_EXPRESS("1021","日通通運",  "^\\d+$"),

	TNT("1022", "TNT","^\\d+$"),

	OVERSEA_COURIER_SERVICE("1023", "OCS", "^\\d+$"),

	USPS("1024", "USPS",  "^\\d+$"),

	SF_Express("1025","SFエクスプレス",  "^\\d+$"),

	ARAMEX("1026", "Aramex", "^\\d+$"),

	SAGAWA_GLOBAL("1027", "SGHグローバル", "^(\\d{12}|\\d{10})$"),

	/**
	 * その他
	 */
	OTHERS("1000", "その他",  "^\\d+$")


	;

    private static Map<String, DeliveryCompanyNumber> reverseLookup =
	        Arrays.stream(DeliveryCompanyNumber.values()).collect(Collectors.toMap(DeliveryCompanyNumber::getId, Function.identity()));

	/**
	 * 配送会社コード
	 */
	private final String id;
	private String trackingNumberPattern;
	private String carrierName;

	/**
	 * コンストラクタ(初期値有)
	 * @param id 配送会社コード
	 * @param trackingNumberPattern
	 */
	private DeliveryCompanyNumber(String id, String carrierName, String trackingNumberPattern) {
		this.id = id;
		this.carrierName = carrierName;
		this.trackingNumberPattern = trackingNumberPattern;
	}

	/**
	 * 配送会社コード取得
	 * @return 配送会社コード
	 */
    public String getId() {
        return this.id;
    }

	public String getTrackingNumberPattern() {
		return trackingNumberPattern;
	}

	public static DeliveryCompanyNumber getDeliveryCompanyNumber(final String id) {
		return reverseLookup.get(id);
	}
}
