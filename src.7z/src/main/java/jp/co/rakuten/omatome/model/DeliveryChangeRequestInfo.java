package jp.co.rakuten.omatome.model;

import java.time.LocalDate;
import java.time.LocalDateTime;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class DeliveryChangeRequestInfo {

	private String trackingNumber;

	private String companyNumber;
	
	private String changeRequestId;
	
	private LocalDate deliveryDate;
	
	private String deliveryTime;
	
	private Integer deliveryStatus;

    private String requestOkihaiPlace1;
    
    private String requestOkihaiPlace2;
    
    private String okihaiRemarks;
    
    private Integer omatomeFlag;
    
    private Integer points;
    
    private LocalDateTime changeTimestamp;
    

    public DeliveryChangeRequestInfo(String trackingNumber, String companyNumber, String changeRequestId,
			LocalDate deliveryDate, String deliveryTime, Integer deliveryStatus, String requestOkihaiPlace1,
			String requestOkihaiPlace2, String okihaiRemarks, Integer omatomeFlag, Integer points, 
			LocalDateTime changeTimestamp) {

		this.trackingNumber = trackingNumber;
		this.companyNumber = companyNumber;
		this.changeRequestId = changeRequestId;
		
		this.deliveryDate = deliveryDate;
		this.deliveryTime = deliveryTime;
		this.deliveryStatus = deliveryStatus;
		
		this.requestOkihaiPlace1 = requestOkihaiPlace1;
		this.requestOkihaiPlace2 = requestOkihaiPlace2;
		this.okihaiRemarks = okihaiRemarks;
		this.omatomeFlag = omatomeFlag;
		
		this.points = points;
		
		this.changeTimestamp = changeTimestamp;
    }
}
