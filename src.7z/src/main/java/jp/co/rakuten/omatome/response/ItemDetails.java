package jp.co.rakuten.omatome.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import lombok.Data;


@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "itemId", "itemName", "basketId" })
public class ItemDetails {

	@JsonProperty("itemId")
	private Long itemId;
	
	@JsonProperty("itemName")
	private String itemName;
	
	@JsonProperty("basketId")
	private Long basketId;
	
}
