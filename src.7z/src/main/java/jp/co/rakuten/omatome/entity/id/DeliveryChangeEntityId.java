package jp.co.rakuten.omatome.entity.id;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import java.io.Serializable;

@Embeddable
public class DeliveryChangeEntityId implements Serializable {
  @Column(name = "DELIVERY_COMPANY_NUMBER")
  private String companyNumber;

  @Column(name = "TRACKING_NUMBER")
  private String trackingNumber;

  public DeliveryChangeEntityId() {
  }

  public DeliveryChangeEntityId(String companyNumber, String trackingNumber) {
    this.companyNumber = companyNumber;
    this.trackingNumber = trackingNumber;
  }

  public String getCompanyNumber() {
    return companyNumber;
  }

  public String getTrackingNumber() {
    return trackingNumber;
  }

  @Override
  public int hashCode() {
	final int prime = 31;
	int result = 1;
	result = prime * result + ((companyNumber == null) ? 0 : companyNumber.hashCode());
	result = prime * result + ((trackingNumber == null) ? 0 : trackingNumber.hashCode());
	return result;
  }
	
  @Override
  public boolean equals(Object obj) {
	if (this == obj)
		return true;
	if (obj == null)
		return false;
	if (getClass() != obj.getClass())
		return false;
	DeliveryChangeEntityId other = (DeliveryChangeEntityId) obj;
	if (companyNumber == null) {
		if (other.companyNumber != null)
			return false;
		} else if (!companyNumber.equals(other.companyNumber))
			return false;
	if (trackingNumber == null) {
		if (other.trackingNumber != null)
			return false;
		} else if (!trackingNumber.equals(other.trackingNumber))
			return false;
		return true;
  }

	
	  
  
}
