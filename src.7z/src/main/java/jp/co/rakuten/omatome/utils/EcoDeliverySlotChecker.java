package jp.co.rakuten.omatome.utils;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class EcoDeliverySlotChecker {
  private static Map<String, List<String>> JPEcoDayAndTimeSlotMap;
  private static Map<String, List<String>> RExpressEcoDayAndTimeSlotMap;

  public EcoDeliverySlotChecker(List<String> japanPostEcoDays,
                                List<String> jpEcoTimeSlots,
                                List<String> rExpressEcoDays,
                                List<String> rExpressEcoTimeSlots) {

    JPEcoDayAndTimeSlotMap = new HashMap<>();
    japanPostEcoDays.forEach(x -> JPEcoDayAndTimeSlotMap.put(x, jpEcoTimeSlots));

    RExpressEcoDayAndTimeSlotMap = new HashMap<>();
    rExpressEcoDays.forEach(x -> RExpressEcoDayAndTimeSlotMap.put(x, rExpressEcoTimeSlots));
  }

  public boolean isEligible(String date, String timeSlot, String companyNumber) {
    String dayOfWeek = LocalDate.parse(date, DateTimeFormatter.ofPattern("yyyyMMdd")).getDayOfWeek().name();

    if (companyNumber.equals("1003") && JPEcoDayAndTimeSlotMap.containsKey(dayOfWeek)) {
      return JPEcoDayAndTimeSlotMap.get(dayOfWeek).contains(timeSlot);
    }

    if (companyNumber.equals("1028") && RExpressEcoDayAndTimeSlotMap.containsKey(dayOfWeek)) {
      return RExpressEcoDayAndTimeSlotMap.get(dayOfWeek).contains(timeSlot);
    }

    return false;
  }
}
