package jp.co.rakuten.omatome.entity;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@Entity
@Table(name = "POINT_ALLOCATION_HISTORY")
public class PointAllocationHistoryEntity {

	@Id
	@Column(name = "CHANGE_REQUEST_ID")
    private String changeRequestId;

	@Column(name = "TRACKING_NUMBER")
    private String trackingNumber;
	
	@Column(name = "POINT_NOT_ALLOCATED_TRACKING_NUMBER")
    private String pointNotAllocatedTrackingNumber;
	
	@Column(name = "COMPANY_NUMBER")
    private String companyNumber;
	
	@Column(name = "POINT")
	private Integer point;
	
	@Column(name = "EASY_ID")
	private Long easyId;
	
	@Column(name = "ANNOTATION_FLAG")
	private Integer annotationFlag;
	
	@Column(name = "POINT_ALLOCATED_FLAG")
	private Integer pointAllocatedFlag;
	
	@Column(name = "CREATE_TIMESTAMP")
	private LocalDateTime createTimestamp;
	
	@Column(name = "CHANGE_TIMESTAMP")
	private LocalDateTime changeTimestamp;
	
}