package jp.co.rakuten.omatome.utils;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;
import java.util.Optional;

import org.apache.commons.lang3.StringUtils;

import jp.co.rakuten.omatome.entity.DeliveryChangeEntity;

public class Demo {
  Boolean flagTest = Boolean.FALSE;
    public void m1() {
     
      m2(10,flagTest);
      System.out.println("flagTest: "+flagTest);
    }
      public void m2(int val, Boolean flagTest) {
        System.out.println("Value of val: "+val+ " flagTest: "+flagTest);
        
        if(val == 10) {
          flagTest = Boolean.TRUE;
        }
      }
    	
	public static String formatDate(LocalDateTime DateTime, String pattern) {
		  DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern(pattern);
		  return dateFormatter.format(DateTime);

	  }
	
	public Optional<DeliveryChangeEntity> fetchAvailableOmatomeCombineRequest(String deliveryChangeId) {
		Optional<DeliveryChangeEntity> existingDeliveryChangeEntity = Optional.ofNullable(new DeliveryChangeEntity());
		//if (null != deliveryChangeId)
		//	existingDeliveryChangeEntity = deliveryChangeRepository.findFirstByDeliveryChangeId(deliveryChangeId);
		return existingDeliveryChangeEntity;
	}

	public static void main(String[] args) {
		new Demo().m1();
		
		List<String> strings = new LinkedList<>();
		//strings.add("Java");
		//strings.add("is");
		//strings.add("cool");
		System.out.println(strings);
		String message = String.join(",", strings);
		System.out.println("message list: "+message);
		StringUtils.join(strings,",");
		System.out.println("'"+StringUtils.join(strings,"','")+"'");
		System.out.println(org.springframework.util.StringUtils.collectionToDelimitedString(strings, ","));
		
		System.out.println("================================================================================");
		
		List<List<String>> outerList = new ArrayList<>();
		
		@SuppressWarnings("serial")
                List<String> innerList1 = new ArrayList<String>() {{
		  add("1");
		  add("1");
		  add("1");
		  add("1");
		  add("1");
		}};
		
		List<String> innerList2 = Arrays.asList("123","456","ABC","6789");
		List<String> innerList3 = Arrays.asList("abc","abc","abc","abc");
		List<String> innerList4 = Arrays.asList("1","1","1","1");
		List<String> innerList5 = Arrays.asList("2","2","2","2");
		
		outerList.add(innerList1);
		outerList.add(innerList2);
		outerList.add(innerList3);
		outerList.add(innerList4);
		outerList.add(innerList5);
		boolean flag = false;
		outerList.forEach(list -> {
		  System.out.println("Value of list: "+list);
		  list.stream().allMatch(val -> {
		    System.out.println(" "+val);
		    return !val.equals("1");
		  });
		  System.out.println("List is: after return : "+list);
		});

	}

}

