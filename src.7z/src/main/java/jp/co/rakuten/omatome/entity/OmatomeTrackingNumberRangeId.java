package jp.co.rakuten.omatome.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@Embeddable
public class OmatomeTrackingNumberRangeId implements Serializable {

	@Column(name = "RANGE_TYPE")
	private String rangeType;

	@Column(name = "TRACKING_NUMBER_BEGIN")
	private Long trackingNumberBegin;
	
	@Column(name = "TRACKING_NUMBER_END")
	private Long trackingNumberEnd;

	@Column(name = "COMPANY_NUMBER")
	private String companyNumber;
}
