package jp.co.rakuten.omatome.exception;

import org.springframework.http.HttpStatus;


public class OmatomeException extends RuntimeException {

  private static final long serialVersionUID = -2984675157619561383L;

  private HttpStatus status;

  private String errorCode;

  private String errorMessage;

  public OmatomeException(String errorMessage) {
    super(errorMessage);
  }

  public OmatomeException(String errorMessage, HttpStatus status) {
    super(errorMessage);
    this.status = status;
  }

  public OmatomeException(HttpStatus status, String errorCode, String errorMessage) {
    super(errorMessage);
    this.status = status;
    this.errorCode = errorCode;
    this.errorMessage = errorMessage;
  }

  public OmatomeException(String message, Throwable cause) {
    super(message, cause);
  }

  public HttpStatus getStatus() {
    return status;
  }

  public String getErrorCode() {
    return errorCode;
  }

  public String getErrorMessage() {
    return errorMessage;
  }


}
