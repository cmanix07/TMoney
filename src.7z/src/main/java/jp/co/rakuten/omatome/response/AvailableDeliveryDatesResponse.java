package jp.co.rakuten.omatome.response;

import jp.co.rakuten.omatome.model.DateTimeSlot;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.stream.Collectors;

public class AvailableDeliveryDatesResponse {

  private final List<DateTimeSlot> availableDates;

  public AvailableDeliveryDatesResponse(List<DateTimeSlot> availableDates) {
    this.availableDates = availableDates;
  }

  public static AvailableDeliveryDatesResponse buildFrom(Map<String, List<TimeSlot>> availableDates) {
    List<DateTimeSlot> dateTimeSlots = availableDates
      .entrySet()
      .stream()
      .map(x -> {
        String jpFormatDate = LocalDate.parse(x.getKey(), DateTimeFormatter.ofPattern("yyyyMMdd"))
          .format(DateTimeFormatter.ofPattern("M月d日(E)", Locale.JAPAN));

        return new DateTimeSlot(x.getKey(), isEcoTimeSlotAvailableForDate(x), x.getValue());
      })
      .collect(Collectors.toList());
    return new AvailableDeliveryDatesResponse(dateTimeSlots);
  }

  private static boolean isEcoTimeSlotAvailableForDate(Map.Entry<String, List<TimeSlot>> x) {
    List<TimeSlot> ecoTimeSlots = x.getValue()
      .stream()
      .filter(TimeSlot::isEcoFlag)
      .collect(Collectors.toList());

    return ecoTimeSlots.size() >= 1;
  }

  public List<DateTimeSlot> getAvailableDates() {
    return availableDates;
  }
}
