package jp.co.rakuten.omatome.controller;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import jp.co.rakuten.omatome.request.LoginRequest;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * Authentication API specification for Swagger documentation and Code Generation.
 * Implemented by Spring Security.
 */
@Api("Authentication")
@RestController(value = "/")
@RequestMapping("/")
public class AccessTokenController {
  /**
   * Implemented by Spring Security
   */
  @ApiOperation(value = "Login", notes = "Login with the given credentials.")
  @ApiResponses({@ApiResponse(code = 200, message = "Login Success.Use the token from response header."),
    @ApiResponse(code = 401, message = "You are unauthorized to access the requested resource. Please log in."),
    @ApiResponse(code = 403, message = "Your account is not authorized to access the requested resource.")})
  @PostMapping(path = "accesstoken", consumes = {MediaType.APPLICATION_JSON_VALUE})
  public void login(
    @RequestBody LoginRequest loginRequest
  ) {
    throw new IllegalStateException("Add Spring Security to handle authentication");
  }

}