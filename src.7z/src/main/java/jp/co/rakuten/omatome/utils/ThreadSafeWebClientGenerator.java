package jp.co.rakuten.omatome.utils;

import com.gargoylesoftware.htmlunit.BrowserVersion;
import com.gargoylesoftware.htmlunit.WebClient;

public class ThreadSafeWebClientGenerator {
  public WebClient generate() {
    WebClient webClient = new WebClient(BrowserVersion.CHROME);

    webClient.getCookieManager().setCookiesEnabled(true);
    webClient.getOptions().setJavaScriptEnabled(true);
    webClient.getOptions().setTimeout(4000);

    webClient.getOptions().setUseInsecureSSL(true);
    // overcome problems in JavaScript
    webClient.getOptions().setThrowExceptionOnScriptError(false);
    webClient.getOptions().setPrintContentOnFailingStatusCode(false);

    webClient.getOptions().setDownloadImages(false);

    return webClient;
  }
}
