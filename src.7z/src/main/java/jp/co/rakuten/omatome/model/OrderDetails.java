package jp.co.rakuten.omatome.model;

import java.time.LocalDate;
import java.time.LocalDateTime;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class OrderDetails {
	
	private String orderNumber;
	
	private Integer oppFlag;

	private String companyNumber;
	
	private Long itemId;

	private String itemName;
	
	private Long basketId;
	
	private LocalDate wishDeliveryDate;
	
	private LocalDateTime orderDate;

	private String trackingNumber;
	
	private String shopName;
	
	private String deliveryName;
	
	public OrderDetails(String orderNumber, Integer oppFlag, 
			String originalNonOnePayTrackingNumber, String nonOnePaydeliveryCompanyNumber,
			String originalOnePayTrackingNumber, String onePaydeliveryCompanyNumber,
			Long itemId, String itemName, Long basketId, 
			LocalDate wishDeliveryDate, LocalDateTime orderDate, 
			String shopName, String deliveryName) {
		
		super();
		
		this.orderNumber = orderNumber;
		this.oppFlag = oppFlag;
		
		if(oppFlag == null) {
			this.trackingNumber = originalNonOnePayTrackingNumber;
			this.companyNumber = nonOnePaydeliveryCompanyNumber;
		} else {
			this.trackingNumber = originalOnePayTrackingNumber;
			this.companyNumber = onePaydeliveryCompanyNumber;
		}
		
		this.itemId = itemId;
		this.itemName = itemName;
		this.basketId = basketId;
		this.wishDeliveryDate = wishDeliveryDate;
		this.orderDate = orderDate;
		
		this.shopName = shopName;
		this.deliveryName = deliveryName;
	}
	
	
	
}
