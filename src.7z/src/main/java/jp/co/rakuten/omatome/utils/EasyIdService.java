package jp.co.rakuten.omatome.utils;

import jp.co.rakuten.omatome.exception.OmatomeException;
import jp.co.rakuten.omatome.response.rae.EasyIdResponse;
import jp.co.rakuten.omatome.response.rae.TokenResponse;
import org.apache.logging.log4j.util.Strings;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.http.*;
import org.springframework.stereotype.Component;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

@Component
public class EasyIdService {
  @Autowired
  private RestTemplate restTemplate;

  @Value("${rae.token.parser.baseUrl}")
  private String baseUrl;

  @Value("${rae.token.parser.clientId}")
  private String clientId;

  @Value("${rae.token.parser.clientSecret}")
  private String clientSecret;

  public EasyIdService() {
  }

  public EasyIdService(RestTemplate restTemplate, String baseUrl, String clientId, String clientSecret) {
    this.restTemplate = restTemplate;
    this.baseUrl = baseUrl;
    this.clientId = clientId;
    this.clientSecret = clientSecret;
  }

  @Cacheable(value = "Omatome_easyId", unless = "#result == null")
  public String getEasyId(String raeToken) {
    String easyId = "";
    ResponseEntity<TokenResponse> tokenResponseResponseEntity = getAccessToken();

    try {
      ResponseEntity<EasyIdResponse> easyIdResponseResponseEntity = getEasyId(raeToken, tokenResponseResponseEntity);
      easyId = easyIdResponseResponseEntity.getBody().getEasy_id();

      if (Strings.isBlank(easyId)) {
        throwError();
      }

    } catch (Exception e) {
      throwError();
    }

    return easyId;
  }

  private ResponseEntity<EasyIdResponse> getEasyId(String raeToken, ResponseEntity<TokenResponse> tokenResponseResponseEntity) {

    HttpHeaders headers = new HttpHeaders();
    headers.add("Content-Type", MediaType.APPLICATION_FORM_URLENCODED.toString());
    headers.add("Authorization", "OAuth2 " + tokenResponseResponseEntity.getBody().getAccess_token());

    MultiValueMap<String, String> params = new LinkedMultiValueMap<>();
    params.add("validate_token", raeToken);
    params.add("validate_scope", "pnp_common_sethistorystatus");

    HttpEntity<MultiValueMap<String, String>> entity = new HttpEntity<>(params, headers);

    return restTemplate
      .postForEntity(baseUrl + "/engine/api/Auth/AccessValidate/20170207", entity, EasyIdResponse.class);
  }

  private ResponseEntity<TokenResponse> getAccessToken() {
    HttpHeaders headers = new HttpHeaders();
    headers.add("Content-Type", MediaType.APPLICATION_FORM_URLENCODED.toString());

    MultiValueMap<String, String> params = new LinkedMultiValueMap<>();

    params.add("client_id", clientId);
    params.add("client_secret", clientSecret);
    params.add("scope", "rae_access_validate");
    params.add("grant_type", "client_credentials");

    HttpEntity<MultiValueMap<String, String>> entity = new HttpEntity<>(params, headers);


    return restTemplate
      .postForEntity(baseUrl + "/engine/token", entity, TokenResponse.class);
  }

  private void throwError() {
    throw new OmatomeException(HttpStatus.UNPROCESSABLE_ENTITY, "GE_002", "Cannot get easy id from raeToken");
  }
}

