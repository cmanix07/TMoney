package jp.co.rakuten.omatome.entity;

import java.time.LocalDate;
import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.Table;

import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import jp.co.rakuten.omatome.entity.id.DeliveryChangeEntityId;

@Entity
@EntityListeners(AuditingEntityListener.class)
@Table(name = "DELIVERY_CHANGE_REQUEST_INFO")
public class DeliveryChangeEntity {

  @EmbeddedId
  private DeliveryChangeEntityId id;

  @Column(name = "CHANGE_REQUEST_ID")
  private String deliveryChangeId;

  @Column(name = "DELIVERY_DATE")
  private LocalDate deliveryDate;

  @Column(name = "DELIVERY_TIME")
  private String timeSlot;

  @Column(name = "DELIVERY_TIME_SLOT_CODE")
  private String timeSlotCode;

  @Column(name = "ECO_FLAG")
  private boolean ecoFlag;

  @Column(name = "DELIVERY_STATUS")
  private String status;

  //redelivery or date_change
  @Column(name = "REQUEST_TYPE")
  private String requestType;

  @CreatedDate
  @Column(name = "CREATE_TIMESTAMP")
  private LocalDateTime createTimestamp;

  @LastModifiedDate
  @Column(name = "CHANGE_TIMESTAMP")
  private LocalDateTime changeTimestamp;

  public DeliveryChangeEntity() {
  }

  public DeliveryChangeEntity(DeliveryChangeEntityId id, String deliveryChangeId, LocalDate deliveryDate,
      String timeSlot, String timeSlotCode, boolean ecoFlag, String status, String requestType) {
    this.id = id;
    this.deliveryChangeId = deliveryChangeId;
    this.deliveryDate = deliveryDate;
    this.timeSlot = timeSlot;
    this.timeSlotCode = timeSlotCode;
    this.ecoFlag = ecoFlag;
    this.status = status;
    this.requestType = requestType;
  }

  public DeliveryChangeEntityId getId() {
    return id;
  }

  public LocalDate getDeliveryDate() {
    return deliveryDate;
  }

  public String getTimeSlot() {
    return timeSlot;
  }

  public String getStatus() {
    return status;
  }

  public boolean isEcoFlag() {
    return ecoFlag;
  }

  public String getTimeSlotCode() {
    return timeSlotCode;
  }

  public String getRequestType() {
    return requestType;
  }

  public String getDeliveryChangeId() {
    return deliveryChangeId;
  }

  public void setDeliveryChangeId(String deliveryChangeId) {
    this.deliveryChangeId = deliveryChangeId;
  }
  
}