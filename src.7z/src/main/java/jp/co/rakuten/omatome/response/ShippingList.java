package jp.co.rakuten.omatome.response;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import lombok.Data;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "changeRequestId","omatomeOrder","deliveryStatusDisplay","deliveryDateDisplay","deliveryTimeDisplay",
	"companyNumberDisplay","shopNameDisplay","itemNameDisplay","trackingNumberDisplay","points", "deliveryDateToday" 
	, "okihaiOrder", "requestOkihaiPlace1", "requestOkihaiPlace2", "okihaiRemarks","changeTypeDisplay","trackingNumberDetails" })
public class ShippingList {

	@JsonProperty("changeRequestId")
	private String changeRequestId;
	
	@JsonProperty("omatomeOrder")
	private boolean omatomeOrder;
	
	//Added the status here, Assuming all the tracking number status will be same for Omatome Orders
	//TO BE discussed Just for display details about the first tracking number
	@JsonProperty("deliveryStatusDisplay")
	private Integer deliveryStatusDisplay;

	@JsonProperty("deliveryDateDisplay")
	private String deliveryDateDisplay;

	@JsonProperty("deliveryTimeDisplay")
	private String deliveryTimeDisplay;
	
	@JsonProperty("companyNumberDisplay")
	private String companyNumberDisplay;

	@JsonProperty("shopNameDisplay")
	private String shopNameDisplay;
	
	//TO BE discussed, the first Item Name from the itemDetails List for the first trackingNumberDispaly 
	@JsonProperty("itemNameDisplay")
	private String itemNameDisplay;
	
	//TO BE discussed first tracking Number details list
	@JsonProperty("trackingNumberDisplay")
	private String trackingNumberDisplay;
	
	@JsonProperty("points")
	private int points;
	
	@JsonProperty("deliveryDateToday")
	private boolean deliveryDateToday;
	
	@JsonProperty("okihaiOrder")
	private boolean okihaiOrder;
	
	@JsonProperty("requestOkihaiPlace1")
	private String requestOkihaiPlace1;
	
	@JsonProperty("requestOkihaiPlace2")
	private String requestOkihaiPlace2;
	
	@JsonProperty("okihaiRemarks")
	private String okihaiRemarks;
	
	@JsonProperty("changeTypeDisplay")
	private String changeTypeDisplay;
	
	
	@JsonProperty("trackingNumberDetails")
	private List<TrackingNumberDetails> trackingNumberDetails;
	
	
	
}
