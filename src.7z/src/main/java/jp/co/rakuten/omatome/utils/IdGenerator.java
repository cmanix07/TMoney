package jp.co.rakuten.omatome.utils;

import java.util.UUID;

public class IdGenerator {
  public String generate() {
    return UUID.randomUUID().toString();
  }
}
