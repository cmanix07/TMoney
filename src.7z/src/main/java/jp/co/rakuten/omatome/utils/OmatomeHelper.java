package jp.co.rakuten.omatome.utils;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

import static jp.co.rakuten.omatome.utils.TrackingNumberCleaner.cleanMultipleTrackingNumber;

import jp.co.rakuten.omatome.entity.DeliveryInfoEntity;
import jp.co.rakuten.omatome.model.DeliveryChangeRequestInfo;
import jp.co.rakuten.omatome.model.OrderDetails;

@Component
public class OmatomeHelper {

	public List<String> getDeliveryInfoKeyList(List<OrderDetails> orderDetailsList){
		List<String> deliveryInfoKeyList = new ArrayList<String>();
		for(OrderDetails orderDetails : orderDetailsList) {
			if(StringUtils.isNotBlank(orderDetails.getTrackingNumber())) {
				cleanMultipleTrackingNumber(orderDetails.getTrackingNumber()).forEach(cleanedTrackingNumber -> {
					String deliveryInfoKey = getDeliveryInfoKey(cleanedTrackingNumber, orderDetails.getCompanyNumber(), orderDetails.getOrderNumber()); 
					deliveryInfoKeyList.add(deliveryInfoKey);
				});
			}
		}
		
		return deliveryInfoKeyList;
	}
	
	public Map<String, DeliveryInfoEntity> getDeliveryInfoMap(List<DeliveryInfoEntity> deliveryInfoList) {
		Map<String,DeliveryInfoEntity> deliveryInfoMap = new HashMap<>();
		deliveryInfoList.forEach(deliveryInfoEntity ->{
			String deliveryInfoKey = getDeliveryInfoKey(deliveryInfoEntity.getDeliveryInfoId().getTrackingNumber(),
				deliveryInfoEntity.getDeliveryInfoId().getCompanyNumber(),deliveryInfoEntity.getDeliveryInfoId().getOrderNumber());
			deliveryInfoMap.put(deliveryInfoKey, deliveryInfoEntity);
		});
	
		return deliveryInfoMap; 
	  }
	
	public Map<String, DeliveryChangeRequestInfo> getChangeRequestGroupInfoMap(List<DeliveryChangeRequestInfo> infoList) {
		Map<String, DeliveryChangeRequestInfo> infoMap = new HashMap<>();
		infoList.forEach(requestInfo ->{
			String infoKey = requestInfo.getTrackingNumber() + "-" + requestInfo.getCompanyNumber();
			infoMap.put(infoKey, requestInfo);
		});
	
		return infoMap; 
	  }
	
	public String getDeliveryInfoKey(String trackingNumber,String companyNumber,String orderNumber) {
		String key = trackingNumber + "-" + companyNumber + "-" + orderNumber;
		return key;
	}
}
