package jp.co.rakuten.omatome.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import lombok.Data;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "orderDate", "itemName" })
public class ItemInfo implements Comparable<ItemInfo>{

	@JsonProperty("orderDate")
	private String orderDate;
		
	@JsonProperty("itemName")
	private String itemName;
	
	@Override
	public int compareTo(ItemInfo item) {
		if(this.getOrderDate() == null || item.getOrderDate() == null) {
			return 0;
		}
		return this.getOrderDate().compareTo(item.getOrderDate());
	}

}
