package jp.co.rakuten.omatome.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@NoArgsConstructor
@Table(name = "OMATOME_APP_CONFIG")
public class OmatomeAppConfig {

  @Id
  @Column(name = "CURRENT_VERSION")
  private String currentVersion;

  @Column(name = "FORCE_UPDATE_ENABLE")
  private Integer forceUpdateEnable;
  
  @Column(name = "SYSTEM_MAINTENANCE")
  private Integer systemMaintenance;
  
  @Column(name = "MAINTENANCE_MESSAGE")
  private String maintenanceMessage;

  @Column(name = "FORCE_UPDATE_MESSAGE")
  private String forceUpdateMessage;

  @Column(name = "NEW_VERSION_UPDATE_MESSAGE")
  private String newVersionUpdateMessage;
  
}
