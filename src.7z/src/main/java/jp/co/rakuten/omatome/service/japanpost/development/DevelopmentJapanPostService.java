package jp.co.rakuten.omatome.service.japanpost.development;

import jp.co.rakuten.omatome.model.TrackingInfo;
import jp.co.rakuten.omatome.service.japanpost.JapanPostService;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.*;

public class DevelopmentJapanPostService implements JapanPostService {
  private String url;

  public DevelopmentJapanPostService(String url) {
    this.url = url;
  }

  @Override
  public Map<String, Set<String>> getCommonAvailableDates(List<TrackingInfo> trackingInfoList) {
    LinkedHashMap<String, Set<String>> result = new LinkedHashMap<String, Set<String>>();
    if (trackingInfoList.isEmpty()) {
      return result;
    }

    HashSet<String> timeSlots = new LinkedHashSet<>();
    timeSlots.add("00");
    timeSlots.add("53");
    timeSlots.add("56");

    
    LocalDate today = LocalDate.now();
    for(int i = 0;i < 7; i++) {
    	String date = today.plusDays(i).format(DateTimeFormatter.ofPattern("yyyyMMdd"));
	    switch (trackingInfoList.get(0).getTrackingNumber()) {
	      case "SUCCESS": {
	        result.put(date, timeSlots);
	        break;
	      }
	      default: {
	        result.put(date, timeSlots);
	      }
	    }
    }

    return result;
  }

  @Override
  public Map<String, List<TrackingInfo>> updateDelivery(List<TrackingInfo> trackingInfoList, String date, String timeSlotCode, String phoneNumber) {
    HashMap<String, List<TrackingInfo>> result = new HashMap<>();
    result.put("SUCCESS", trackingInfoList);
    result.put("FAILURE", Collections.emptyList());
    return result;
  }
}
