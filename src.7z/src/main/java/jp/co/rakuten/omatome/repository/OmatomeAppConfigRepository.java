package jp.co.rakuten.omatome.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import jp.co.rakuten.omatome.entity.OmatomeAppConfig;

@Repository
public interface OmatomeAppConfigRepository extends JpaRepository<OmatomeAppConfig,String>  {


}
