package jp.co.rakuten.omatome.response;

public class TimeSlot {
  private String timeSlotCode;
  private String timeRange;
  private boolean ecoFlag;

  public TimeSlot() {
  }

  public TimeSlot(String timeSlotCode, String timeRange, boolean ecoFlag) {
    this.timeSlotCode = timeSlotCode;
    this.timeRange = timeRange;
    this.ecoFlag = ecoFlag;
  }

  public String getTimeSlotCode() {
    return timeSlotCode;
  }

  public boolean isEcoFlag() {
    return ecoFlag;
  }

  public String getTimeRange() {
    return timeRange;
  }
}
