package jp.co.rakuten.omatome.service.japanpost;

import jp.co.rakuten.omatome.model.TrackingInfo;

import java.util.*;

public interface JapanPostService {
  public Map<String, Set<String>> getCommonAvailableDates(List<TrackingInfo> trackingInfoList);

  public Map<String, List<TrackingInfo>> updateDelivery(List<TrackingInfo> trackingInfoList, String date, String timeSlotCode, String phoneNumber);
}
