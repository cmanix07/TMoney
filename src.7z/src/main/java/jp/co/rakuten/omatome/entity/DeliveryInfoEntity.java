package jp.co.rakuten.omatome.entity;

import java.time.LocalDate;
import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "DELIVERY_INFO")
public class DeliveryInfoEntity {

  @EmbeddedId
  private DeliveryInfoEntityId deliveryInfoId;

  @Column(name = "HANDLING_DATETIME")
  private LocalDateTime handlingDatetime;

  @Column(name = "DELIVERY_STATUS")
  private Integer deliveryStatus;

  @Column(name = "DELIVERY_DATE")
  private LocalDate deliveryDate;

  @Column(name = "DELIVERY_TIME")
  private String deliveryTime;

  @Column(name = "COMPLETED_DATE")
  private LocalDate completedDate;

  @Column(name = "STORAGE_LIMIT_DATE")
  private LocalDate storageLimitDate;

  @Column(name = "DELIVERY_REQUEST_URL")
  private String deliveryRequestUrl;

  @Column(name = "REDELIVERY_REQUEST_URL")
  private String redeliveryRequestUrl;

  @Column(name = "EXTENDED_FLAG3")
  private Integer extendedFlag3;

  @Column(name = "ABSENCE_REASON_NUMBER")
  private Integer absenceReasonNumber;

  @Column(name = "CHANGE_TIMESTAMP")
  private LocalDateTime changeTimestamp;

}
