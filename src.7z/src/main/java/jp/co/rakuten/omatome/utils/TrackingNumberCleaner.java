package jp.co.rakuten.omatome.utils;

import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;
import java.util.stream.Collectors;

public class TrackingNumberCleaner {

	private static final String FORWARD_SLASH_AND_BACK_SLASH = "/|\\\\";

	public static String cleanTrackingNumber(String input) {
		return input.replaceAll("[^A-Za-z0-9]", "");
	}

	public static List<String> cleanMultipleTrackingNumber(String input) {
		if(input == null) {
			return new LinkedList<String>();
		}
		return Arrays.stream(input
				.replaceAll(FORWARD_SLASH_AND_BACK_SLASH, ",")
				.split(","))
				.filter(x -> !x.isEmpty())
				.map(TrackingNumberCleaner::cleanTrackingNumber)
				.collect(Collectors.toList());
	}
}
