package jp.co.rakuten.omatome.request;

import jp.co.rakuten.omatome.model.TrackingInfo;

import java.util.List;

public class AvailableDeliveryDateRequest {
  private List<TrackingInfo> trackingInfoList;
  private String companyNumber;

  private AvailableDeliveryDateRequest() {
  }

  public AvailableDeliveryDateRequest(List<TrackingInfo> trackingInfoList, String companyNumber) {
    this.trackingInfoList = trackingInfoList;
    this.companyNumber = companyNumber;
  }

  public List<TrackingInfo> getTrackingInfoList() {
    return trackingInfoList;
  }

  public String getCompanyNumber() {
    return companyNumber;
  }
}
