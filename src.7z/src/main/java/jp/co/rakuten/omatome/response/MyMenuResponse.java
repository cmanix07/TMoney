package jp.co.rakuten.omatome.response;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class MyMenuResponse {
	
	private String privacyPolicyUrl;
	private String licenseUrl;
	private String appListUrl;
	private boolean notificationEnabled;
	
}
