package jp.co.rakuten.omatome.dao;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import jp.co.rakuten.omatome.entity.DeliveryInfoEntity;
import jp.co.rakuten.omatome.model.DeliveryChangeRequestInfo;
import jp.co.rakuten.omatome.model.OrderDetails;
import jp.co.rakuten.omatome.utils.OmatomeConstants;
import jp.co.rakuten.omatome.utils.QueryConstants;


@Component
public class OmatomeDAO {

	@PersistenceContext
	private EntityManager entityManager;

	
	@SuppressWarnings("unchecked")
	public List<OrderDetails> fetchMyOrders(String easyId, List<String> companyNumbers) { 
		StringBuilder queryBuilder =  new StringBuilder(QueryConstants.FETCH_ORDER_DATA);
		Query fetchOrderDetailsQuery = entityManager.createNativeQuery(queryBuilder.toString(),"fetchMyOrders");
		fetchOrderDetailsQuery.setParameter("easyId", easyId);
		fetchOrderDetailsQuery.setParameter("companyNumbers", companyNumbers);
		fetchOrderDetailsQuery.setParameter("deliveryNames", OmatomeConstants.DELIVERY_NAME);
		return fetchOrderDetailsQuery.getResultList(); 
	}

	@SuppressWarnings("unchecked")
	public List<DeliveryInfoEntity> fetchMyOrderDeliveryStatus(Collection<String> deliveryInfoKeyList){ 
		List<DeliveryInfoEntity> resultList = new ArrayList<>();
		StringBuilder queryBuilder =  new StringBuilder(QueryConstants.FETCH_ORDER_DELIVERY_STATUS);
		queryBuilder.append(" ( ");
		boolean appendOr = false;
		if(!CollectionUtils.isEmpty(deliveryInfoKeyList)) {
			for(String deliveryInfoKey:deliveryInfoKeyList) {
				if(appendOr) {
					queryBuilder.append(" OR ");
				}
				String[] key = deliveryInfoKey.split("-",3);
				queryBuilder.append(" ( tracking_number = '" + key[0] + "'");
				queryBuilder.append(" and company_number = '" + key[1] + "'");
				queryBuilder.append(" and order_number = '" + key[2] + "' )");

				appendOr = true;
			};
			queryBuilder.append(" ) and change_timestamp > (sysdate-90)");

			resultList = entityManager.createNativeQuery(queryBuilder.toString(),DeliveryInfoEntity.class).getResultList();
		}
		return resultList; 
	}

	@SuppressWarnings("unchecked")
	public List<DeliveryChangeRequestInfo> fetchMyChangeRequestInfo(Collection<String> deliveryInfoKeyList){ 
		List<DeliveryChangeRequestInfo> resultList = new ArrayList<>();
		StringBuilder queryBuilder =  new StringBuilder(QueryConstants.FETCH_CHANGE_REQUEST_DATA);
		queryBuilder.append(" ( ");
		boolean appendOr = false;
		if(!CollectionUtils.isEmpty(deliveryInfoKeyList)) {
			for(String deliveryInfoKey:deliveryInfoKeyList) {
				if(appendOr) {
					queryBuilder.append(" OR ");
				}
				String[] key = deliveryInfoKey.split("-",3);
				queryBuilder.append(" ( deliveryChangeRequestInfo.tracking_number = '" + key[0] + "'");
				queryBuilder.append(" and deliveryChangeRequestInfo.delivery_company_number = '" + key[1] + "' )");

				appendOr = true;
			};
			queryBuilder.append(" ) and deliveryChangeRequestInfo.change_timestamp > (sysdate-90)");

			resultList = entityManager.createNativeQuery(queryBuilder.toString(), "fetchChangeRequestOrders").getResultList();
		}
		return resultList; 
	}
	
}
