package jp.co.rakuten.omatome.entity;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@Entity
@Table(name = "OMATOME_USER")
public class OmatomeUserEntity {

	@EmbeddedId
	private OmatomeUserEntityId omatomeUserId;
	
	@Column(name = "APP_VERSION")
	private String appVersion;
	
	@Column(name = "NOTIFICATION_ENABLED")
	private Integer notificationEnabled;
	
	@Column(name = "CHANGE_TIMESTAMP")
	private Timestamp changeTimestamp;
	
	@Column(name = "CREATE_TIMESTAMP")
	private Timestamp createTimestamp;
	
	@Column(name = "CHANGE_USER")
	private String changeUser;
	
	@Column(name = "CREATE_USER")
	private String createUser;
	
}
