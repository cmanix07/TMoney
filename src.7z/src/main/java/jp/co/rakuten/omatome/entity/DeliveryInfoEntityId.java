package jp.co.rakuten.omatome.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import java.io.Serializable;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Embeddable
public class DeliveryInfoEntityId implements Serializable {

  /**
   *
   */
  private static final long serialVersionUID = 1L;

  @Column(name = "ORDER_NUMBER")
  private String orderNumber;

  @Column(name = "COMPANY_NUMBER")
  private String companyNumber;

  @Column(name = "TRACKING_NUMBER")
  private String trackingNumber;

}
