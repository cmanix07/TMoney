package jp.co.rakuten.omatome.service;

import static jp.co.rakuten.omatome.utils.OmatomeConstants.OMATOME_DEFAULT_ACTION;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.LinkedList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import jp.co.rakuten.omatome.entity.PointAllocationHistoryEntity;
import jp.co.rakuten.omatome.repository.PointAllocationHistoryRepository;
import jp.co.rakuten.omatome.response.PointAllocationHistoryResponseDTO;
import jp.co.rakuten.omatome.response.PointAllocationInfo;
import jp.co.rakuten.omatome.utils.OmatomeConstants;

@Service
public class PointAllocationHistoryService {

	@Autowired
	PointAllocationHistoryRepository pointAllocationHistoryRepository;


	public PointAllocationHistoryResponseDTO fetchPointAllocationHistory(Long easyId) {
		LocalDate currentDate = LocalDate.now();

		List<PointAllocationHistoryEntity> pointAllocationHistoryList = pointAllocationHistoryRepository
				.findByEasyId(easyId, currentDate.minusDays(OmatomeConstants.NUMBER_OF_DAYS_DATA));

		PointAllocationHistoryResponseDTO pointAllocationHistoryResponseDTO = buildPointAllocationHistoryResponse(
				pointAllocationHistoryList);

		return pointAllocationHistoryResponseDTO;
	}

	public PointAllocationHistoryResponseDTO buildPointAllocationHistoryResponse(
			List<PointAllocationHistoryEntity> pointAllocationHistoryList) {
		PointAllocationHistoryResponseDTO pointAllocationHistoryResponseDTO = new PointAllocationHistoryResponseDTO();
		List<PointAllocationInfo> pointAllocationList = new LinkedList<>();
		if (!CollectionUtils.isEmpty(pointAllocationHistoryList)) {
			pointAllocationHistoryList.forEach(pointAllocationHistoryEntity -> {
				PointAllocationInfo pointAllocationInfo = new PointAllocationInfo();
				pointAllocationInfo.setTrackingNumber(pointAllocationHistoryEntity.getTrackingNumber());
				pointAllocationInfo.setPoints(pointAllocationHistoryEntity.getPoint());
				if(pointAllocationHistoryEntity.getAnnotationFlag()!=null && pointAllocationHistoryEntity.getAnnotationFlag()==1) {
					pointAllocationInfo.setAnnotationFlag(true);	
				} else {
					pointAllocationInfo.setAnnotationFlag(false);
				}
				
				pointAllocationInfo.setCompanyNumber(pointAllocationHistoryEntity.getCompanyNumber());
				pointAllocationInfo.setPointNotAllocatedTrackingNumber(pointAllocationHistoryEntity.getPointNotAllocatedTrackingNumber());
				pointAllocationInfo.setPointGrantDate(formatDate(pointAllocationHistoryEntity.getChangeTimestamp(),
						OmatomeConstants.YYYY_MM_DD_PATTERN));
				pointAllocationInfo.setAction(OMATOME_DEFAULT_ACTION);
				pointAllocationList.add(pointAllocationInfo);
			});
		}
		pointAllocationHistoryResponseDTO.setPointHistoryList(pointAllocationList);
		pointAllocationHistoryResponseDTO.setResponseCode(OmatomeConstants.SUCCESS_RESPONSE_CODE);
		pointAllocationHistoryResponseDTO.setResponseMessage(OmatomeConstants.SUCCESS_RESPONSE_MESSAGE);
		return pointAllocationHistoryResponseDTO;

	}

	public String formatDate(LocalDateTime dateTime, String pattern) {
		DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern(pattern);
		return dateFormatter.format(dateTime);

	}

}
