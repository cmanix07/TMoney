package jp.co.rakuten.omatome.service;

import static jp.co.rakuten.omatome.utils.OmatomeConstants.DATE_CHANGE_REQUEST;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import jp.co.rakuten.omatome.entity.DeliveryChangeEntity;
import jp.co.rakuten.omatome.entity.DeliveryChangePointEntity;
import jp.co.rakuten.omatome.entity.id.DeliveryChangeEntityId;
import jp.co.rakuten.omatome.model.TimeSlotCode;
import jp.co.rakuten.omatome.model.TrackingInfo;
import jp.co.rakuten.omatome.repository.DeliveryChangePointsRepository;
import jp.co.rakuten.omatome.repository.DeliveryChangeRepository;
import jp.co.rakuten.omatome.response.DeliveryChangeResponse;
import jp.co.rakuten.omatome.response.TimeSlot;
import jp.co.rakuten.omatome.service.japanpost.JapanPostService;
import jp.co.rakuten.omatome.utils.DateUtil;
import jp.co.rakuten.omatome.utils.EcoDeliverySlotChecker;
import jp.co.rakuten.omatome.utils.IdGenerator;

@Service
public class DeliveryModificationService {

  private final JapanPostService japanPostService;
  private final DeliveryChangeRepository deliveryChangeRepository;
  private final DeliveryChangePointsRepository deliveryChangePointsRepository;
  private final IdGenerator idGenerator;
  private EcoDeliverySlotChecker ecoDeliverySlotChecker;
  private String id = "";

  @Autowired
  public DeliveryModificationService(JapanPostService japanPostService,
      DeliveryChangeRepository deliveryChangeRepository,
      DeliveryChangePointsRepository deliveryChangePointsRepository, IdGenerator idGenerator,
      EcoDeliverySlotChecker ecoDeliverySlotChecker) {
    this.japanPostService = japanPostService;
    this.deliveryChangeRepository = deliveryChangeRepository;
    this.deliveryChangePointsRepository = deliveryChangePointsRepository;
    this.idGenerator = idGenerator;
    this.ecoDeliverySlotChecker = ecoDeliverySlotChecker;
  }

  @Transactional(rollbackOn = Exception.class)
  public DeliveryChangeResponse modifyDelivery(List<TrackingInfo> trackingInfoList, String deliveryDate,
      String timeSlotCode, String contactNumber, String companyNumber, boolean ecoFlag) {

    boolean isOmatomeGroupDateChangeRequest;
    List<DeliveryChangeEntity> deliveryChangeEntities = null;
    Map<String, List<TrackingInfo>> changeStatus = null;
    int rewardedPoints = 0;
    id = idGenerator.generate();
    LocalDate localDeliveryDate = DateUtil.getLocalDate(deliveryDate);

    List<DeliveryChangeEntity> existingDeliveryChangeEntities = findAllDeliveryChangeEntitiesById(trackingInfoList, companyNumber); //Pass the trackingNos & CompanyNo Ids to retrieve all existing entities
    isOmatomeGroupDateChangeRequest = isOmatomeGroupEditRequest(existingDeliveryChangeEntities, timeSlotCode, localDeliveryDate);

    //New Request then trackingInfoMap is empty.
    if(existingDeliveryChangeEntities.isEmpty()) {
      changeStatus = japanPostService.updateDelivery(
          trackingInfoList,
          deliveryDate,
          timeSlotCode,
          contactNumber);

      List<TrackingInfo> successfulTrackingInfos = changeStatus.get("SUCCESS");
      deliveryChangeEntities = prepareDeliveryChangeEntities(timeSlotCode, companyNumber, ecoFlag,
          localDeliveryDate, successfulTrackingInfos);

      rewardedPoints = getPoints(successfulTrackingInfos, false);
      deliveryChangeRepository.saveAll(deliveryChangeEntities);

      deliveryChangePointsRepository
      .save(new DeliveryChangePointEntity(id, rewardedPoints,
          isOmatome(successfulTrackingInfos)));
    }
    //date change or re-delivery request
    else if(isOmatomeGroupDateChangeRequest) { 
      changeStatus = japanPostService.updateDelivery(trackingInfoList, deliveryDate, timeSlotCode, contactNumber);
      List<TrackingInfo> successfulTrackingInfos = changeStatus.get("SUCCESS");
      List<TrackingInfo> failedTrackingInfos = changeStatus.get("FAILURE");

      Map<String, List<TrackingInfo>> successTrackingInfoMap = extractMatchingTrackingInfosFromDeliveryChangeEntity(existingDeliveryChangeEntities, successfulTrackingInfos);
      Map<String, List<TrackingInfo>> failedTrackingInfoMap = extractMatchingTrackingInfosFromDeliveryChangeEntity(existingDeliveryChangeEntities, failedTrackingInfos);

      List<TrackingInfo> trackingInfoListForPoints = extractNonMatchingTrackingInfos(successfulTrackingInfos,
          existingDeliveryChangeEntities);

      deliveryChangeEntities = prepareDeliveryChangeEntities(timeSlotCode, companyNumber, ecoFlag,
          localDeliveryDate, successfulTrackingInfos);

      rewardedPoints = getPoints(trackingInfoListForPoints, isOmatome(successfulTrackingInfos));

      deliveryChangeRepository.saveAll(deliveryChangeEntities);
      deliveryChangePointsRepository
      .save(new DeliveryChangePointEntity(id, rewardedPoints, isOmatome(successfulTrackingInfos)));

      // Delete the records from points tables which got success
      if(!CollectionUtils.isEmpty(successTrackingInfoMap.keySet())) {
        List<DeliveryChangePointEntity> deliveryChangePointEntities = deliveryChangePointsRepository.findAllById(successTrackingInfoMap.keySet());
        deliveryChangePointsRepository.deleteAll(deliveryChangePointEntities);
      }
      //Update points corresponding to failed delivery changeIds.
      if(!failedTrackingInfoMap.isEmpty()) {
        List<DeliveryChangePointEntity> deliveryChangePointEntitiesForUpdate =  new ArrayList<>();
        for (Entry<String, List<TrackingInfo>> entry : failedTrackingInfoMap.entrySet()) {
          boolean isOmatomeFlag = isOmatome(entry.getValue()); 
          deliveryChangePointEntitiesForUpdate.add(new DeliveryChangePointEntity(entry.getKey(), getPoints(entry.getValue(), isOmatomeFlag), isOmatomeFlag));
        }
        deliveryChangePointsRepository.saveAll(deliveryChangePointEntitiesForUpdate);
      }
    }else {

      //Retrieve the non-omatome trackingInfo
      List<TrackingInfo> trackingInfoForChangeRequest = extractNonMatchingTrackingInfos(trackingInfoList,
          existingDeliveryChangeEntities);

      // JP call only for non-group tracking number
      if (!trackingInfoForChangeRequest.isEmpty()) {
        changeStatus = japanPostService.updateDelivery(trackingInfoForChangeRequest, deliveryDate, timeSlotCode,
            contactNumber);
        List<TrackingInfo> successfulTrackingInfoForChangeRequest = changeStatus.get("SUCCESS");
        Set<String> changeIdSets = existingDeliveryChangeEntities.stream().map(entity -> entity.getDeliveryChangeId()).collect(Collectors.toSet());
        List<DeliveryChangePointEntity> deliveryChangePointEntities = deliveryChangePointsRepository.findAllById(changeIdSets);
        rewardedPoints = deliveryChangePointEntities.stream().map(DeliveryChangePointEntity::getPoint).reduce(0, Integer::sum);
        rewardedPoints += getPoints(successfulTrackingInfoForChangeRequest, Boolean.TRUE);

        deliveryChangeEntities = prepareDeliveryChangeEntities(timeSlotCode, companyNumber, ecoFlag, localDeliveryDate, successfulTrackingInfoForChangeRequest);

        existingDeliveryChangeEntities.stream().forEach(entity -> entity.setDeliveryChangeId(id));
        deliveryChangeEntities.addAll(existingDeliveryChangeEntities);

        deliveryChangeRepository.saveAll(deliveryChangeEntities);
        deliveryChangePointsRepository.save(new DeliveryChangePointEntity(id, rewardedPoints, Boolean.TRUE));
        if(!CollectionUtils.isEmpty(deliveryChangePointEntities)) {
          deliveryChangePointsRepository.deleteAll(deliveryChangePointEntities);
        }
      }


    }
    return new DeliveryChangeResponse(id, changeStatus, rewardedPoints, deliveryDate, timeSlotCode,
        TimeSlotCode.getDescriptionFor(timeSlotCode), ecoFlag);
  }

  /**
   * @param trackingInfoList
   * @param existingDeliveryChangeEntities
   * @return
   */
  private List<TrackingInfo> extractNonMatchingTrackingInfos(List<TrackingInfo> trackingInfoList,
      List<DeliveryChangeEntity> existingDeliveryChangeEntities) {
    List<TrackingInfo> trackingInfoForChangeRequest = trackingInfoList
        .stream().filter(
            trackinInfo -> existingDeliveryChangeEntities.stream()
            .noneMatch(deliveryChangeEntity -> deliveryChangeEntity.getId()
                .getTrackingNumber().equals(trackinInfo.getTrackingNumber())))
        .collect(Collectors.toList());
    return trackingInfoForChangeRequest;
  }

  /**
   * @param timeSlotCode
   * @param companyNumber
   * @param ecoFlag
   * @param localDeliveryDate
   * @param successfulTrackingInfos
   * @return
   */
  private List<DeliveryChangeEntity> prepareDeliveryChangeEntities(String timeSlotCode, String companyNumber,
      boolean ecoFlag, LocalDate localDeliveryDate, List<TrackingInfo> successfulTrackingInfos) {
    List<DeliveryChangeEntity> deliveryChangeEntities = successfulTrackingInfos.stream()
    .map(trackingInfo -> new DeliveryChangeEntity(
      new DeliveryChangeEntityId(companyNumber, trackingInfo.getTrackingNumber()),
      id, localDeliveryDate, TimeSlotCode.getDescriptionFor(timeSlotCode), timeSlotCode, ecoFlag,
      null, trackingInfo.getRequestType()))
    .collect(Collectors.toList());
    return deliveryChangeEntities;
  }

  /**
   * @param existingDeliveryChangeEntities
   * @param trackingInfos
   */
  private Map<String, List<TrackingInfo>> extractMatchingTrackingInfosFromDeliveryChangeEntity(List<DeliveryChangeEntity> existingDeliveryChangeEntities,
      List<TrackingInfo> trackingInfos) {
    Map<String, List<TrackingInfo>> trackingInfoMap = new HashMap<>();

    for (DeliveryChangeEntity entity : existingDeliveryChangeEntities) {
      List<TrackingInfo> trackinInfoList= trackingInfos.stream().filter(trackinInfo -> entity.getId()
          .getTrackingNumber().equals(trackinInfo.getTrackingNumber()))
          .collect(Collectors.toList());
      if(trackinInfoList.size() > 0) {
        if(trackingInfoMap.containsKey(entity.getDeliveryChangeId())) {
          List<TrackingInfo> tempTrackingInfos =  trackingInfoMap.get(entity.getDeliveryChangeId());
          tempTrackingInfos.addAll(trackinInfoList);
          trackingInfoMap.put(entity.getDeliveryChangeId(), tempTrackingInfos);
        }else {
          trackingInfoMap.put(entity.getDeliveryChangeId(), trackinInfoList);
        }
      }
    }
    return trackingInfoMap;
  }

  private int getPoints(List<TrackingInfo> trackingInfos, boolean isOmatome) {
    if(isOmatome && trackingInfos.size() == 1 ) {
      return trackingInfos.stream().map(TrackingInfo::getPoint).reduce(0, Integer::sum);
    }
    if (trackingInfos.size() > 1) {
      return trackingInfos.stream().map(TrackingInfo::getPoint).reduce(0, Integer::sum);
    }
    
    return 0;
  }

  private boolean isOmatome(List<TrackingInfo> trackingInfos) {
    return trackingInfos.size() > 1;
  }

  public Map<String, List<TimeSlot>> availableDates(List<TrackingInfo> trackingInfoList, String companyNumber) {

    List<TrackingInfo> jpRequestTrackingInfoList = new ArrayList<>();
    Map<String, Set<String>> existingSelectedDates =  new LinkedHashMap<>();
    trackingInfoList.forEach(trackingInfo-> {
      if(trackingInfo.getChangeRequestId() !=null && trackingInfo.getRequestType().equalsIgnoreCase(DATE_CHANGE_REQUEST)) {
        DeliveryChangeEntityId deliveryChangeId  = new DeliveryChangeEntityId(companyNumber,trackingInfo.getTrackingNumber());
        Optional<DeliveryChangeEntity> deliveryChangeOptional = deliveryChangeRepository.findById(deliveryChangeId);
        DeliveryChangeEntity deliveryChangeInfo = deliveryChangeOptional.get();
        Set<String> selectedTimeSlot = new HashSet<>();
        selectedTimeSlot.add(deliveryChangeInfo.getTimeSlotCode());
        String formattedDeliveryDate = DateUtil.format(deliveryChangeInfo.getDeliveryDate());
        existingSelectedDates.put(formattedDeliveryDate, selectedTimeSlot);
      } else {
        jpRequestTrackingInfoList.add(trackingInfo);
      }
    });
    Map<String, Set<String>> commonAvailableDates ;
    if(existingSelectedDates.isEmpty()) {
      commonAvailableDates = japanPostService.getCommonAvailableDates(jpRequestTrackingInfoList);
    } else {
      commonAvailableDates = existingSelectedDates;
    }

    Map<String, List<TimeSlot>> result = new LinkedHashMap<>();

    commonAvailableDates.forEach((date, slots) -> {
      List<TimeSlot> timeSlots = slots
          .stream()
          .map(timeSlotCode -> new TimeSlot(
              timeSlotCode,
              TimeSlotCode.getDescriptionFor(timeSlotCode),
              ecoDeliverySlotChecker.isEligible(date, timeSlotCode, companyNumber)))
          .collect(Collectors.toList());
      result.put(date, timeSlots);
    });

    return result;
  }

  private Boolean isOmatomeGroupEditRequest(List<DeliveryChangeEntity> existingDeliveryChangeEntities, String timeSlotCode, LocalDate localDeliveryDate) {
    if(CollectionUtils.isEmpty(existingDeliveryChangeEntities)) {
      return Boolean.TRUE;
    }else {
      Boolean isOmatomeGroupOrNewDateChangeRequest = Boolean.FALSE;
      for (DeliveryChangeEntity deliveryChangeEntity : existingDeliveryChangeEntities) {
        isOmatomeGroupOrNewDateChangeRequest = !(deliveryChangeEntity.getDeliveryDate().equals(localDeliveryDate) && deliveryChangeEntity.getTimeSlotCode().equals(timeSlotCode));
        if(isOmatomeGroupOrNewDateChangeRequest) {
          break;
        }
      }
      return isOmatomeGroupOrNewDateChangeRequest;
    }
  }

  private List<DeliveryChangeEntity> findAllDeliveryChangeEntitiesById(List<TrackingInfo> trackingInfos, String companyNumber){
    List<DeliveryChangeEntity> existingDeliveryChangeEntities = new ArrayList<>();
    List<DeliveryChangeEntityId> changeRequestIds = new ArrayList<>();
    if(trackingInfos.size() > 0) {
      trackingInfos.stream().forEach(trackingInfo -> {
        DeliveryChangeEntityId deliveryChangeEntityId = new DeliveryChangeEntityId(companyNumber, trackingInfo.getTrackingNumber()); 
        changeRequestIds.add(deliveryChangeEntityId);
      });
    }
    existingDeliveryChangeEntities = deliveryChangeRepository.findAllById(changeRequestIds);
    return existingDeliveryChangeEntities;
  }

}
