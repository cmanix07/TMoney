package jp.co.rakuten.omatome.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import lombok.Data;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
	  "trackingNumber",
	  "pointNotAllocatedTrackingNumber",
	  "companyNumber",
	  "points",
	  "annotationFlag",
	  "pointGrantDate",
	  "action"
	})
@Data
public class PointAllocationInfo {
	
	@JsonProperty("trackingNumber")
	private String trackingNumber;

	@JsonProperty("pointNotAllocatedTrackingNumber")
	private String pointNotAllocatedTrackingNumber;

	@JsonProperty("companyNumber")
	private String companyNumber;

	@JsonProperty("points")
	private Integer points;

	@JsonProperty("annotationFlag")
	private boolean annotationFlag;

	@JsonProperty("pointGrantDate")
	private String pointGrantDate;

	@JsonProperty("action")
	private String action;
}
