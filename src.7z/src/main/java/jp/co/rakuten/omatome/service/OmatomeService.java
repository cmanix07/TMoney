package jp.co.rakuten.omatome.service;

import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import jp.co.rakuten.omatome.dao.OmatomeDAO;
import jp.co.rakuten.omatome.entity.DeliveryInfoEntity;
import jp.co.rakuten.omatome.entity.OmatomeAppConfig;
import jp.co.rakuten.omatome.entity.OmatomeTrackingNumberRange;
import jp.co.rakuten.omatome.entity.OmatomeUserEntity;
import jp.co.rakuten.omatome.entity.OmatomeUserEntityId;
import jp.co.rakuten.omatome.model.DeliveryChangeRequestInfo;
import jp.co.rakuten.omatome.model.OrderDetails;
import jp.co.rakuten.omatome.repository.OmatomeAppConfigRepository;
import jp.co.rakuten.omatome.repository.OmatomeUserRepository;
import jp.co.rakuten.omatome.repository.TrackingNumberRangeRepository;
import jp.co.rakuten.omatome.response.AppMetadataResponse;
import jp.co.rakuten.omatome.response.MyMenuResponse;
import jp.co.rakuten.omatome.response.MyOrderResponseDTO;
import jp.co.rakuten.omatome.utils.OmatomeConstants;
import jp.co.rakuten.omatome.utils.OmatomeHelper;
import jp.co.rakuten.omatome.utils.ResponseUtils;

@Service
public class OmatomeService {

  private static final Logger log = LoggerFactory.getLogger(OmatomeService.class);

  @Autowired
  private OmatomeDAO omatomeDAO;
  
  @Autowired
  private OmatomeUserRepository omatomeUserRepository;

  @Autowired
  private ResponseUtils responseUtils;
	
  @Autowired
  private OmatomeHelper omatomeHelper;
  
  @Autowired
  private OmatomeAppConfigRepository omatomeAppConfigRepository;
  
  @Autowired
  private TrackingNumberRangeRepository omatomeTrackingNumberRangeRepository;

	/**
	 * @param easyId
	 * @param companyNumberList
	 * @return
	 */
	public MyOrderResponseDTO fetchMyOrders(String easyId, List<String> companyNumberList) {
		if(companyNumberList.isEmpty()) {
			companyNumberList.add("1003");
			companyNumberList.add("1028");
		}
		List<OrderDetails> orderDetailsList = omatomeDAO.fetchMyOrders(easyId, companyNumberList);
		log.info("orderDetailsList:{}", orderDetailsList.size());

		//getDeliveryInfoKey to get the deliveryStatus
		List<String> deliveryInfoKeyList = omatomeHelper.getDeliveryInfoKeyList(orderDetailsList);	
		log.info("deliveryInfoKeyList:{}", deliveryInfoKeyList.size());

		List<DeliveryInfoEntity> deliveryInfoList = omatomeDAO.fetchMyOrderDeliveryStatus(deliveryInfoKeyList);
		log.info("deliveryInfoList:{}", deliveryInfoList.size());

		//Map the status to trackingnumber,companyNumber,orderNumber
		Map<String, DeliveryInfoEntity> deliveryInfoMap = omatomeHelper.getDeliveryInfoMap(deliveryInfoList);
		
		List<DeliveryChangeRequestInfo> deliveryChangeRequestInfoList = omatomeDAO.fetchMyChangeRequestInfo(deliveryInfoKeyList);
		log.info("deliveryChangeRequestInfoList:{}", deliveryChangeRequestInfoList.size());

		Map<String, DeliveryChangeRequestInfo> deliveryChangeRequestInfoMap = omatomeHelper.getChangeRequestGroupInfoMap(deliveryChangeRequestInfoList);
		log.info("deliveryChangeRequestInfoMap:{}", deliveryChangeRequestInfoMap.size());
		
		List<OmatomeTrackingNumberRange> omatomeTrackingNumberRangeList = omatomeTrackingNumberRangeRepository.getTrackingNumberRangeByType(OmatomeConstants.RANGE_TYPE);

		//getResponse Object
		MyOrderResponseDTO myOrderResponseDTO = responseUtils.getMyOrderResponse(orderDetailsList, deliveryInfoMap, deliveryChangeRequestInfoMap, omatomeTrackingNumberRangeList);
		
		log.info("myOrderResponseDTO:{}", myOrderResponseDTO.getShippingList());
		return myOrderResponseDTO;
	}
  
  public void register(String easyId,String deviceId,String appVersion) {
	
	OmatomeUserEntityId omatomeUserEntityId = new OmatomeUserEntityId(easyId,deviceId);
	OmatomeUserEntity omatomeUserEntity;
	Optional<OmatomeUserEntity> omatomeUserOptional = omatomeUserRepository.findById(omatomeUserEntityId);
	if(omatomeUserOptional.isPresent()) {
		omatomeUserEntity = omatomeUserOptional.get();
	} else {
		omatomeUserEntity = new OmatomeUserEntity();
	}
	omatomeUserEntity.setOmatomeUserId(omatomeUserEntityId);
	omatomeUserEntity.setAppVersion(appVersion);
	omatomeUserRepository.save(omatomeUserEntity);
	
  }

  public AppMetadataResponse getAppMetadata() {
	  AppMetadataResponse appMetadataResponse = new AppMetadataResponse();
	  OmatomeAppConfig omatomeAppConfig = omatomeAppConfigRepository.findAll().get(0);
	  appMetadataResponse.setCurrentVersion(omatomeAppConfig.getCurrentVersion());
	  if(omatomeAppConfig.getSystemMaintenance()==1) {
		  appMetadataResponse.setMaintenanceMessage(omatomeAppConfig.getMaintenanceMessage());
		  appMetadataResponse.setSystemMaintenance(true);
	  } else {
		  appMetadataResponse.setSystemMaintenance(false);

	  }
	  appMetadataResponse.setNewVersionUpdateMessage(omatomeAppConfig.getNewVersionUpdateMessage());
	  if(omatomeAppConfig.getForceUpdateEnable()==1) {
		  appMetadataResponse.setForceUpdate(true);
		  appMetadataResponse.setForceUpdateMessage(omatomeAppConfig.getForceUpdateMessage());

	  } else {
		  appMetadataResponse.setForceUpdate(false);
	  }
	  return appMetadataResponse;
  }

  public void updateNotificationSettings(String easyId,String deviceId,boolean nofificationEnable) {
		
	OmatomeUserEntity omatomeUserEntity ;
	OmatomeUserEntityId omatomeUserEntityId = new OmatomeUserEntityId(easyId,deviceId);
	
	Optional<OmatomeUserEntity> optional = omatomeUserRepository.findById(omatomeUserEntityId);
	if(optional.isPresent()) {
		omatomeUserEntity = optional.get();
		if(nofificationEnable) {
			omatomeUserEntity.setNotificationEnabled(1);
		} else {
			omatomeUserEntity.setNotificationEnabled(0);
		}
		omatomeUserRepository.save(omatomeUserEntity);
	} 
	
  }

  public MyMenuResponse getMyMenu(String easyId,String deviceId) {
	MyMenuResponse myMenuResponse = new MyMenuResponse();
	myMenuResponse.setLicenseUrl(OmatomeConstants.LICENSE_URL);
	myMenuResponse.setPrivacyPolicyUrl(OmatomeConstants.PRIVACY_POLICY_URL);
	myMenuResponse.setAppListUrl(OmatomeConstants.APP_LIST_URL);
	OmatomeUserEntityId omatomeUserEntityId = new OmatomeUserEntityId(easyId,deviceId);
	Optional<OmatomeUserEntity> optional = omatomeUserRepository.findById(omatomeUserEntityId);
	OmatomeUserEntity omatomeUserEntity = optional.get();
	if(omatomeUserEntity.getNotificationEnabled()!=null && omatomeUserEntity.getNotificationEnabled()==1) {
		myMenuResponse.setNotificationEnabled(true);
	} else {
		myMenuResponse.setNotificationEnabled(false);
	}
	
	return myMenuResponse;
  }

}
