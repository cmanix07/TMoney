package jp.co.rakuten.omatome.response;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class AppMetadataResponse {
	
	private String currentVersion;
	private boolean forceUpdate;
	private String forceUpdateMessage;
	private boolean systemMaintenance;
	private String maintenanceMessage;
	private String newVersionUpdateMessage;
	
}
