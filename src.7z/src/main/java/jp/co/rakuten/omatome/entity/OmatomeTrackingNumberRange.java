package jp.co.rakuten.omatome.entity;

import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@Entity
@Table(name = "OMATOME_TRACKING_NUMBER_RANGE")
public class OmatomeTrackingNumberRange {
	
	@EmbeddedId
	private OmatomeTrackingNumberRangeId omatomeTrackingNumberRangeId;
}
