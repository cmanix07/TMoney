package jp.co.rakuten.omatome.config;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.cache.CacheManager;
import org.springframework.cache.annotation.CachingConfigurerSupport;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.redis.cache.RedisCacheConfiguration;
import org.springframework.data.redis.cache.RedisCacheManager;
import org.springframework.data.redis.connection.RedisConnectionFactory;
import org.springframework.data.redis.serializer.GenericJackson2JsonRedisSerializer;
import org.springframework.data.redis.serializer.RedisSerializationContext;

import java.time.Duration;
import java.time.temporal.ChronoUnit;

@Configuration
@EnableCaching
@ConditionalOnProperty("spring.redis.enabled")
public class RedisConfiguration extends CachingConfigurerSupport {

  @Autowired
  private RedisConnectionFactory redisConnectionFactory;

  @Value("${spring.cache.time-to-live}")
  private int ttl;

  @Value("${spring.cache.ttl-unit}")
  private ChronoUnit ttlUnit;

  @Bean
  public CacheManager redisCacheManager(ObjectMapper mapper) {
    RedisSerializationContext.SerializationPair<Object> jsonSerializer =
      RedisSerializationContext
        .SerializationPair
        .fromSerializer(new GenericJackson2JsonRedisSerializer(mapper));

    return RedisCacheManager.RedisCacheManagerBuilder
      .fromConnectionFactory(redisConnectionFactory)
      .cacheDefaults(
        RedisCacheConfiguration.defaultCacheConfig()
          .entryTtl(Duration.of(ttl, ttlUnit))
          .serializeValuesWith(jsonSerializer)
      )
      .build();
  }

}