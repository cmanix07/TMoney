package redi

import io.gatling.core.Predef._
import io.gatling.http.Predef._
import scala.concurrent.duration._

class REDISimulation extends Simulation {

  val httpProtocol = http
    .baseUrl(Configuration.t_baseUrl)
    .acceptHeader("text/html,application/json,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8")

  if (phScenario) {
    val constantRateScenario = scenario("PH").exec(PHSearch.phSearch)

    setUp(
      constantRateScenario
        .inject(constantUsersPerSec(Configuration.t_constantUserPerSec) during (Configuration.t_constantLoadDuration seconds))
    ).protocols(httpProtocol)
  }
  else {
    val rampedUpRateScenario = scenario("Generic").exec(GenericSearch.genericSearch)

    setUp(
      rampedUpRateScenario
        .inject(constantUsersPerSec(Configuration.t_constantUserPerSec) during (Configuration.t_constantLoadDuration seconds))
    ).protocols(httpProtocol)
  }

  private def phScenario = {
    "ph".equals(Configuration.t_scenario)
  }
}

object PHSearch {
  val feeder = csv("search_ph.csv").batch(50).random
  val authToken = Configuration.t_authToken

  val phSearch = feed(feeder)
    .exec(http("ph_search")
      .post("/deliverystatus/ph")
      .header("Authorization", "Bearer "+ authToken)
      .body(ElFileBody("phApiBody.json")).asJson)

}

object GenericSearch {
  val feeder = csv("search_generic.csv").batch(50).random
  val authToken = Configuration.t_authToken

  val genericSearch = feed(feeder)
    .exec(http("generic_search")
      .post("/deliverystatus")
      .header("Authorization", "Bearer "+ authToken)
      .body(ElFileBody("genericApiBody.json")).asJson)

}

object Configuration {
  val t_baseUrl = System.getProperty("baseUrl")
  val t_scenario = System.getProperty("scenario")
  val t_constantUserPerSec = Integer.getInteger("constantUserPerSec", 56).toInt
  val t_constantLoadDuration = Integer.getInteger("constantLoadDuration", 10).toInt
  val t_authToken = System.getProperty("authToken")
}