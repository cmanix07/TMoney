-- WARNING : QUERY might be really slow
-- CHANGE the output directory and file accordingly and total rows for CURSOR C_ORDER
-- REMOVE ->PL/SQL procedure successfully completed. and empty lines manually after spooling done
SPOOL C:\USERS\HARDYANSEIN.DJONG\OUTPUT.TXT
SET SERVEROUTPUT ON
DECLARE
    CURSOR C_EASY_ID IS SELECT DISTINCT EASY_ID FROM ORDER_BASE_INFO WHERE STATUS_ID <> -1 ORDER BY CREATE_TIMESTAMP DESC fetch first 100 rows only;
    V_ORDER_LIST VARCHAR2(1000);
    V_ORDER_NUM_IN_ONE_LINE NUMBER := 25;
    V_ORDER_COUNTER NUMBER := 1;
BEGIN
    DBMS_OUTPUT.ENABLE (buffer_size => NULL);
    -- CSV Header
    V_ORDER_LIST := '';
    FOR LOOP_COUNTER IN 1..V_ORDER_NUM_IN_ONE_LINE LOOP
            V_ORDER_LIST := CONCAT(V_ORDER_LIST,CONCAT('order', LOOP_COUNTER));
            IF (LOOP_COUNTER < V_ORDER_NUM_IN_ONE_LINE) THEN
                V_ORDER_LIST := CONCAT(V_ORDER_LIST , ',');
            END IF;
        END LOOP;
    DBMS_OUTPUT.PUT_LINE(V_ORDER_LIST);
    -- CSV Content
    V_ORDER_LIST := '';
    FOR CUR_EASY_ID IN C_EASY_ID LOOP
            V_ORDER_LIST := '';
            V_ORDER_COUNTER := 1;
            FOR CUR_REC IN (SELECT ORDER_NUMBER FROM ORDER_BASE_INFO WHERE STATUS_ID <> -1 AND EASY_ID = CUR_EASY_ID.EASY_ID ORDER BY CREATE_TIMESTAMP DESC fetch first V_ORDER_NUM_IN_ONE_LINE rows only) LOOP
                    -- concat order number , don't add comma to end of line
                    IF (V_ORDER_COUNTER > 1) THEN
                        V_ORDER_LIST := CONCAT(V_ORDER_LIST , ',');
                    END IF;
                    V_ORDER_LIST := CONCAT(V_ORDER_LIST,CUR_REC.ORDER_NUMBER);

                    -- order number counter
                    V_ORDER_COUNTER := V_ORDER_COUNTER + 1;
                END LOOP;
            DBMS_OUTPUT.PUT_LINE(V_ORDER_LIST);
        END LOOP;

    COMMIT;
END;
/

SPOOL OFF