# REDI performance test

Performance test are written using gatling for REDI API. 
Sample inputs are read from the resources/search*.csv files.

To test it out, simply execute the following command:
```bash
    mvn gatling:test
```

## Authentication
For authentication call the /accesstoken API for REDI and pass the auth token as argument while running the test.

```bash
    mvn gatling:test -DauthToken=REPLACE_ME
```

## Parameters
| Parameter              | Description   |
| ---------------------- |:--------------|
| -DconstantUserPerSec   | Number of users to be increased per second for - **constant scenario**|
| -DconstantLoadDuration | Duration in seconds for - **constant scenario**                       |
| -DbaseUrl              | Base url for application                                              |
| -Dscenario             | Scenario to run - ph or bulk                                          |
| -DauthToken            | Authentication token to be used for connecting to the test API        |

## Changing log level
Change LOG level in logback-test.xml
```xml
	<root level="REPLACE_ME">
		<appender-ref ref="CONSOLE" />
	</root>
```

## Links
[Build pipeline](https://jenkins-zed.intra.rakuten-it.com/job/Tenant/job/ecld-scg-redi/job/Apps/job/performance-test/)

[Build and deploy code](https://git.rakuten-it.com/projects/ZEDCLT/repos/tenant-ecld-scg-redi-performance-test/browse)


## Generating Dataset
```asciidoc 
Gatling is using csv file as feeder for performance test. For REDI API performance test , dataset can be generated from target database by getting order numbers and split it into a set of 25 order numbers (max order numbers from Purchase History request). 
Step to generate : 
1. Go to performance-test-api/src/test/resources/generate_unique_order_number_dataset.sql
2. Change SPOOL location to accessible location in the server where SQLPlus will be executed. 
   SPOOL C:\USERS\HARDYANSEIN.DJONG\OUTPUT.TXT -> SPOOL /home/<user>/ph_dataset.csv
3. Change the query accordingly 
   CURSOR C_ORDER IS SELECT ORDER_NUMBER FROM ORDER_BASE_INFO WHERE STATUS_ID <> -1 ORDER BY CREATE_TIMESTAMP DESC fetch first 100 rows only; ->
   CURSOR C_ORDER IS SELECT ORDER_NUMBER FROM ORDER_BASE_INFO WHERE STATUS_ID <> -1 AND CREATE_TIMESTAMP < TRUNC(SYSDATE) ORDER BY CREATE_TIMESTAMP DESC fetch first 100000 rows only;
4. Execute the modified PL/SQL in SQLPlus 
5. Remove "PL/SQL procedure successfully completed." and empty lines manually after spooling done in the output file.
```
 
## How to add cert for HTTPS endpoint to truststore and keystore
```asciidoc
openssl s_client -connect REPLACE_URL:443 2>/dev/null </dev/null |  sed -ne '/-BEGIN CERTIFICATE-/,/-END CERTIFICATE-/p' > certificate.cer

keytool -importcert -file certificate.cer -keystore keystore.jks

keytool -import -v -trustcacerts -file certificate.cer -keystore truststore.ks
```

## Execution steps in pipeline
```asciidoc
1. Make sure that test order numbers are updated in test files (search*.csv)
2. Build jenkins pipeline with git branch and note docker image version
3. Ensure that 4 replicas of REDI are running with 4CPU and atleast 6GB memory
4. Ensure that performance test pod has 4cpu as resource
5. Build the QA pipeline with below parameters
    GIT_BRANCH and MANIFEST_GIT_BRANCH = git branch name
    BASE_URL = URL
    SCENARIO = ph
    CONSTANT_USER_PER_SEC = no of users per sec
    CONSTANT_LOAD_DURATION = time to run the test for
    AUTH_TOKEN = get auth token by calling the authentication API separately
    other parameters = default
6. During deploy select the docker image from step 2
7. Login to zxd and check logs
    zctl login -c jpe2-zed2-stg -n ecld-scg-redi
    kubectl get po
    kubectl get logs -f <POD_NAME_FOR_PERF_TEST_FROM_ABOVE_STEP>
8. The QPS will be listed after the process finishes
9. Delete the performance test job
    kubectl delete job performance-test-qa
10. Check the resource usage from datadog
    https://app.datadoghq.com/dashboard/

```

## Performance test results
https://confluence.rakuten-it.com/confluence/pages/viewpage.action?pageId=2122795167